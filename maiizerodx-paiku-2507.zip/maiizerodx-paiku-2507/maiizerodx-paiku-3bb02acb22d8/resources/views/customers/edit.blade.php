@extends('layouts.app')

@push('script')
<script>
	document.addEventListener('DOMContentLoaded', () => {
  const timeInput = document.getElementById('balance_check_time');
  const form      = timeInput.closest('form');   // หา <form> ที่ครอบอยู่

  // 1) ตรวจทันทีที่พิมพ์
  timeInput.addEventListener('input', () => {
    validateTime(timeInput);
  });

  // 2) กันไว้ตอน submit อีกรอบ
  form.addEventListener('submit', (e) => {
    if (!validateTime(timeInput)) {
      e.preventDefault();      // ยกเลิกการ submit
      alert('กรุณากรอกเวลาเป็นรูปแบบ HH:MM (เช่น 08:05 หรือ 18:45)');
    }
  });

  // ฟังก์ชันตรวจสอบเวลา
  function validateTime(el) {
    // ^([01]\d|2[0-3]):[0-5]\d$ อนุญาต 00-23:00-59 เท่านั้น
    const isValid = /^([01]\d|2[0-3]):[0-5]\d(?:[:][0-5]\d)?$/.test(el.value.trim());
    el.classList.toggle('is-invalid', !isValid);  // แต่ง class Bootstrap ถ้าอยากให้ขึ้นสีแดง
    return isValid;
  }
});
</script>
@endpush

@section('content')
<a href="#"><strong><i class="glyphicon glyphicon-shopping-cart"></i> แก้ไขลูกค้า</strong></a>
<hr>
<div class="row">
	<div class="col-md-12">
		<form class="form-horizontal" method="post" action="{{ url('/customers/'.$customer->id) }}">
			{{ csrf_field() }}
			<input type="hidden" name="_method" value="PUT">
			<fieldset>
				<!-- Text input-->
				<div class="form-group">
					<label class="col-md-4 control-label">ชื่อลูกค้า</label>
					<div class="col-md-4">
						<input name="name" type="text" placeholder="ชื่อลูกค้า" class="form-control input-md"
							required="" value="{{ $customer->name }}">
					</div>
				</div>
				<div class="form-group">
					<label class="col-md-4 control-label">เบอร์โทร</label>
					<div class="col-md-4">
						<input name="telephone" type="text" placeholder="เบอร์โทร" class="form-control input-md"
							value="{{ $customer->telephone }}">
					</div>
				</div>
				<div class="form-group">
					<label class="col-md-4 control-label">ที่อยู่</label>
					<div class="col-md-4">
						<textarea name="address" class="form-control input-md">{{ $customer->address}}</textarea>
					</div>
				</div>
				<div class="form-group">
					<label class="col-md-4 control-label">ประเภทลูกค้า</label>
					<div class="col-md-4">
						<select id="selectbasic" name="customer_type_id" class="form-control">
							<option value="0" @if($customer['customer_type_id']==0 )selected="selected" @endif>
								-------ไม่ระบุ-------</option>
							@if($customertypes)
							@foreach($customertypes as $customertype)
							<option value="{{$customertype->id}}" @if($customer['customer_type_id']==$customertype['id']
								)selected="selected" @endif>{{$customertype->name}}</option>
							@endforeach
							@endif
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="col-md-4 control-label">ตลาด</label>
					<div class="col-md-4">
						<select id="selectbasic" name="market_id" class="form-control">
							<option value="0" @if($customer['market_id']==0 )selected="selected" @endif>
								-------ไม่ระบุ-------</option>
							@if($markets)
							@foreach($markets as $market)
							<option value="{{$market->id}}" @if($customer['market_id']==$market['id']
								)selected="selected" @endif>{{$market->name}}</option>
							@endforeach
							@endif
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="col-md-4 control-label">รถ</label>
					<div class="col-md-4">
						<select id="selectbasic" name="car_id" class="form-control">
							<option value="0" @if($customer['car_id']==0 )selected="selected" @endif>
								-------ไม่ระบุ-------</option>
							@if($cars)
							@foreach($cars as $car)
							<option value="{{$car->id}}" @if($customer['car_id']==$car['id'] )selected="selected"
								@endif>{{$car->name}}</option>
							@endforeach
							@endif
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="col-md-4 control-label">ออกบิล</label>
					<div class="col-md-4">
						<div class="checkbox">
							<label><input name="auto_bill_print" type="checkbox" value="1"
									@if($customer['auto_bill_print']==1) checked @endif>เงินสด</label>
						</div>
					</div>
				</div>
				{{-- 20250620 --}}
				<hr>
				<div class="form-group">
					<label class="col-md-4 control-label">ช่องทางการรับยอด</label>
					<div class="col-md-4">
						<input name="statement_channel" type="text" placeholder="Line / โทรศัพท์"
							class="form-control input-md"  value="{{ $customer->statement_channel }}">
					</div>
				</div>
				<div class="form-group">
					<label class="col-md-4 control-label">เวลาเช็คยอดของลูกค้า</label>
					<div class="col-md-4">
						<input id="balance_check_time" name="balance_check_time" type="text"
							placeholder="ตัวอย่าง 10:30" class="form-control input-md" 
							value="{{ $customer->balance_check_time }}">
					</div>
				</div>
				<hr>
				<div class="form-group">
					<label class="col-md-4 control-label">สถานะของลูกค้า</label>
					<div class="col-md-4">
						<select id="selectbasic" name="status" class="form-control">
							<option value="1" @if($customer['status']==1 )selected="selected" @endif>
								ยังมีการสั่งซื้อสินค้า</option>
							<option value="0" @if($customer['status']==0 )selected="selected" @endif>
								ไม่มีการสั่งซื้อสินค้า</option>
						</select>
					</div>
				</div>
				<!-- Button (Double) -->
				<div class="form-group">
					<label class="col-md-4 control-label"></label>
					<div class="col-md-8">
						<input type="submit" name="submit" class="btn btn-success" value="แก้ไข">
					</div>
				</div>

			</fieldset>
		</form>
	</div>
</div>

@endsection