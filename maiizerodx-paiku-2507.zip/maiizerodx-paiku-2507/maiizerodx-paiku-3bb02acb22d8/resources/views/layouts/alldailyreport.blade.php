<!doctype html>
<html>

<head>
  <meta charset="utf-8">
  <title>DailyReport</title>
  <style type="text/css">
    body {
      width: 100%;
      height: 100%;
      margin: 0;
      padding: 0;
      background-color: #FAFAFA;
      font: 12pt "Tahoma";
    }

    * {
      box-sizing: border-box;
      -moz-box-sizing: border-box;
    }

    .page {
      width: 210mm;
      min-height: 297mm;
      padding: 5mm;
      margin: 5mm auto;
      border: 1px #D3D3D3 solid;
      border-radius: 5px;
      background: white;
      box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
    }

    .subpage {
      padding: .1cm;
      height: 287mm;
    }

    @page {
      size: A4;
      margin: 0;
    }

    @media print {

      html,
      body {
        width: 210mm;
        height: 297mm;
      }

      .page {
        margin: 0;
        border: initial;
        border-radius: initial;
        width: initial;
        min-height: initial;
        box-shadow: initial;
        background: initial;
        page-break-after: always;
      }
    }

    body,
    td,
    th {
      font-size: 10pt;
    }

    caption {
      font-size: 15pt;
      margin-bottom: 10px;
    }

    .tg {
      border-collapse: collapse;
      border-spacing: 0;
    }

    .tg td {
      font-size: 14px;
      padding: 4px;
      border-style: solid;
      border-width: 1px;
      overflow: hidden;
      word-break: normal;
      text-align: right;
    }

    .tg td:nth-child(2),
    .tg td:nth-child(4) {
      text-align: left;
      word-break: break-word;
    }

    .tg th {
      font-size: 14px;
      font-weight: bold;
      padding: 4px;
      border-style: solid;
      border-width: 1px;
      overflow: hidden;
      word-break: normal;
      text-align: center;
    }

    .tg .tg-yw4l {
      vertical-align: top
    }

    .total {
      font-weight: bold;
      text-align: center !important;
      background-color: #f2f2f2;
    }

    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .detail {
      text-align: left !important;
    }

    .title {
      font-size: 16px;
      font-weight: bold;
      text-align: center;
      flex-grow: 1;
    }
  </style>
</head>

<body>
  <div class="book">
    <div class="page">
      <div class="subpage">
        <div class="header">
          <div class="logo">
            <img src="{{ asset('images/phaiku-logo.png') }}" alt="Logo" style="width: 100px; height: auto;">
          </div>
          <div class="title">ใบรายงานการส่งเต้าหู้ประจำสายรถ ______</div>
          <div class="date">
            วันที่: {{ \App\ThaiFormat::shortdate(\Carbon\Carbon::now()) }}
          </div>
        </div>
        <table width="100%" border="1" cellpadding="2" cellspacing="0" class="tg">
          <tbody>
            <tr>
              <th width="40">ที่</th>
              <th scope="col" width="120">ตลาด</th>
              <th scope="col" width="50">รหัส</th>
              <th scope="col">รายชื่อ</th>
              <th width="45" scope="col">เต้าหู้<br>ขาว</th>
              <th width="45" scope="col">เต้าหู้<br>เหลือง</th>
              <th width="55" scope="col">เต้าหู้<br>กระดาน</th>
              <th width="45" scope="col">เต้าหู้<br>พวง</th>
              <th width="45" scope="col">เต้าหู้<br>นิ่ม</th>
              <th width="60" scope="col">เส้นเล็ก<br>ดอกบัว</th>
              <th width="50" scope="col">วุ้นเส้น<br>กิเลน</th>
            </tr>
            <tr>
              <th>1</th>
              <td>ตลาดทรัพย์สินมหากษัตริย์</td>
              <td>001</td>
              <td>ร้านน้องฟิล์ม</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
            </tr>
            <tr>
              <td>2</td>
              <td>ตลาดนัด</td>
              <td>002</td>
              <td>บริษัท พีเค นู้ดเดิ้ล ช็อป จำกัด  สำนักงานใหญ่ </td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
            </tr>
            <tr>
              <td>3</td>
              <td>ตลาดนัด</td>
              <td>003</td>
              <td>ร้านเจ๊หมวย</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
            </tr>
            <tr>
              <td>4</td>
              <td>ตลาดนัด</td>
              <td>004</td>
              <td>ร้านสมชาย</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
            </tr>
            <tr>
              <td>5</td>
              <td>ตลาดนัด</td>
              <td>005</td>
              <td>ร้านเจ๊แดง</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
            </tr>
            <tr>
              <td>6</td>
              <td>ตลาดนัด</td>
              <td>006</td>
              <td>ร้านนายดำ</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
            </tr>
            <tr>
              <td>7</td>
              <td>ตลาดนัด</td>
              <td>007</td>
              <td>ร้านเจ๊อ้อย</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
            </tr>
            <tr>
              <td>8</td>
              <td>ตลาดนัด</td>
              <td>008</td>
              <td>ร้านป้าตุ้ม</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
            </tr>
            <tr>
              <td>9</td>
              <td>ตลาดนัด</td>
              <td>009</td>
              <td>ร้านนายแดง</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
            </tr>
            <tr>
              <td>10</td>
              <td>ตลาดนัด</td>
              <td>010</td>
              <td>ร้านเจ๊ติ๋ม</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
            </tr>
            <tr>
              <td>11</td>
              <td>ตลาดนัด</td>
              <td>011</td>
              <td>ร้านป้าหวาน</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
            </tr>
            <tr>
              <td>12</td>
              <td>ตลาดนัด</td>
              <td>012</td>
              <td>ร้านสมปอง</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
            </tr>
            <tr>
              <td>13</td>
              <td>ตลาดนัด</td>
              <td>013</td>
              <td>ร้านเจ๊หน่อย</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
            </tr>
            <tr>
              <td>14</td>
              <td>ตลาดนัด</td>
              <td>014</td>
              <td>ร้านนายเขียว</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
            </tr>
            <tr>
              <td>15</td>
              <td>ตลาดนัด</td>
              <td>015</td>
              <td>ร้านป้าสมพร</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
            </tr>
            <tr>
              <td>16</td>
              <td>ตลาดนัด</td>
              <td>016</td>
              <td>ร้านเจ๊น้อย</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
            </tr>
            <tr>
              <td>17</td>
              <td>ตลาดนัด</td>
              <td>017</td>
              <td>ร้านนายขาว</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
            </tr>
            <tr>
              <td>18</td>
              <td>ตลาดนัด</td>
              <td>018</td>
              <td>ร้านป้าดวง</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
            </tr>
            <tr>
              <td>19</td>
              <td>ตลาดนัด</td>
              <td>019</td>
              <td>ร้านเจ๊จันทร์</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
            </tr>
            <tr>
              <td>20</td>
              <td>ตลาดนัด</td>
              <td>020</td>
              <td>ร้านนายทอง</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
            </tr>
            <tr>
              <td>21</td>
              <td>ตลาดนัด</td>
              <td>021</td>
              <td>ร้านป้าสายฝน</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
            </tr>
            <tr>
              <td>22</td>
              <td>ตลาดนัด</td>
              <td>022</td>
              <td>ร้านเจ๊นิด</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
            </tr>
            <tr>
              <td>23</td>
              <td>ตลาดนัด</td>
              <td>023</td>
              <td>ร้านนายฟ้า</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
            </tr>
            <tr>
              <td>24</td>
              <td>ตลาดนัด</td>
              <td>024</td>
              <td>ร้านป้าดา</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
            </tr>
            <tr>
              <td>25</td>
              <td>ตลาดนัด</td>
              <td>025</td>
              <td>ร้านเจ๊อร</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
            </tr>
            <tr>
              <td>26</td>
              <td>ตลาดนัด</td>
              <td>026</td>
              <td>ร้านนายชม</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
            </tr>
            <tr>
              <td>27</td>
              <td>ตลาดนัด</td>
              <td>027</td>
              <td>ร้านป้าสายใจ 2</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
            </tr>
            <tr>
              <td>28</td>
              <td>ตลาดนัด</td>
              <td>028</td>
              <td>ร้านเจ๊น้อย 2</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
            </tr>
            <tr>
              <td>29</td>
              <td>ตลาดนัด</td>
              <td>029</td>
              <td>ร้านนายแดง 2</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
            </tr>
            <tr>
              <td>30</td>
              <td>ตลาดนัด</td>
              <td>030</td>
              <td>ร้านป้าสมพร 2</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
            </tr>
            
            <tr>
              <td colspan="4" class="total">สรุปยอด</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    <div class="page">
      <div class="subpage">
        <div class="header">
          <div class="logo">
            <img src="{{ asset('images/phaiku-logo.png') }}" alt="Logo" style="width: 100px; height: auto;">
          </div>
          <div class="title">ใบรายงานการส่งถั่วงอกประจำสายรถ ______</div>
          <div class="date">
            วันที่: {{ \App\ThaiFormat::shortdate(\Carbon\Carbon::now()) }}
          </div>
        </div>
        <table width="100%" border="1" cellpadding="2" cellspacing="0" class="tg">
          <tbody>
            <tr>
              <th scope="col" rowspan="2" width="30">ที่</th>
              <th scope="col" rowspan="2" width="120">ตลาด</th>
              <th scope="col" rowspan="2" width="50">รหัส</th>
              <th scope="col" rowspan="2">รายชื่อ</th>
              <th scope="colgroup" colspan="5">ถั่วงอก</th>
              <th scope="col" rowspan="2" width="130">หมายเหตุ</th>
            </tr>
            <tr>
              <th scope="col" width="55">1 kg</th>
              <th scope="col" width="55">5 kg</th>
              <th scope="col" width="55">10 kg</th>
              <th scope="col" width="55">มัดปาก</th>
              <th scope="col" width="70">ซีนไม่สูญญากาศ</th>
            </tr>
            <tr>
              <td>1</td>
              <td>ตลาดนัด</td>
              <td>001</td>
              <td>ร้านน้องฟิล์ม</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>{{ rand(10, 90) }}</td>
              <td>Lorem, quam debitis saepe.</td>
            </tr>
            
            <tr>
              <td colspan="4" class="total">สรุปยอด</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    <div class="page">
      <div class="subpage">
        <div class="header">
          <div class="logo">
            <img src="{{ asset('images/phaiku-logo.png') }}" alt="Logo" style="width: 100px; height: auto;">
          </div>
          <div class="title">ใบรายงานการส่งถั่วถังและตะกร้าประจำสายรถ ______</div>
          <div class="date">
            วันที่: {{ \App\ThaiFormat::shortdate(\Carbon\Carbon::now()) }}
          </div>
        </div>
        <table width="100%" border="1" cellpadding="2" cellspacing="0" class="tg">
          <tbody>
            <tr>
              <th scope="col">ที่</th>
              <th scope="col">ตลาด</th>
              <th scope="col">รหัส<br>ลูกค้า</th>
              <th scope="col">รายชื่อ</th>
              <th scope="col" width="45">ถั่วถัง</th>
              <th scope="col" width="120">น้ำหนัก</th>
              <th scope="col" width="50">ถั่วตะกร้า</th>
              <th scope="col" width="120">น้ำหนัก</th>
              <th scope="col" width="80">หมายเหตุ</th>
            </tr>
            <tr>
              <td>1</td>
              <td>ตลาดนัด</td>
              <td>001</td>
              <td>ร้านน้องฟิล์ม</td>
              <td>7</td>
              <td class="detail">
                {{ rand(50, 55) }}.{{ rand(50, 55) }}.{{ rand(50, 55) }}.{{ rand(50, 55) }}.{{ rand(50, 55) }}
                {{ rand(50, 55) }}.{{ rand(50, 55) }}
              </td>
              <td>-</td>
              <td>-</td>
              <td>lorem</td>
            </tr>
            <tr>
              <td>2</td>
              <td>ตลาดนัด</td>
              <td>002</td>
              <td>ร้านป้าสายใจ</td>
              <td>-</td>
              <td>-</td>
              <td>7</td>
              <td class="detail">
                {{ rand(20,27) }}.{{ rand(20,27) }}.{{ rand(20,27) }}.{{ rand(20,27) }}.{{ rand(20,27) }}
                {{ rand(20,27) }}.{{ rand(20,27) }}
              </td>
              <td>-</td>
            </tr>
            <tr>
              <td>3</td>
              <td>ตลาดนัด</td>
              <td>003</td>
              <td>ร้านเจ๊หมวย</td>
              <td>5</td>
              <td class="detail">
                {{ rand(20,27) }}.{{ rand(20,27) }}.{{ rand(20,27) }}.{{ rand(20,27) }}.{{ rand(20,27) }}
                {{ rand(20,27) }}.{{ rand(20,27) }}
              </td>
              <td>-</td>
              <td>-</td>
              <td>-</td>
            </tr>
            <tr>
              <td>4</td>
              <td>ตลาดนัด</td>
              <td>004</td>
              <td>ร้านสมชาย</td>
              <td>-</td>
              <td>-</td>
              <td>5</td>
              <td class="detail">
                {{ rand(20,27) }}.{{ rand(20,27) }}.{{ rand(20,27) }}.{{ rand(20,27) }}.{{ rand(20,27) }}
                {{ rand(20,27) }}.{{ rand(20,27) }}
              </td>
              <td>-</td>
            </tr>
            <tr>
              <td colspan="4" class="total">สรุปยอด</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</body>

</html>