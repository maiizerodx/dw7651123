<!doctype html>
<html>

<head>
  <meta charset="utf-8">
  <title>DailyReport</title>
  <style type="text/css">
    body {
      width: 100%;
      height: 100%;
      margin: 0;
      padding: 0;
      background-color: #FAFAFA;
      font: 12pt "Tahoma";
    }

    * {
      box-sizing: border-box;
      -moz-box-sizing: border-box;
    }

    .page {
      width: 210mm;
      min-height: 297mm;
      padding: 5mm;
      margin: 5mm auto;
      border: 1px #D3D3D3 solid;
      border-radius: 5px;
      background: white;
      box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
    }

    .subpage {
      padding: .1cm;
      height: 287mm;
    }

    @page {
      size: A4;
      margin: 0;
    }

    @media print {

      html,
      body {
        width: 210mm;
        height: 297mm;
      }

      .page {
        margin: 0;
        border: initial;
        border-radius: initial;
        width: initial;
        min-height: initial;
        box-shadow: initial;
        background: initial;
        page-break-after: always;
      }
    }

    body,
    td,
    th {
      font-size: 10pt;
    }

    tr{
      height: 45px;
    }

    caption {
      font-size: 15pt;
      margin-bottom: 10px;
    }

    .tg {
      border-collapse: collapse;
      border-spacing: 0;
    }

    .tg td {
      font-size: 14px;
      padding: 4px;
      border-style: solid;
      border-width: 1px;
      overflow: hidden;
      word-break: normal;
      text-align: right;
    }

    .tg td:nth-child(2),
    .tg td:nth-child(4) {
      text-align: left;
      word-break: break-word;
    }

    .tg th {
      font-size: 14px;
      font-weight: bold;
      padding: 4px;
      border-style: solid;
      border-width: 1px;
      overflow: hidden;
      word-break: normal;
      text-align: center;
    }

    .tg .tg-yw4l {
      vertical-align: top
    }

    .total {
      font-weight: bold;
      text-align: center !important;
      background-color: #f2f2f2;
    }

    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .detail {
      text-align: left !important;
    }

    .title {
      font-size: 16px;
      font-weight: bold;
      text-align: center;
      flex-grow: 1;
    }

    .logo> img {
      width: auto;
      height: 80px;
    }
  </style>
</head>

<body>
  <div class="book">
    @if(count($datas)>0)
    @php
      $itemsPerPage = 20;
      $totalPages = ceil(count($datas) / $itemsPerPage);
      $dataChunks = array_chunk($datas, $itemsPerPage);
    @endphp
    
    @foreach($dataChunks as $pageIndex => $pageData)
    <div class="page">
      <div class="subpage">
        <div class="header">
          <div class="logo">
            <img src="{{ asset('images/phaiku-logo.png') }}" alt="Logo">
          </div>
          <div class="title">ใบรายงานการส่งเต้าหู้ประจำสายรถ {{$car_name}}</div>
          <div class="date">
            วันที่: {{ $report_date }}<br>
            หน้า {{ $pageIndex + 1 }} / {{ $totalPages }}
          </div>
        </div>
        <table width="100%" border="1" cellpadding="2" cellspacing="0" class="tg">
          <tbody>
            <tr>
              <th width="40">ที่</th>
              <th scope="col" width="120">ตลาด</th>
              <th scope="col" width="50">รหัส</th>
              <th scope="col">รายชื่อ</th>
              <th width="45" scope="col">เต้าหู้<br>ขาว</th>
              <th width="45" scope="col">เต้าหู้<br>เหลือง</th>
              <th width="55" scope="col">เต้าหู้<br>กระดาน</th>
              <th width="45" scope="col">เต้าหู้<br>พวง</th>
              <th width="45" scope="col">เต้าหู้<br>นิ่ม</th>
              <th width="60" scope="col">เส้นเล็ก<br>ดอกบัว</th>
              <th width="50" scope="col">วุ้นเส้น<br>กิเลน</th>
            </tr>
            @php
              $count = ($pageIndex * $itemsPerPage) + 1;
            @endphp
            @foreach($pageData as $data)
            <tr>
              <th>{{$count++}}</th>
              <th>{{$data['market']}}</th>
              <td>{{$data['customer_id']}}</td>
              <td>{{$data['name']}}</td>
              <td align='center'>{{$data['p1']>0 ? $data['p1'] : '-'}}</td>
              <td align='center'>{{$data['p2']>0 ? $data['p2'] : '-'}}</td>
              <td align='center'>{{$data['p3']>0 ? $data['p3'] : '-'}}</td>
              <td align='center'>{{$data['p4']>0 ? $data['p4'] : '-'}}</td>
              <td align='center'>{{$data['p5']>0 ? $data['p5'] : '-'}}</td>
              <td align='center'>{{$data['p22']>0 ? $data['p22'] : '-'}}</td>
              <td align='center'>{{$data['p23']>0 ? $data['p23'] : '-'}}</td>
            </tr>
            @endforeach
            
            @if($pageIndex == $totalPages - 1)
            <tr>
              <td colspan="4" class="total">สรุปยอด</td>
              <td class="total">{{$total['p1']>0 ? number_format($total['p1'],0) : '-'}}</td>
              <td class="total">{{$total['p2']>0 ? number_format($total['p2'],0) : '-'}}</td>
              <td class="total">{{$total['p3']>0 ? number_format($total['p3'],0) : '-'}}</td>
              <td class="total">{{$total['p4']>0 ? number_format($total['p4'],0) : '-'}}</td>
              <td class="total">{{$total['p5']>0 ? number_format($total['p5'],0) : '-'}}</td>
              <td class="total">{{$total['p22']>0 ? number_format($total['p22'],0) : '-'}}</td>
              <td class="total">{{$total['p23']>0 ? number_format($total['p23'],0) : '-'}}</td>
            </tr>
            @endif
          </tbody>
        </table>
      </div>
    </div>
    @endforeach
    
    @foreach($dataChunks as $pageIndex => $pageData)
    <div class="page">
      <div class="subpage">
        <div class="header">
          <div class="logo">
            <img src="{{ asset('images/phaiku-logo.png') }}" alt="Logo">
          </div>
          <div class="title">ใบรายงานการส่งถั่วงอกประจำสายรถ  {{$car_name}}</div>
          <div class="date">
            วันที่: {{ $report_date }}<br>
            หน้า {{ $pageIndex + 1 }} / {{ $totalPages }}
          </div>
        </div>
        <table width="100%" border="1" cellpadding="2" cellspacing="0" class="tg">
          <tbody>
            <tr>
              <th scope="col" width="">ที่</th>
              <th scope="col" width="">ตลาด</th>
              <th scope="col" width="50">รหัส</th>
              <th scope="col" >รายชื่อ</th>
              <th scope="col" width="55">1 kg</th>
              <th scope="col" width="55">5 kg</th>
              <th scope="col" width="55">10 kg</th>
              <th scope="col" width="55">มัดปาก</th>
              <th scope="col" width="70">ซีนไม่สูญญากาศ</th>
            </tr>
            @php
              $count = ($pageIndex * $itemsPerPage) + 1;
            @endphp
            @foreach($pageData as $data)
            <tr>
              <th>{{$count++}}</th>
              <th>{{$data['market']}}</th>
              <td>{{$data['customer_id']}}</td>
              <td>{{$data['name']}}</td>
              <td align='center'>{{$data['p6']>0 ? $data['p6'] : '-'}}</td>
              <td align='center'>{{$data['p7']>0 ? $data['p7'] : '-'}}</td>
              <td align='center'>{{$data['p8']>0 ? $data['p8'] : '-'}}</td>
              <td align='center'>{{$data['p19']>0 ? $data['p19'] : '-'}}</td>
              <td align='center'>{{$data['p20']>0 ? $data['p20'] : '-'}}</td>
            </tr>
            @endforeach

            @if($pageIndex == $totalPages - 1)
            <tr>
              <td colspan="4" class="total">สรุปยอด</td>
              <td class="total">{{ $total['p6']>0 ? number_format($total['p6'],0) : '-' }}</td>
              <td class="total">{{ $total['p7']>0 ? number_format($total['p7'],0) : '-' }}</td>
              <td class="total">{{ $total['p8']>0 ? number_format($total['p8'],0) : '-' }}</td>
              <td class="total">{{ $total['p19']>0 ? number_format($total['p19'],0) : '-' }}</td>
              <td class="total">{{ $total['p20']>0 ? number_format($total['p20'],0) : '-' }}</td>
            </tr>
            @endif
          </tbody>
        </table>
      </div>
    </div>
    @endforeach
    
    @foreach($dataChunks as $pageIndex => $pageData)
      <div class="page">
        <div class="subpage">
          <div class="header">
            <div class="logo">
              <img src="{{ asset('images/phaiku-logo.png') }}" alt="Logo">
            </div>
            <div class="title">ใบรายงานการส่งถั่วถังและตะกร้าประจำสายรถ  {{$car_name}}</div>
            <div class="date">
              วันที่: {{ $report_date }}<br>
              หน้า {{ $pageIndex + 1 }} / {{ $totalPages }}
            </div>
          </div>
          <table width="100%" border="1" cellpadding="2" cellspacing="0" class="tg">
            <tbody>
              <tr>
                <th scope="col">ที่</th>
                <th scope="col">ตลาด</th>
                <th scope="col">รหัส<br>ลูกค้า</th>
                <th scope="col">รายชื่อ</th>
                <th scope="col" width="45">ถั่วถัง</th>
                <th scope="col" width="120">น้ำหนัก</th>
                <th scope="col" width="50">ถั่วตะกร้า</th>
                <th scope="col" width="120">น้ำหนัก</th>
              </tr>
              @php
              $count = ($pageIndex * $itemsPerPage) + 1;
            @endphp
            @foreach($pageData as $data)
            <tr>
              <th>{{$count++}}</th>
              <th>{{$data['market']}}</th>
              <td>{{$data['customer_id']}}</td>
              <td>{{$data['name']}}</td>
              <td align='center'>{{$data['bucket_num']>0 ? $data['bucket_num'] : '-'}}</td>
              <td align='center'>{{$data['bucket_list']>0 ? $data['bucket_list'] : '-'}}</td>
              <td align='center'>{{$data['basket_num']>0 ? $data['basket_num'] : '-'}}</td>
              <td align='center'>{{$data['basket_list']>0 ? $data['basket_list'] : '-'}}</td>
            </tr>
            @endforeach
            @if($pageIndex == $totalPages - 1)
              <tr>
                <td colspan="4" class="total">สรุปยอด</td>
                <td class="total">{{ $total['bucket_num']>0 ? number_format($total['bucket_num'],0) : '-' }}</td>
                <td class="total">{{ $total['bucket_weight']>0 ? number_format($total['bucket_weight'],0) : '-' }}</td>
                <td class="total">{{ $total['basket_num']>0 ? number_format($total['basket_num'],0) : '-' }}</td>
                <td class="total">{{ $total['basket_weight']>0 ? number_format($total['basket_weight'],0) : '-' }}</td>
              </tr>
            @endif
            </tbody>
          </table>
        </div>
      </div>
    @endforeach
    @endif

</body>

</html>