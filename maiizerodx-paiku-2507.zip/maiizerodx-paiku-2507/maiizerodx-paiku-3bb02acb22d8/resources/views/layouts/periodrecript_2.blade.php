<!doctype html>
<html>

<head>
  <meta charset="utf-8">
  <title>ใบวางบิล/บิลเงินสด รายบุคคล ตามช่วงเวลา</title>
  <style type="text/css">
    @import url('https://fonts.googleapis.com/css2?family=Sarabun:wght@400;500;700&display=swap');

    body {
      background: rgb(204, 204, 204);
    }

    page {
      background: white;
      display: block;
      margin: 0 auto;
      margin-bottom: 0.5cm;
      box-shadow: 0 0 0.5cm rgba(0, 0, 0, 0.5);
      font-family: 'Sarabun', sans-serif;
    }

    page[size="A4"] {
      width: 21cm;
      height: 29.7cm;
    }

    page[size="A4"][layout="portrait"] {
      width: 29.7cm;
      height: 21cm;
    }

    page[size="A5"] {
      width: 14.8cm;
      height: 21cm;
    }

    page[size="A5"][layout="portrait"] {
      width: 21cm;
      height: 14.8cm;
    }

    @media print {

      body,
      page {
        margin: 0;
        box-shadow: 0;
      }
    }

    .container {
      background-color: white;
      width: 210mm;
      height: 148mm;
      box-sizing: border-box;
      padding: 8mm;
      margin: auto;
      box-shadow: 0 0 15px rgba(0, 0, 0, 0.05);
      display: flex;
      flex-direction: column;
      gap: 12px;
    }

    /* --- Header --- */
    .header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      border-bottom: 2px solid #e5e7eb;
      padding-bottom: 12px;
    }

    .customer-info>.name {
      flex: 1;
      font-size: 14px;
      color: #374151;
      word-wrap: break-word;
    }

    .customer-info p {
      font-size: 12px;
      margin: 0 20px 0 0;
      line-height: 1.5;
    }

    .invoice-details {
      text-align: right;
      width: 300px;
    }

    .invoice-details h2 {
      font-size: 16px;
      font-weight: 600;
      margin: 0;
    }

    .invoice-details p {
      font-size: 12px;
      margin: 4px 0 0;
    }

    /* --- Bill To & Date --- */
    .meta-info {
      display: flex;
      justify-content: space-between;
      font-size: 12px;
    }

    .bill-to h3,
    .date-info h3 {
      font-weight: 600;
      font-size: 12px;
      margin: 0 0 4px 0;
      color: #374151;
    }

    .bill-to p,
    .date-info p {
      margin: 0;
    }


    /* --- Table --- */
    .expense-table {
      width: 100%;
      border-collapse: collapse;
      font-size: 12px;
    }

    .expense-table th,
    .expense-table td {
      border: 1px solid #e5e7eb;
      padding: 4px 8px;
      text-align: center;
    }

    .expense-table thead {
      background-color: #f3f4f6;
    }

    .expense-table th {
      font-weight: 600;
      font-size: 11px;
      color: #374151;
    }

    .expense-table .category {
      text-align: left;
      font-weight: 500;
    }

    .expense-table .amount {
      text-align: right;
    }

    .expense-table tbody tr:nth-child(even) {
      background-color: #f9fafb;
    }

    /* --- Total --- */
    .total-section {
      display: flex;
      justify-content: flex-end;
    }

    .total-box {
      border: 1px solid #0e4813;
      padding: 8px;
      font-size: 14px;
      font-weight: bold;
      background-color: #eff6ff;
      color: #0e4813;
      border-radius: 6px;
      min-width: 200px;
      text-align: right;
    }

    .total-label {
      margin-right: 12px;
      align-self: center;
      font-weight: 600;
    }


    /* --- Bottom Section --- */
    .bottom-section {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 12px;
      font-size: 11px;
      padding-top: 12px;
      border-top: 1px solid #e5e7eb;
    }

    .info-card {
      background-color: #f9fafb;
      padding: 12px;
      border: 1px solid #e5e7eb;
      border-radius: 6px;
    }

    .info-card h3 {
      font-size: 12px;
      font-weight: 600;
      margin: 0 0 8px 0;
      border-bottom: 1px solid #e5e7eb;
      padding-bottom: 6px;
    }

    .info-card p {
      margin: 0 0 4px 0;
      line-height: 1.6;
    }

    .contact-info {
      display: flex;
      gap: 12px;
      justify-content: space-between;
    }

    .qr-code {
      flex-shrink: 0;
    }

    .qr-placeholder {
      width: 60px;
      height: 60px;
      border: 1px solid #d1d5db;
      border-radius: 4px;
    }

    .qr-placeholder svg {
      width: 100%;
      height: 100%;
    }


    /* --- Signature --- */
    .signature-section {
      font-size: 12px;
      text-align: right;
      margin-top: 20px;
      padding-top: 20px;
    }

    .signature-line {
      border-bottom: 1px dotted #6b7280;
      width: 200px;
      display: inline-block;
      margin-right: 5px;
    }
  </style>
</head>

<body>
  <?php
if(!isset($orderDatas))
{
  echo 'NO DATA';
  $countdate = 0;
}
else
{
  $countdate = count($orderDatas);
  $maxDatePerPage = 7;
  $startPage = 1;
}
?>
  @if($countdate > 0)
  {{-- New design --}}
  @if($total['tofu_price'] > 0)
  <page size="A5" layout="portrait">
    <div class="container">
      <header class="header">
        <div class="customer-info">
          <strong>ชื่อลูกค้า:</strong>{{ $header['name'] }} - {{$header['market']}}
          <p>
            <strong>ที่อยู่:</strong> {{ $header['address'] }}
          </p>
        </div>
        <div class="invoice-details">
          <h2>ใบวางบิล / บิลเงินสด(เต้าหู้)</h2>
          <p><strong>รอบบิล:</strong> {{$header['startDate']}} - {{$header['endDate']}}</p>
        </div>
      </header>

      <table class="expense-table">
        <thead>
          <tr>
            <th class="category">รายการ/วันที่</th>
            @for($i = 0; $i < 7; $i++) <th>@if(isset($orderDatas[$i])){{ $orderDatas[$i]['date']}}@else - @endif</th>
              @endfor
              <th>รวม</th>
              <th class="amount">จำนวนเงิน (บาท)</th>
          </tr>
        </thead>
        <tbody>
          @if($total['p1'] > 0)
          <tr>
            <td>ขาว</td>
            @for($i = 0; $i < 7; $i++) <td>
              @if(isset($orderDatas[$i]) && $orderDatas[$i]['p1'] > 0){{ $orderDatas[$i]['p1']}}@else - @endif</td>
              @endfor
              <td>{{ $total['p1']}}</td>
              <td>@if($total['p1_price'] > 0){{ number_format($total['p1_price'],2)}}@else - @endif</td>
          </tr>
          @endif
          @if($total['p2'] > 0)
          <tr>
            <td>เหลือง</td>
            @for($i = 0; $i < 7; $i++) <td>
              @if(isset($orderDatas[$i]) && $orderDatas[$i]['p2'] > 0){{ $orderDatas[$i]['p2']}}@else - @endif
              </td>
              @endfor
              <td>{{ $total['p2']}}</td>
              <td>@if($total['p2_price'] > 0){{ number_format($total['p2_price'],2)}}@else - @endif</td>
          </tr>
          @endif
          @if($total['p3'] > 0)
          <tr>
            <td>กระดาน</td>
            @for($i = 0; $i < 7; $i++) <td>
              @if(isset($orderDatas[$i]) && $orderDatas[$i]['p3'] > 0){{ $orderDatas[$i]['p3']}}@else - @endif
              </td>
              @endfor
              <td>{{ $total['p3']}}</td>
              <td>@if($total['p3_price'] > 0){{ number_format($total['p3_price'],2)}}@else - @endif</td>
          </tr>
          @endif
          @if($total['p4'] > 0)
          <tr>
            <td>พวง</td>
            @for($i = 0; $i < 7; $i++) <td>
              @if(isset($orderDatas[$i]) && $orderDatas[$i]['p4'] > 0){{ $orderDatas[$i]['p4']}}@else - @endif
              </td>
              @endfor
              <td>{{ $total['p4']}}</td>
              <td>@if($total['p4_price'] > 0){{ number_format($total['p4_price'],2)}}@else - @endif</td>
          </tr>
          @endif
          @if($total['p5'] > 0)
          <tr>
            <td>นิ่ม</td>
            @for($i = 0; $i < 7; $i++) <td>
              @if(isset($orderDatas[$i]) && $orderDatas[$i]['p5'] > 0){{ $orderDatas[$i]['p5']}}@else - @endif
              </td>
              @endfor
              <td>@if($total['p5'] > 0){{ $total['p5']}}@else - @endif</td>
              <td>@if($total['p5_price'] > 0){{ number_format($total['p5_price'],2)}}@else - @endif</td>
          </tr>
          @endif
          @if($total['p22'] > 0)
          <tr>
            <td>เส้นเล็ก ดอกบัว</td>
            @for($i = 0; $i < 7; $i++) <td>
              @if(isset($orderDatas[$i]) && $orderDatas[$i]['p22'] > 0){{ $orderDatas[$i]['p22']}}@else - @endif
              </td>
              @endfor
              <td>@if($total['p22'] > 0){{ $total['p22']}}@else - @endif</td>
              <td>@if($total['p22_price'] > 0){{ number_format($total['p22_price'],2)}}@else - @endif</td>
          </tr>
          @endif
          @if($total['p23'] > 0)
          <tr>
            <td>วุ้นเส้น กิเลน</td>
            @for($i = 0; $i < 7; $i++) <td>
              @if(isset($orderDatas[$i]) && $orderDatas[$i]['p23'] > 0){{ $orderDatas[$i]['p23']}}@else - @endif
              </td>
              @endfor
              <td>@if($total['p23'] > 0){{ $total['p23']}}@else - @endif</td>
              <td>@if($total['p23_price'] > 0){{ number_format($total['p23_price'],2)}}@else - @endif</td>
          </tr>
          @endif
        </tbody>
      </table>

      <section class="total-section">
        <span class="total-label">ยอดเงินสุทธิ:</span>
        <div class="total-box">{{ number_format($total['tofu_price'],2)}}</div>
      </section>

      <footer class="bottom-section">
        <div class="info-card">
          <h3>ช่องทางการโอนเงิน</h3>
          <p>
            <strong>ธนาคาร:</strong> {{ $header['payment_tofu']['bank'] }}<br>
            <strong>ชื่อบัญชี:</strong> {{ $header['payment_tofu']['name'] }}<br>
            <strong>เลขที่บัญชี:</strong> {{ $header['payment_tofu']['account'] }}
          </p>
        </div>
        <div class="info-card">
          <h3>ช่องทางการติดต่อ</h3>
          <div class="contact-info">
            <p>
              <strong>ID Line:</strong> phiku_59<br>
              <strong>โทร:</strong> 081-9427250
            </p>
            <div class="qr-code">
              <div class="qr-placeholder">
                <img src="{{ asset('images/qr_line.png') }}" alt="QR Code Placeholder"
                  style="width: 100%; height: 100%;">
              </div>
            </div>
          </div>
        </div>
        <div class="info-card">
          <h3>ผู้รับเงิน</h3>
          <div class="signature-section" style="text-align:left; margin-top:10px; padding-top:10px;">
            <span class="signature-line" style="width: 100%; display:block;"></span>
            <p style="margin-top: 5px;">(.....................................................)</p>
          </div>
        </div>
      </footer>
    </div>
  </page>
  @endif
    @if($total['bean_price'] > 0)
    {{-- Bean Bill --}}
    <page size="A5" layout="portrait">
      <div class="container">
        <header class="header">
          <div class="customer-info">
            <strong>ชื่อลูกค้า:</strong>{{ $header['name'] }} - {{$header['market']}}
            <p>
              <strong>ที่อยู่:</strong> {{ $header['address'] }}
            </p>
          </div>
          <div class="invoice-details">
            <h2>ใบวางบิล / บิลเงินสด(ถั่วงอก)</h2>
            <p><strong>รอบบิล:</strong> {{$header['startDate']}} - {{$header['endDate']}}</p>
          </div>
        </header>

        <table class="expense-table">
          <thead>
            <tr>
              <th colspan="2" class="category">รายการ/วันที่</th>
              @for($i = 0; $i < 7; $i++) <th>@if(isset($orderDatas[$i])){{ $orderDatas[$i]['date']}}@else - @endif</th>
                @endfor
                <th>รวม</th>
                <th class="amount">จำนวนเงิน (บาท)</th>
            </tr>
          </thead>
          <tbody>
            @if($total['p6'] > 0)
            <tr>
              <td colspan="2">ถั่วงอก 1 kg</td>
              @for($i = 0; $i < 7; $i++) <td>
                @if(isset($orderDatas[$i]) && $orderDatas[$i]['p6'] > 0){{ $orderDatas[$i]['p6']}}@else - @endif
                </td>
                @endfor
                <td>{{ $total['p6']}}</td>
                <td>@if($total['p6_price'] > 0){{ number_format($total['p6_price'],2)}}@else - @endif</td>
            </tr>
            @endif
            @if($total['p7'] > 0)
            <tr>
              <td colspan="2">ถั่วงอก 5 kg</td>
              @for($i = 0; $i < 7; $i++) <td>
                @if(isset($orderDatas[$i]) && $orderDatas[$i]['p7'] > 0){{ $orderDatas[$i]['p7']}}@else - @endif
                </td>
                @endfor
                <td>{{ $total['p7']}}</td>
                <td>@if($total['p7_price'] > 0){{ number_format($total['p7_price'],2)}}@else - @endif</td>
            </tr>
            @endif
            @if($total['p8'] > 0)
            <tr>
              <td colspan="2">ถั่วงอก 10 kg</td>
              @for($i = 0; $i < 7; $i++) <td>
                @if(isset($orderDatas[$i]) && $orderDatas[$i]['p8'] > 0){{ $orderDatas[$i]['p8']}}@else - @endif
                </td>
                @endfor
                <td>{{ $total['p8']}}</td>
                <td>@if($total['p8_price'] > 0){{ number_format($total['p8_price'],2)}}@else - @endif</td>
            </tr>
            @endif
            @if($total['p19'] > 0)
            <tr>
              <td colspan="2">มัดปาก</td>
              @for($i = 0; $i < 7; $i++) <td>
                @if(isset($orderDatas[$i]) && $orderDatas[$i]['p19'] > 0){{ $orderDatas[$i]['p19']}}@else - @endif
                </td>
                @endfor
                <td>{{ $total['p19']}}</td>
                <td>@if($total['p19_price'] > 0){{ number_format($total['p19_price'],2)}}@else - @endif</td>
            </tr>
            @endif
            @if($total['p20'] > 0)
            <tr>
              <td colspan="2">ซีนไม่สูญญากาศ</td>
              @for($i = 0; $i < 7; $i++) <td>
                @if(isset($orderDatas[$i]) && $orderDatas[$i]['p20'] > 0){{ $orderDatas[$i]['p20']}}@else - @endif
                </td>
                @endfor
                <td>{{ $total['p20']}}</td>
                <td>@if($total['p20_price'] > 0){{ number_format($total['p20_price'],2)}}@else - @endif</td>
            </tr>
            @endif
            @if($total['bucket_num'] > 0)
            <tr>
              <td rowspan="3">ถั่วถัง</td>
              <td>จน.</td>
              @for($i = 0; $i < 7; $i++) <td>
                @if(isset($orderDatas[$i]) && $orderDatas[$i]['bucket_num'] > 0){{ $orderDatas[$i]['bucket_num']}}@else -
                @endif
                </td>
                @endfor
                <td>{{ $total['bucket_num']}}</td>
                <td>-</td>
            </tr>
            <tr>
              <td>ถัง</td>
              @for($i = 0; $i < 7; $i++) <td>
                @if(isset($orderDatas[$i]) && $orderDatas[$i]['bucket_list'] > 0)
                {{ $orderDatas[$i]['bucket_list']}}
                @else - @endif
                </td>
                @endfor
                <td>-</td>
                <td>-</td>
            </tr>
            <tr>
              <td>นน.รวม</td>
              @for($i = 0; $i < 7; $i++) <td>
                @if(isset($orderDatas[$i]) && $orderDatas[$i]['bucket_total'] > 0){{
                $orderDatas[$i]['bucket_total']}}@else - @endif
                </td>
                @endfor
                <td>@if($total['bucket_weight'] > 0){{ number_format($total['bucket_weight'],2)}}@else - @endif</td>
                <td>@if($total['bucket_price'] > 0){{ number_format($total['bucket_price'],2)}}@else - @endif</td>
            </tr>
            @endif
            @if($total['basket_num'] > 0)
            <tr>
              <td rowspan="3">ถั่วตะกร้า</td>
              <td>จน.</td>
              @for($i = 0; $i < 7; $i++) <td>
                @if(isset($orderDatas[$i]) && $orderDatas[$i]['basket_num'] > 0){{ $orderDatas[$i]['basket_num']}}@else -
                @endif
                </td>
                @endfor
                <td>{{ $total['basket_num']}}</td>
                <td>-</td>
            </tr>
            <tr>
              <td>ตะกร้า</td>
              @for($i = 0; $i < 7; $i++) <td>
                @if(isset($orderDatas[$i]) && $orderDatas[$i]['basket_list'] > 0)
                {{ $orderDatas[$i]['basket_list']}}
                @else - @endif
                </td>
                @endfor
                <td>-</td>
                <td>-</td>
            </tr>
            <tr>
              <td>นน.รวม</td>
              @for($i = 0; $i < 7; $i++) <td>
                @if(isset($orderDatas[$i]) && $orderDatas[$i]['basket_total'] > 0){{
                $orderDatas[$i]['basket_total']}}@else - @endif
                </td>
                @endfor
                <td>@if($total['basket_weight'] > 0){{ number_format($total['basket_weight'],2)}}@else - @endif</td>
                <td>@if($total['basket_price'] > 0){{ number_format($total['basket_price'],2)}}@else - @endif</td>
            </tr>
            @endif
          </tbody>
        </table>

        <section class="total-section">
          <span class="total-label">ยอดเงินสุทธิ:</span>
          <div class="total-box">{{ number_format($total['bean_price'],2)}}</div>
        </section>

        <footer class="bottom-section">
          <div class="info-card">
            <h3>ช่องทางการโอนเงิน</h3>
            <p>
              <strong>ธนาคาร:</strong> {{ $header['payment_bean']['bank'] }}<br>
              <strong>ชื่อบัญชี:</strong> {{ $header['payment_bean']['name'] }}<br>
              <strong>เลขที่บัญชี:</strong> {{ $header['payment_bean']['account'] }}
            </p>
          </div>
          <div class="info-card">
            <h3>ช่องทางการติดต่อ</h3>
            <div class="contact-info">
              <p>
                <strong>ID Line:</strong> phiku_59<br>
                <strong>โทร:</strong> 081-9427250
              </p>
              <div class="qr-code">
                <div class="qr-placeholder">
                  <img src="{{ asset('images/qr_line.png') }}" alt="QR Code Placeholder"
                    style="width: 100%; height: 100%;">
                </div>
              </div>
            </div>
          </div>
          <div class="info-card">
            <h3>ผู้รับเงิน</h3>
            <div class="signature-section" style="text-align:left; margin-top:10px; padding-top:10px;">
              <span class="signature-line" style="width: 100%; display:block;"></span>
              <p style="margin-top: 5px;">(.....................................................)</p>
            </div>
          </div>
        </footer>
      </div>
    </page>
    @endif
  @endif

</body>

</html>