<!DOCTYPE html>
<html lang="th">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <meta charset="utf-8">
        <meta name="generator" content="Bootply" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

        <!--[if lt IE 9]>
            <script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->

        <!-- CSRF Token -->
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>{{ config('app.name', 'Laravel') }}</title>

        <!-- Styles -->
        <link href="{{ asset('css/bootstrap.min.css') }}" rel="stylesheet" />
        <!--<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">-->
        <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> -->
        <link href="{{ asset('css/styles.css') }}" rel="stylesheet">
        <link href="{{ asset('css/fontawesome-all.css') }}" rel="stylesheet">
        @stack('styles')

        <!-- Scripts -->
        <script>
            window.Laravel = <?php echo json_encode([
                'csrfToken' => csrf_token(),
            ]); ?>
        </script>

    </head>
    <body>

    {{-- {{setlocale(LC_ALL,'TH')}} --}}
<!-- header -->
<div id="top-nav" class="navbar navbar-inverse navbar-static-top">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="{{ url('/') }}">{{ config('app.name', 'Laravel') }}</a>
        </div>
        <div class="navbar-collapse collapse">
            <ul class="nav navbar-nav navbar-right">
                @if (Auth::user())
                    <li class="dropdown">
                        <a class="dropdown-toggle" role="button" data-toggle="dropdown" href="{{ url('/users/'.Auth::user()->id) }}"><i class="glyphicon glyphicon-user"></i>สวัสดี, {{ Auth::user()->firstname }}<!-- <span class="caret"></span> --></a>
                        {{--<ul id="g-account-menu" class="dropdown-menu" role="menu">
                            <li><a href="#">ข้อมูลส่วนตัว</a></li>
                        </ul>--}}
                    </li>
                    <li>
                        <a href="{{ url('/logout') }}"
                            onclick="event.preventDefault();
                                     document.getElementById('logout-form').submit();">
                            <i class="glyphicon glyphicon-lock"></i> ออกจากระบบ
                        </a>
                        <form id="logout-form" action="{{ url('/logout') }}" method="POST" style="display: none;">
                            {{ csrf_field() }}
                        </form>
                    </li>
                @endif
            </ul>
        </div>
    </div>
    <!-- /container -->
</div>
<!-- /Header -->

<!-- Main -->
<div class="container-fluid">
    <div class="row">
        <div class="col-sm-2">
            <!-- Left column -->
            <a href="{{ url('/') }}"><strong><i class="glyphicon glyphicon-home"></i> หน้าแรก</strong></a>
            <hr>
            <strong><i class="glyphicon glyphicon-list"></i> จัดการข้อมูล</strong>
            <!-- <hr> -->
            <ul class="nav nav-pills nav-stacked">
                <!-- <li class="nav-header"></li>
                <span class="badge badge-info">2</span> -->
                <li><a href="{{ url('/customers') }}"><i class="glyphicon glyphicon-user"></i> ข้อมูลลูกค้า</a></li>
                <li><a href="{{ url('/cars') }}"><i class="fa fa-car fa-lg"></i> ข้อมูลรถส่งของ</a></li>
                <li><a href="{{ url('/markets') }}"><i class="fa fa-shopping-cart fa-lg"></i> ข้อมูลตลาด</a></li>
                <li><a href="{{ url('/products') }}"><i class="glyphicon glyphicon-apple"></i> ข้อมูลสินค้า</a></li>
                <li><a href="{{ url('/orders') }}"><i class="fa fa-table fa-lg"></i> ข้อมูลการสั่งซื้อ</a></li>
            </ul>

            <hr>
            <strong><i class="glyphicon glyphicon-list"></i> สรุปรายงาน</strong>
            <!-- <hr> -->
            <ul class="nav nav-pills nav-stacked">
                <!-- <li class="nav-header"></li> -->
                <li><a href="{{ url('/reports') }}"><i class="far fa-file-alt fa-lg"></i> รายการส่งของ</a></li>
            </ul>
            <hr>
            @if(Auth::user()->role_id >= 3 )
            <strong><i class="glyphicon glyphicon-list"></i> ระบบบัญชี</strong>
            <!-- <hr> -->
            <ul class="nav nav-pills nav-stacked">
                <li><a href="{{ url('/billings') }}"><i class="fa fa-table fa-lg"></i> ข้อมูลใบวางบิล</a></li>
                <li><a href="{{ url('/receipts') }}"><i class="fa fa-table fa-lg"></i> ข้อมูลใบเสร็จรับเงิน</a></li>
                <li><a href="{{ url('/transactions') }}"><i class="fa fa-table fa-lg"></i> ข้อมูลธุรกรรม</a></li>

                <!-- <li class="nav-header"></li>
                <span class="badge badge-info">2</span> -->
                <!-- <li><a href="{{ url('/billings') }}"><i class="fa fa-file-text-o fa-lg"></i> สร้างใบแจ้งหนี้</a></li> -->
                <li><a href="{{ url('/receipts/filter') }}"><i class="far fa-file-alt fa-lg"></i> รายงานใบเสร็จรับเงิน</a></li>
                <li><a href="{{ url('/transactions/list/transfer') }}"><i class="far fa-file-alt fa-lg"></i> รายงานสถานะการโอนเงิน</a></li>
                <li><a href="{{ url('/transactions/list/cheque') }}"><i class="far fa-file-alt fa-lg"></i> รายงานสถานะเช็ค</a></li>
                <li><a href="{{ url('/reports/account') }}"><i class="far fa-file-alt fa-lg"></i> รายงานสรุปบัญชี</a></li>
            </ul>
            <hr>
            @endif

            {{-- @if(Auth::user()->role_id == 9)
                 Admin Zone  
                 <strong><i class="glyphicon glyphicon-list"></i> แถบเครื่องมือผู้ดูแล</strong>
                 <!-- <hr> -->
                 <ul class="nav nav-pills nav-stacked">
                     <li class="nav-header"></li>
                    <li><a href="#"><i class="fa fa-user-plus"></i> เพิ่มผู้ใช้งาน</a></li>
                     <li><a href="#"><i class="fas fa-pencil-alt"></i> แก้ไข/ลบ ผู้ใช้งาน</a></li>
                     <li><a href="#"><i class="fa fa-users"></i> จัดกลุ่มผู้ใช้งาน</a></li>
                 </ul>
                 END Admin Zone
             @endif--}}

        </div>
        <!-- /col-3 -->
        <div class="col-sm-10">
            @include('flash-message')
            @yield('content')
        </div>
        <!--/col-span-9-->
    </div>
</div>
<!-- /Main -->

<footer class="footer text-center">
    Release Version 1.6 [2025-07]
</footer>
<!-- /.modal -->
    <!-- script references -->
        <!-- <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script> -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

        <script src="{{ asset('js/bootstrap.min.js') }}"></script>
        <!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script> -->
        @stack('script')
    </body>
</html>
