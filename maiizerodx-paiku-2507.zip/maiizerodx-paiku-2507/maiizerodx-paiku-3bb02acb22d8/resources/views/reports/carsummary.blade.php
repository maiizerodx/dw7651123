@extends('layouts.app')

@push('styles')
<link rel="stylesheet" href="{{ asset('jquery-ui-themes-1.12.1/themes/base/jquery-ui.css') }}">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="css/bootstrap-select.min.css">
<style>
    .header {
        text-align: center;
        margin-bottom: 20px;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    .header .logo img {
        width: 100px;
        height: auto;
    }

    .header .title {
        font-size: 24px;
        font-weight: bold;
    }

    .header .date {
        font-size: 16px;
        margin-top: 10px;
    }

    .total {
        font-weight: bold;
        background-color: #c4dbae;
    }

    .total td {
        font-weight: bold;
    }

    td.number {
        text-align: right;
    }

    .total-weight {
        font-weight: bold;
        background-color: #dbcbae;
    }
    .total-weight td {
        font-weight: bold;
    }


    .mx-10px {
        margin-left: 10px;
        margin-right: 10px;
    }
</style>
@endpush

@push('script')

@endpush

@section('content')
<div class="row">
    <div class="col">
        <div class="header">
            <div class="logo">
                <img src="{{ asset('images/phaiku-logo.png') }}" alt="Logo" style="width: 100px; height: auto;">
            </div>
            <div class="title">สรุปรายงานการส่งของ</div>
            <div class="date">
                วันที่: {{date( 'd/m/Y', strtotime( $date_q ))}}
            </div>
        </div>
        <table class="table table-bordered mx-10px" width="100%" cellpadding="5" cellspacing="5" class="tg">
            <tbody>
                <tr>
                    <th width="40" rowspan="2">ที่</th>
                    <th scope="col" rowspan="2">รถ</th>
                    <th scope="col" rowspan="2">เต้าหู้<br>ขาว</th>
                    <th scope="col" rowspan="2">เต้าหู้<br>เหลือง</th>
                    <th scope="col" rowspan="2">เต้าหู้<br>กระดาน</th>
                    <th scope="col" rowspan="2">เต้าหู้<br>พวง</th>
                    <th scope="col" rowspan="2">เต้าหู้<br>นิ่ม</th>
                    <th scope="col" rowspan="2">เส้นเล็ก<br>ดอกบัว</th>
                    <th scope="col" rowspan="2">วุ้นเส้น<br>กิเลน</th>
                    <th scope="colgroup" colspan="10">
                        <center>ถั่วงอก</center>
                    </th>
                </tr>
                <tr>
                    <th scope="col">1 kg</th>
                    <th scope="col">5 kg</th>
                    <th scope="col">10 kg</th>
                    <th scope="col">มัดปาก</th>
                    <th scope="col">ซีนไม่<br>สูญญากาศ</th>
                    <th scope="col">ถั่วถัง</th>
                    <th scope="col">น้ำหนัก</th>
                    <th scope="col">ถั่วตะกร้า</th>
                    <th scope="col">น้ำหนัก</th>
                    <th scope="col">รวม</th>
                </tr>
                @foreach ($allcars as $car)
                <tr>
                    <td>{{ $loop->iteration }}</td>
                    <td>{{ $car['name'] }}</td>
                    <td class="number">{{ $car['p1']>0? number_format($car['p1'],2) : '-' }}</td>
                    <td class="number">{{ $car['p2']>0? number_format($car['p2'],2) : '-' }}</td>
                    <td class="number">{{ $car['p3']>0? number_format($car['p3'],2) : '-' }}</td>
                    <td class="number">{{ $car['p4']>0? number_format($car['p4'],2) : '-' }}</td>
                    <td class="number">{{ $car['p5']>0? number_format($car['p5'],2) : '-' }}</td>
                    <td class="number">{{ $car['p22']>0? number_format($car['p22'],2) : '-' }}</td>
                    <td class="number">{{ $car['p23']>0? number_format($car['p23'],2) : '-' }}</td>
                    <td class="number">{{ $car['p6']>0? number_format($car['p6'],2) : '-' }}</td>
                    <td class="number">{{ $car['p7']>0? number_format($car['p7'],2) : '-' }}</td>
                    <td class="number">{{ $car['p8']>0? number_format($car['p8'],2) : '-' }}</td>
                    <td class="number">{{ $car['p19']>0? number_format($car['p19'],2) : '-' }}</td>
                    <td class="number">{{ $car['p20']>0? number_format($car['p20'],2) : '-' }}</td>
                    <td class="number">{{ $car['b_num']>0? number_format($car['b_num'],2) : '-' }}</td>
                    <td class="number">{{ $car['b_total']>0? number_format($car['b_total'],2) : '-' }}</td>
                    <td class="number">{{ $car['b_basket_num']>0? number_format($car['b_basket_num'],2) : '-' }}</td>
                    <td class="number">{{ $car['b_basket_total']>0? number_format($car['b_basket_total'],2) : '-' }}
                    </td>
                    <td class="number">{{ $carsWeight[$car['id']]>0? number_format($carsWeight[$car['id']],2) : '-' }}</td>
                </tr>
                @endforeach
                <tr class="total">
                    <td colspan="2" class="total">สรุปยอด</td>
                    <td class="number">{{ $totalProducts['p1']>0? number_format($totalProducts['p1'],2) : '-' }}</td>
                    <td class="number">{{ $totalProducts['p2']>0? number_format($totalProducts['p2'],2) : '-' }}</td>
                    <td class="number">{{ $totalProducts['p3']>0? number_format($totalProducts['p3'],2) : '-' }}</td>
                    <td class="number">{{ $totalProducts['p4']>0? number_format($totalProducts['p4'],2) : '-' }}</td>
                    <td class="number">{{ $totalProducts['p5']>0? number_format($totalProducts['p5'],2) : '-' }}</td>
                    <td class="number">{{ $totalProducts['p22']>0? number_format($totalProducts['p22'],2) : '-' }}</td>
                    <td class="number">{{ $totalProducts['p23']>0? number_format($totalProducts['p23'],2) : '-' }}</td>
                    <td class="number">{{ $totalProducts['p6']>0? number_format($totalProducts['p6'],2) : '-' }}</td>
                    <td class="number">{{ $totalProducts['p7']>0? number_format($totalProducts['p7'],2) : '-' }}</td>
                    <td class="number">{{ $totalProducts['p8']>0? number_format($totalProducts['p8'],2) : '-' }}</td>
                    <td class="number">{{ $totalProducts['p19']>0? number_format($totalProducts['p19'],2) : '-' }}</td>
                    <td class="number">{{ $totalProducts['p20']>0? number_format($totalProducts['p20'],2) : '-' }}</td>
                    <td class="number">{{ $totalProducts['b_num']>0? number_format($totalProducts['b_num'],2) : '-' }}
                    </td>
                    <td class="number">{{ $totalProducts['b_total']>0? number_format($totalProducts['b_total'],2) : '-'
                        }}</td>
                    <td class="number">{{ $totalProducts['b_basket_num']>0?
                        number_format($totalProducts['b_basket_num'],2) : '-' }}</td>
                    <td class="number">{{ $totalProducts['b_basket_total']>0?
                        number_format($totalProducts['b_basket_total'],2) : '-' }}</td>
                    <td class="number">-</td>
                </tr>
                {{-- Weight summary --}}
                <tr class="total-weight">
                    <td colspan="2" class="total-weight">สรุปน้ำหนัก</td>
                    <td class="number">{{ $totalWeight['p1']>0? number_format($totalWeight['p1'],2) : '-' }}</td>
                    <td class="number">{{ $totalWeight['p2']>0? number_format($totalWeight['p2'],2) : '-' }}</td>
                    <td class="number">{{ $totalWeight['p3']>0? number_format($totalWeight['p3'],2) : '-' }}</td>
                    <td class="number">{{ $totalWeight['p4']>0? number_format($totalWeight['p4'],2) : '-' }}</td>
                    <td class="number">{{ $totalWeight['p5']>0? number_format($totalWeight['p5'],2) : '-' }}</td>
                    <td class="number">{{ $totalWeight['p22']>0? number_format($totalWeight['p22'],2) : '-' }}</td>
                    <td class="number">{{ $totalWeight['p23']>0? number_format($totalWeight['p23'],2) : '-' }}</td>
                    <td class="number">{{ $totalWeight['p6']>0? number_format($totalWeight['p6'],2) : '-' }}</td>
                    <td class="number">{{ $totalWeight['p7']>0? number_format($totalWeight['p7'],2) : '-' }}</td>
                    <td class="number">{{ $totalWeight['p8']>0? number_format($totalWeight['p8'],2) : '-' }}</td>
                    <td class="number">{{ $totalWeight['p19']>0? number_format($totalWeight['p19'],2) : '-' }}</td>
                    <td class="number">{{ $totalWeight['p20']>0? number_format($totalWeight['p20'],2) : '-' }}</td>
                    <td class="number">-
                    </td>
                    <td class="number">{{ $totalProducts['b_total']>0? number_format($totalProducts['b_total'],2) : '-'
                        }}</td>
                    <td class="number">-</td>
                    <td class="number">{{ $totalProducts['b_basket_total']>0?
                        number_format($totalProducts['b_basket_total'],2) : '-' }}</td>
                    <td class="number">-</td>
                </tr>
                <tr class="total">
                    <td colspan="2" class="total">น้ำหนักรวม ตามประเภท</td>
                    <td colspan="7" class="number">{{ $totalWeight['tofu']>0? number_format($totalWeight['tofu'],2) : '-' }}</td>
                    <td colspan="10" class="number">{{ $totalWeight['bean']>0? number_format($totalWeight['bean'],2) : '-' }}</td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

@endsection