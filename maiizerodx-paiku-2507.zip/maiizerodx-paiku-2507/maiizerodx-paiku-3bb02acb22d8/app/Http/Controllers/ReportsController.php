<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\ThaiFormat;

class ReportsController extends Controller
{
    /**--
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //$customers = \App\Customer::all();
        //show only customers with status = 1
        $customers = \App\Customer::with('market')->where('status',1)->get();

        $cars = \App\Car::all();

         //foreach($customers as $customer){
         //  echo $customer->id.' : '.$customer->name.' - '.$customer->market->name." <br>";
         //}
	
	    //print_r($customers);

        return view('reports.selectdaterange',compact('customers','cars'));
    }

    //สรุปรายงานการส่งของ ของรถทุกคัน - web
    public function summary(Request $request)
    {
        $date_q = date( 'Y-m-d', strtotime( $request->dateValue ));

        $cars = \App\Car::all();
        $customers = \App\Customer::where('status',1)->get();
        $selectedProducts = [1,2,3,4,5,6,7,8,19, 20, 22, 23];

        $products = \App\Product::whereIn('id', $selectedProducts)->get();
        $productWeight = [];
        foreach ($products as $product) {
            $productWeight['p'.$product->id] = $product->weight;
        }
        
        // initialize all cars and total
        $allcars = array();
        $carsWeight = array();
        $totalWeight = array();
        $totalProducts = array();
        foreach ($cars as $car) {
            $allcars[$car->id]['id'] = $car->id;
            $allcars[$car->id]['name'] = $car->name;
            foreach ($selectedProducts as $productId) {
                $allcars[$car->id]['p'.$productId] = 0; // initialize product quantities
                $totalProducts['p'.$productId] = 0; // initialize total for each product
                $totalWeight['p'.$productId] = 0; // initialize total weight
            }
            $carsWeight[$car->id] = 0; // initialize total weight for each car
            $allcars[$car->id]['b_num'] = 0;
            $allcars[$car->id]['b_total'] = 0;
            $allcars[$car->id]['b_basket_num'] = 0;
            $allcars[$car->id]['b_basket_total'] = 0;
            $totalProducts['b_num'] = 0; // initialize total for bucket number
            $totalProducts['b_total'] = 0;
            $totalProducts['b_basket_num'] = 0; // initialize total for basket number
            $totalProducts['b_basket_total'] = 0; // initialize total for basket weight
        }

        foreach ($customers as $customer) {
            $orders = \App\Order::with('product_lineitems','bucket_lineitems','basket_lineitems')
            ->where('customer_id',$customer->id)
            ->whereDate('order_at',$date_q)
            ->get();
            $car_id = $customer->car_id;
            foreach ($orders as $order) {
                
                if (isset($allcars[$car_id])) {
                    // create new array for each product
                    foreach ($selectedProducts as $productId) {
                        $selectedQty = $order->product_lineitems()->where('product_id', $productId)->sum('qty');
                        if ($selectedQty > 0) {
                            if (!isset($allcars[$car_id]['p'.$productId])) {
                                $allcars[$car_id]['p'.$productId] = 0;
                            }
                            $allcars[$car_id]['p'.$productId] += $selectedQty;
                            $carsWeight[$car_id] += $selectedQty * $productWeight['p'.$productId];
                            $totalProducts['p'.$productId] += $selectedQty; // accumulate total for each product
                            $totalWeight['p'.$productId] += $selectedQty * $productWeight['p'.$productId]; // accumulate total weight
                        }
                    }
                    
                    // handle bucket lineitems
                    $bucketQty = $order->bucket_lineitems->sum('weight');
                    if ($bucketQty > 0) {
                        if (!isset($allcars[$car_id]['b_num'])) {
                            $allcars[$car_id]['b_num'] = 0;
                        }
                        $allcars[$car_id]['b_num']++;
                        $totalProducts['b_num'] += 1; // accumulate total for bucket number
                        $allcars[$car_id]['b_total'] = isset($allcars[$car_id]['b_total']) ? $allcars[$car_id]['b_total'] + $bucketQty : $bucketQty;
                        $totalProducts['b_total'] += $bucketQty; // accumulate total for bucket weight
                        $carsWeight[$car_id] += $bucketQty; // accumulate total weight for bucket
                    }
                    // handle basket lineitems
                    $basketQty = $order->basket_lineitems->sum('weight');
                    if ($basketQty > 0) {
                        if (!isset($allcars[$car_id]['b_basket_num'])) {
                            $allcars[$car_id]['b_basket_num'] = 0;
                        }
                        $allcars[$car_id]['b_basket_num']++;
                        $totalProducts['b_basket_num'] += 1; // accumulate total for basket number
                        $allcars[$car_id]['b_basket_total'] = isset($allcars[$car_id]['b_basket_total']) ? $allcars[$car_id]['b_basket_total'] + $basketQty : $basketQty;
                        $totalProducts['b_basket_total'] += $basketQty; // accumulate total for basket weight
                        $carsWeight[$car_id] += $basketQty; // accumulate total weight for basket
                    }
                    
                }
            }
        }
        $totalWeight['bean'] = 0;
        $totalWeight['tofu'] = 0;

        // calculate total weight for bean and tofu products
        $totalWeight['bean'] = $totalWeight['p6'] + $totalWeight['p7'] + $totalWeight['p8'] + $totalWeight['p19'] + $totalWeight['p20']+$totalProducts['b_basket_total']+$totalProducts['b_total'];
        $totalWeight['tofu'] = $totalWeight['p1'] + $totalWeight['p2'] + $totalWeight['p3'] + $totalWeight['p4'] + $totalWeight['p5'];
        
        return view('reports.carsummary',compact('allcars','totalProducts','date_q', 'totalWeight', 'productWeight','carsWeight'));
        //return [$allcars, $totalProducts, $date_q];
    }

    //ใบรายการส่งของ แยกตามรถ
    //แสดงข้อมูลลูกค้าและยอดขายของรถแต่ละคันที่เลือก
    public function showcar(Request $request)
    {
        $date_q = date( 'Y-m-d', strtotime( $request->dateValue ));
        $report_date = ThaiFormat::shortdate($request->dateValue);
        $id = $request->car_id;
        $car_name = \App\Car::findOrFail($id)->name;
        //$customers = \App\Customer::with('orders')->where('car_id',$id)->get();
        //show only customers with status = 1
        $customers = \App\Customer::with('market')->where('car_id',$id)->where('status',1)->get();
        // $customers = \App\Customer::where('car_id',$id)->get();

        //echo print_r($customers)."<hr>";

        $datas = array();

        $total = array();
        $total['p1'] = 0;
        $total['p2'] = 0;
        $total['p3'] = 0;
        $total['p4'] = 0;
        $total['p5'] = 0;
        $total['p6'] = 0;
        $total['p7'] = 0;
        $total['p8'] = 0;

        // additional products
        $total['p19'] = 0;
        $total['p20'] = 0;
        $total['p22'] = 0;
        $total['p23'] = 0;

        $total['basket_num'] = 0;
        $total['basket_weight'] = 0;
        $total['bucket_num'] = 0;
        $total['bucket_weight'] = 0;

        foreach ($customers as $customer) {
            $data = array();
            $data['market'] = $customer->market->name;
            $data['customer_id'] = $customer->id;
            $data['name'] = $customer->name;
            $orders = \App\Order::with('product_lineitems','bucket_lineitems','basket_lineitems')->where('customer_id',$customer->id)->whereDate('order_at',$date_q)->get();

            $data['p1'] = "";
            $data['p2'] = "";
            $data['p3'] = "";
            $data['p4'] = "";
            $data['p5'] = "";
            $data['p6'] = "";
            $data['p7'] = "";
            $data['p8'] = "";

            // additional products
            $data['p19'] = "";
            $data['p20'] = "";
            $data['p22'] = "";
            $data['p23'] = "";

            $data['basket_num']="";
            $data['basket_list']="";

            $data['bucket_num']="";
            $data['bucket_list']="";
            if(count($orders)>0)
            {
                foreach ($orders as $order) {
                    // bean products product in (6-8,19,20)
                    // tofu products product in (1-5,22,23)
                    for ($i=1; $i <= 23 ; $i++) {
                        if($i >= 9 && $i <= 18)
                            continue;
                        $temps2 = $order->product_lineitems()->where('product_id',$i)->get();
                        if(count($temps2)>0)
                        {
                            foreach ($temps2 as $temp) {
                                $data['p'.$i] += $temp->qty;
                                $total['p'.$i] += $temp->qty;
                            }
                        }
                    }

                    // bucket lineitems
                    $bucket_lists =  $order->bucket_lineitems()->get();
                    if(count($bucket_lists) > 0)
                    {
                        $temp_w = 0;
                        foreach ($bucket_lists as $bucket) {
                            $temp_w += $bucket->weight;
                            $data['bucket_list'] .= number_format ($bucket->weight);
                            $data['bucket_list'] .= ' ';
                            $data['bucket_num']++;
                        }
                        $total['bucket_weight'] += $temp_w;
                        $total['bucket_num'] +=$data['bucket_num'];
                    }

                    // basket lineitems
                    $basket_lists =  $order->basket_lineitems()->get();
                    if(count($basket_lists) > 0)
                    {
                        $temp_w = 0;
                        foreach ($basket_lists as $basket) {
                            $temp_w += $basket->weight;
                            $data['basket_list'] .= number_format ($basket->weight);
                            $data['basket_list'] .= ' ';
                            $data['basket_num']++;
                        }
                        $total['basket_weight'] += $temp_w;
                        $total['basket_num'] +=$data['basket_num'];
                    }
                }
            }
            array_push($datas,$data);
        }
        //echo print_r($datas);
        //echo print_r($total);
        return view('layouts.singlecardailyreport',compact('car_name','report_date','datas','total'));
    }

    public function showallcar($date_q)
    {
        //$customers = \App\Customer::with('orders')->where('car_id',$id)->get();
        // $customers = \App\Customer::with(['orders' => function ($query) {
        //             $query->whereDate('order_at','2017-01-07');
        //         }])->where('car_id',$id)->get();
        $count = \App\Car::all()->count();
        $customers = \App\Customer::with('orders.product_lineitems','orders.bucket_lineitems')->where('status',1)->get();
        $allcars = array();
        $total = array();
        for ($id=1; $id <= $count ; $id++) {
            $datas = array();
            $total[$id]['p1'] = 0;
            $total[$id]['p2'] = 0;
            $total[$id]['p3'] = 0;
            $total[$id]['p4'] = 0;
            $total[$id]['p5'] = 0;
            $total[$id]['p6'] = 0;
            $total[$id]['p7'] = 0;
            $total[$id]['p8'] = 0;
            $total[$id]['num_b'] = 0;
            $total[$id]['sum_b'] = 0;
            foreach ($customers as $customer) {
                if($customer->car_id == $id)
                {
                    $data = array();
                    $data['market'] = $customer->market->name;
                    $data['name'] = $customer->name;
                    $total[$id]['car'] = $customer->car->name;

                    $temps = $customer->orders()->whereDate('order_at',$date_q)->get();
                    $data['p1'] = 0;
                    $data['p2'] = 0;
                    $data['p3'] = 0;
                    $data['p4'] = 0;
                    $data['p5'] = 0;
                    $data['p6'] = 0;
                    $data['p7'] = 0;
                    $data['p8'] = 0;
                    $data['num_b']=0;
                    $data['list_b']="";
                    if(count($temps)>0)
                    {
                        for ($i=1; $i <= 8 ; $i++) {
                            $temps2 = $temps[0]->product_lineitems()->where('product_id',$i)->get();
                            if(count($temps2)>0)
                            {
                               foreach ($temps2 as $temp) {
                                   $data['p'.$i] = $temp->qty;
                                   $total[$id]['p'.$i] += $data['p'.$i];
                               }
                            }
                        }

                        $temps1 =  $temps[0]->bucket_lineitems()->get();
                        if(count($temps1) > 0)
                        {
                            $temp_w = 0;
                           foreach ($temps1 as $temp1) {
                                $temp_w += $temp1->weight;
                                $data['list_b'] .= number_format ($temp1->weight);
                                $data['list_b'] .= ' ';
                                $data['num_b']++;
                           }
                           $total[$id]['num_b'] +=$data['num_b'];
                           $total[$id]['sum_b'] +=$temp_w;
                        }
                    }
                    array_push($datas,$data);
                }
            }
            array_push($allcars,$datas);
        }
        echo print_r($allcars);
        //echo print_r($total);
        //return view('layouts.cardailyreport',compact('date_q','allcars','total'));
    }

    public function printSummaryByDate(Request $request)
    {
        $date_q = date( 'Y-m-d', strtotime( $request->dateValue ));
        $cars = \App\Car::all();

        $allcars = array();
        $total = array();

        foreach ($cars as $car) {
            $id = $car->id;
            $customers = \App\Customer::where('car_id',$id)->where('status',1)->get();

            $datas = array();
            $total[$id]['p1'] = 0;
            $total[$id]['p2'] = 0;
            $total[$id]['p3'] = 0;
            $total[$id]['p4'] = 0;
            $total[$id]['p5'] = 0;
            $total[$id]['p6'] = 0;
            $total[$id]['p7'] = 0;
            $total[$id]['p8'] = 0;
            $total[$id]['num_b'] = 0;
            $total[$id]['sum_b'] = 0;

            $total[$id]['car'] = $car->name;


            if(count($customers)>0){
                foreach ($customers as $customer) {
                    $data = array();
                    $data['name'] = $customer->name;
                    $data['market'] = $customer->market->name;

                    $orders = \App\Order::with('product_lineitems','bucket_lineitems')->where('customer_id',$customer->id)->whereDate('order_at',$date_q)->get();

                    //echo count($orders)."<hr>";
                    for ($i=1; $i <= 8 ; $i++) {
                        $data['p'.$i] = 0;
                    }
                    $data['num_b']=0;
                    $data['list_b']="";

                    if(count($orders)>0)
                    {
                        foreach ($orders as $order) {

                            for ($i=1; $i <= 8 ; $i++) {
                                $temps = $order->product_lineitems()->where('product_id',$i)->get();
                                // $data['p'.$i] = 0;
                                if(count($temps)>0)
                                {
                                   foreach ($temps as $temp) {
                                       $data['p'.$i] += $temp->qty;
                                       $total[$id]['p'.$i] += $temp->qty;
                                   }
                                }
                            }

                            $temps1 = $order->bucket_lineitems()->get();
                            // $data['num_b']=0;
                            // $data['list_b']="";
                            if(count($temps1)>0)
                            {
                                $temp_w = 0;
                               foreach ($temps1 as $temp1) {
                                    $temp_w += $temp1->weight;
                                    $data['list_b'] .= number_format ($temp1->weight);
                                    $data['list_b'] .= ' ';
                                    $data['num_b']++;
                               }
                               $total[$id]['num_b'] +=$data['num_b'];
                               $total[$id]['sum_b'] +=$temp_w;
                            }
                        }
                    }
                    $datas['car_id'] = $car->id;
                    array_push($datas,$data);
                }
                array_push($allcars,$datas);
            }

        }

        return view('layouts.cardailyreport',compact('date_q','allcars','total'));
    }

    

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function printBillByDateRange(Request $request)
    {
        //
        //return ("ตั้งแต่วันที่ " . $request->startDate ." จนถึง ". $request->endDate);
        $from = date( 'Y-m-d H:i:s', strtotime( $request->startDate ));
        $to = date( 'Y-m-d H:i:s', strtotime( $request->endDate .'+1 days'));

        $orders = \App\Order::where('order_at','>=', $from)
                    ->where('order_at','<', $to) //whereBetween('order_at', [$from, $to])
                    ->where('customer_id',$request->customer_id)
                    ->orderBy('order_at','asc')
                    ->get();
        $customer = \App\Customer::findOrFail($request->customer_id);

        // echo "ชื่อ :" . $customer->name;
        // echo "<br>ตลาด :" . $customer->market->name;
        // echo "<br>ช่วงวันทำรายการ :" . $request->startDate . " - " . $request->endDate ;
        // echo "<hr>";

        //payment data
        // ธนาคาร: กรุงเทพ
        // ชื่อบัญชี: สุรชิต ทักษะปิยะบุตร
        // เลขที่บัญชี: 709-025889-3

        $paymentdata = array();
        $paymentdata['owner'] = array();
        $paymentdata['owner']['name'] = 'สุรชิต ทักษะปิยะบุตร';
        $paymentdata['owner']['bank'] = 'กรุงเทพ';
        $paymentdata['owner']['account'] = '709-025889-3';

        $paymentdata['bean'] = array();
        $paymentdata['bean']['name'] = 'บริษัท ไผ่คู่ จำกัด ';
        $paymentdata['bean']['bank'] = 'ไทยพาณิชย์ สาขา นครปฐม';
        $paymentdata['bean']['account'] = '519-293285-4';

        $paymentdata['tofu'] = array();
        $paymentdata['tofu']['name'] = 'ศรุตา ทักษะปิยะบุตร';
        $paymentdata['tofu']['bank'] = 'ทหารไทยธนชาติ สาขา ราชบุรี';
        $paymentdata['tofu']['account'] = '311-7-03702-2';

        $header = array();
        $header['name'] = $customer->name;
        $header['market'] = $customer->market->name;
        $header['address'] = $customer->address;
        $header['startDate'] = date( 'd / m / Y', strtotime( $request->startDate ));
        $header['endDate'] = date( 'd / m / Y', strtotime( $request->endDate ));

        //set payment type
        if($request->payment == 'owner') {
            $header['payment_bean'] = $paymentdata['owner'];
            $header['payment_tofu'] = $paymentdata['owner'];
        } else{
            $header['payment_bean'] = $paymentdata['bean'];
            $header['payment_tofu'] = $paymentdata['tofu'];
        }

        $total = array();
        $total['p1_price'] = 0;
        $total['p2_price'] = 0;
        $total['p3_price'] = 0;
        $total['p4_price'] = 0;
        $total['p5_price'] = 0;
        $total['p6_price'] = 0;
        $total['p7_price'] = 0;
        $total['p8_price'] = 0;
        
        $total['p1'] = 0;
        $total['p2'] = 0;
        $total['p3'] = 0;
        $total['p4'] = 0;
        $total['p5'] = 0;
        $total['p6'] = 0;
        $total['p7'] = 0;
        $total['p8'] = 0;
        $total['bucket_num'] = 0;
        $total['bucket_weight'] = 0;
        $total['bucket_price'] = 0;
        $total['basket_num'] = 0;
        $total['basket_weight'] = 0;
        $total['basket_price'] = 0;

        //additional products
        $total['p19'] = 0;
        $total['p20'] = 0;
        $total['p22'] = 0;
        $total['p23'] = 0;
        $total['p19_price'] = 0;
        $total['p20_price'] = 0;
        $total['p22_price'] = 0;
        $total['p23_price'] = 0;

        $total['bean_price'] = 0;
        $total['tofu_price'] = 0;

        $orderDatas = array();
        // echo $orders->count();
        if($orders->count()) {
            //var_dump($orders);
            $iList = 1;
            $totalAll = 0;
            foreach ($orders as $order) {
                # code...
                // if($order->customer->id != $request->customer_id)
                //     continue;

                $orderData = array();
                $orderData['date'] = date( 'd ', strtotime( $order->order_at ));
                $orderData['p1'] = 0;
                $orderData['p2'] = 0;
                $orderData['p3'] = 0;
                $orderData['p4'] = 0;
                $orderData['p5'] = 0;
                $orderData['p6'] = 0;
                $orderData['p7'] = 0;
                $orderData['p8'] = 0;
                $orderData['p19'] = 0;
                $orderData['p20'] = 0;
                $orderData['p22'] = 0;
                $orderData['p23'] = 0;
                $orderData['bucket_num']=0;
                $orderData['bucket_list']="";
                $orderData['bucket_total']=0;
                $orderData['basket_num']=0;
                $orderData['basket_list']="";
                $orderData['basket_total']=0;

                for ($i=1; $i <= 23 ; $i++) {
                    if($i == 21 || $i>=9 && $i <= 18)
                        continue;
                    $tempProduct = $order->product_lineitems()->where('product_id',$i)->get();
                    if(count($tempProduct)>0)
                    {
                       foreach ($tempProduct as $temp) {
                        //echo 'p'.$i.'_price';
                           $orderData['p'.$i] = $temp->qty;
                       }
                    }
                    $total['p'.$i] += $orderData['p'.$i];
                    $total['p'.$i.'_price'] += $order->product_lineitems()->where('product_id',$i)->sum('subtotal');
                    //total bean
                    if($i >= 6 && $i <= 8 || $i == 19 || $i == 20) {
                        $total['bean_price'] +=  $order->product_lineitems()->where('product_id',$i)->sum('subtotal');
                    }
                    //total tofu
                    if($i >= 1 && $i <= 5  || $i == 22 || $i == 23) {
                        $total['tofu_price'] +=  $order->product_lineitems()->where('product_id',$i)->sum('subtotal');
                    }
                }

                $tempBucket =  $order->bucket_lineitems()->get();
                if(count($tempBucket) > 0)
                {
                    //$temp_w = 0;
                    //$orderData['b_total']=0;
                    foreach ($tempBucket as $temp2) {
                        $orderData['bucket_total'] += $temp2->weight;
                        $orderData['bucket_list'] .= number_format ($temp2->weight);
                        $orderData['bucket_list'] .= ' ';
                        $orderData['bucket_num']++;
                        $total['bucket_price'] += $temp2->subtotal;
                        $total['bean_price'] += $temp2->subtotal; // assuming bucket items are bean products
                   }
                   $total['bucket_num'] +=$orderData['bucket_num'];
                   $total['bucket_weight'] +=$orderData['bucket_total'];
                }

                $tempBasket =  $order->basket_lineitems()->get();
                if(count($tempBasket) > 0)
                {
                    //$temp_w = 0;
                    //$orderData['b_total']=0;
                    foreach ($tempBasket as $temp3) {
                        $orderData['basket_total'] += $temp3->weight;
                        $orderData['basket_list'] .= number_format ($temp3->weight);
                        $orderData['basket_list'] .= ' ';
                        $orderData['basket_num']++;
                        $total['basket_price'] += $temp3->subtotal;
                        $total['bean_price'] += $temp3->subtotal; // assuming basket items are bean products
                   }
                   $total['basket_num'] +=$orderData['basket_num'];
                   $total['basket_weight'] +=$orderData['basket_total'];
                }
                $orderTotal = $order->bucket_lineitems->sum('subtotal') + $order->product_lineitems->sum('subtotal');
                // echo "$iList | ". date( 'd / m / Y', strtotime( $order->order_at )) . " | " . number_format($orderTotal,2) . "<br>" ;
                $iList++;
                $totalAll += $orderTotal;
                array_push($orderDatas,$orderData);
            }

            // var_dump($orderDatas);
            // var_dump($total);
            // echo "<hr>" . number_format($totalAll,2);

        }else{
            echo 'No data';
        }
        //var_dump($orders);
        return view('layouts.periodrecript_2',compact('header','orderDatas','total','totalAll'));
    }

    public function printAutoBillOnDate(Request $request)
    {
        $date_q = date( 'Y-m-d', strtotime( $request->onDate ));
        $date_end = date( 'Y-m-d', strtotime( $request->onDate .'+1 days'));

        $car_select = $request->car_id;

        $orders = \App\Order::with('product_lineitems','bucket_lineitems','basket_lineitems','customer')
                    ->where('order_at','>=', $date_q)
                    ->where('order_at','<', $date_end)
                    ->orderBy('customer_id', 'ASC')
                    ->get();
        //return response()->json($orders);
        // $orders = DB::table('orders')
        //         ->whereDate('order_at', $date_q)
        //         ->get();
        //return $date_q . $orders;
        $products = \App\Product::all();
        $bills = array();
        //$temps = $customer->orders()->whereDate('order_at',$date_q)->get();
        if(count($orders)>0)
        {
            foreach ($orders as $order) {

                if($car_select != $order->customer->car_id)
                    continue;
                // check customer status
                if($order->customer->status != 1)
                    continue;

                if(($request->printMode == 'cashbill') && ($order->customer->auto_bill_print != 1))
                    continue;

                if(($request->printMode != 'cashbill') && ($order->customer->auto_bill_print == 1))
                    continue;

                $data = array();
                $data['order_id'] = $order->id;
                $data['car_name'] = $order->customer->car->name;
                $data['customer_no'] = $order->customer->id;//customer_priority;
                $data['customer_name'] = $order->customer->name;
                $data['market_name'] = $order->customer->market->name;
                $data['customer_address'] = $order->customer->address;
                $data['printDate'] =$order->order_at;

                $data['p1'] = "";
                $data['p2'] = "";
                $data['p3'] = "";
                $data['p4'] = "";
                $data['p5'] = "";
                $data['p6'] = "";
                $data['p7'] = "";
                $data['p8'] = "";
                
                $data['p1_amount'] = "";
                $data['p2_amount'] = "";
                $data['p3_amount'] = "";
                $data['p4_amount'] = "";
                $data['p5_amount'] = "";
                $data['p6_amount'] = "";
                $data['p7_amount'] = "";
                $data['p8_amount'] = "";

                // additional products
                $data['p19'] = "";
                $data['p20'] = "";
                $data['p22'] = "";
                $data['p23'] = "";
                $data['p19_amount'] = "";
                $data['p20_amount'] = "";
                $data['p22_amount'] = "";
                $data['p23_amount'] = "";

                $data['num_basket']="";
                $data['list_basket']="";
                $data['basket_amount'] = "";
                $data['num_bucket']="";
                $data['list_bucket']="";
                $data['bucket_amount'] = "";

                $data['bean_total_amount'] = 0;
                $data['tofu_total_amount'] = 0;
                $data['total_amount'] = 0;

                // bean products product in (6-8,19,20)
                // tofu products product in (1-5,22,23)
                for ($i=1; $i <= 23 ; $i++) {
                    if($i == 9 || $i == 10 || $i == 11 || $i == 12 || $i == 13 || $i == 14 || $i == 15 || $i == 16 || $i == 17 || $i == 18)
                        continue;
                    $temps2 = $order->product_lineitems()->where('product_id',$i)->get();
                    if(count($temps2)>0)
                    {
                    foreach ($temps2 as $temp) {
                        $data['p'.$i] += $temp->qty;
                        $data['p'.$i.'_amount'] += $temp->subtotal;
                        //$total[$id]['p'.$i] += $data['p'.$i];
                    }
                        if($i >= 6 && $i <= 8 || $i == 19 || $i == 20)
                            $data['bean_total_amount'] += $data['p'.$i.'_amount'];
                        else
                            $data['tofu_total_amount'] += $data['p'.$i.'_amount'];
                        $data['total_amount'] +=$data['p'.$i.'_amount'];
                    }
                }

                // bucket lineitems
                $temps1 =  $order->bucket_lineitems()->get();
                if(count($temps1) > 0)
                {
                    $temp_w = 0;
                foreach ($temps1 as $temp1) {
                        $temp_w += $temp1->weight;
                        $data['list_bucket'] .= number_format ($temp1->weight);
                        $data['list_bucket'] .= ' ';
                        $data['num_bucket']++;
                        $data['bucket_amount'] += $temp1->subtotal;
                }
                    $data['bean_total_amount'] += $data['bucket_amount'];
                $data['total_amount'] +=$data['bucket_amount'];
                //$total[$id]['num_b'] +=$data['num_b'];
                //$total[$id]['sum_b'] +=$temp_w;
                }

                // basket lineitems
                $temps2 =  $order->basket_lineitems()->get();
                if(count($temps2) > 0)
                {
                    $temp_w = 0;
                foreach ($temps2 as $temp2) {
                        $temp_w += $temp2->weight;
                        $data['list_basket'] .= number_format ($temp2->weight);
                        $data['list_basket'] .= ' ';
                        $data['num_basket']++;
                        $data['basket_amount'] += $temp2->subtotal;
                }
                    $data['bean_total_amount'] += $data['basket_amount'];
                $data['total_amount'] +=$data['basket_amount'];
                }
                array_push($bills,$data);
            }

        }
        if($request->printMode == 'cashbill')
            return view('layouts.p_cashbill',compact('bills','products'));
        else
            return view('layouts.p_billingnote',compact('bills','products'));
    }
    /**
     * พิมพ์ใบรายการส่งของ ตามหมายเลขคำสั่งซื้อ
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function printBillByOrderID($id)
    {
        //
        $order = \App\Order::findOrFail($id);
        $products = \App\Product::all();
        //$temps = $customer->orders()->whereDate('order_at',$date_q)->get();
        $data = array();
        $data['order_id'] = $order->id;
        $data['car_name'] = $order->customer->car->name;
        $data['customer_no'] = $order->customer->id;//customer_priority;
        $data['customer_name'] = $order->customer->name;
        $data['market_name'] = $order->customer->market->name;
        $data['customer_address'] = $order->customer->address;
        $data['printDate'] =$order->order_at;

        $data['p1'] = "";
        $data['p2'] = "";
        $data['p3'] = "";
        $data['p4'] = "";
        $data['p5'] = "";
        $data['p6'] = "";
        $data['p7'] = "";
        $data['p8'] = "";
        
        $data['p1_amount'] = "";
        $data['p2_amount'] = "";
        $data['p3_amount'] = "";
        $data['p4_amount'] = "";
        $data['p5_amount'] = "";
        $data['p6_amount'] = "";
        $data['p7_amount'] = "";
        $data['p8_amount'] = "";

        // additional products
        $data['p19'] = "";
        $data['p20'] = "";
        $data['p22'] = "";
        $data['p23'] = "";
        $data['p19_amount'] = "";
        $data['p20_amount'] = "";
        $data['p22_amount'] = "";
        $data['p23_amount'] = "";

        $data['num_basket']="";
        $data['list_basket']="";
        $data['basket_amount'] = "";
        $data['num_bucket']="";
        $data['list_bucket']="";
        $data['bucket_amount'] = "";

        $data['bean_total_amount'] = 0;
        $data['tofu_total_amount'] = 0;
        $data['total_amount'] = 0;

        if(count($order)>0)
        {
            // bean products product in (6-8,19,20)
            // tofu products product in (1-5,22,23)
            for ($i=1; $i <= 23 ; $i++) {
                if($i == 9 || $i == 10 || $i == 11 || $i == 12 || $i == 13 || $i == 14 || $i == 15 || $i == 16 || $i == 17 || $i == 18)
                    continue;
                $temps2 = $order->product_lineitems()->where('product_id',$i)->get();
                if(count($temps2)>0)
                {
                   foreach ($temps2 as $temp) {
                       $data['p'.$i] += $temp->qty;
                       $data['p'.$i.'_amount'] += $temp->subtotal;
                       //$total[$id]['p'.$i] += $data['p'.$i];
                   }
                    if($i >= 6 && $i <= 8 || $i == 19 || $i == 20)
                        $data['bean_total_amount'] += $data['p'.$i.'_amount'];
                    else
                        $data['tofu_total_amount'] += $data['p'.$i.'_amount'];
                    $data['total_amount'] +=$data['p'.$i.'_amount'];
                }
            }

            // bucket lineitems
            $temps1 =  $order->bucket_lineitems()->get();
            if(count($temps1) > 0)
            {
                $temp_w = 0;
               foreach ($temps1 as $temp1) {
                    $temp_w += $temp1->weight;
                    $data['list_bucket'] .= number_format ($temp1->weight);
                    $data['list_bucket'] .= ' ';
                    $data['num_bucket']++;
                    $data['bucket_amount'] += $temp1->subtotal;
               }
                $data['bean_total_amount'] += $data['bucket_amount'];
               $data['total_amount'] +=$data['bucket_amount'];
               //$total[$id]['num_b'] +=$data['num_b'];
               //$total[$id]['sum_b'] +=$temp_w;
            }

            // basket lineitems
            $temps2 =  $order->basket_lineitems()->get();
            if(count($temps2) > 0)
            {
                $temp_w = 0;
               foreach ($temps2 as $temp2) {
                    $temp_w += $temp2->weight;
                    $data['list_basket'] .= number_format ($temp2->weight);
                    $data['list_basket'] .= ' ';
                    $data['num_basket']++;
                    $data['basket_amount'] += $temp2->subtotal;
               }
                $data['bean_total_amount'] += $data['basket_amount'];
               $data['total_amount'] +=$data['basket_amount'];
            }
        }
        return view('layouts.recript',compact('order','data','products'));
    }

    public function printAccountSum(Request $request)
    {
      $date_q = date( 'Y-m-d', strtotime( $request->startDate ));
      $date_end = date( 'Y-m-d', strtotime( $request->endDate .'+1 days'));

      $receipts = \App\Receipt::with('instalment')
                  ->where('order_at','>=', $date_q)
                  ->where('order_at','<', $date_end)
                  ->get();

      $transactions = \App\Transaction::where('created_at','>=', $date_q)
                  ->where('created_at','<', $date_end)
                  ->get();

      $total = array();
      $total['cash'] = 0.0;
      $total['transfer'] = 0.0;
      $total['transfer_pending'] = 0.0;
      $total['unpay'] = 0.0;
      $total['deduct'] = 0.0;
      $total['cheque'] = 0.0;

      $total['cash'] = $transactions
          ->where('transaction_type_id',1)
          ->sum('total');
      $total['transfer'] = $transactions
          ->where('transaction_type_id',2)
          ->where('transfer_status_id',8)
          ->sum('total');
      $total['transfer_pending'] = $transactions
          ->where('transaction_type_id',2)
          ->where('transfer_status_id',7)
          ->sum('total');
      $total['cheque'] = $transactions
          ->where('transaction_type_id',3)
          ->where('transfer_status_id','!=',10)
          ->sum('total');
      $total['deduct'] = $receipts->sum('deduct_total');
      $receipt_net = $receipts->sum('net_total');
      $total['unpay'] = $receipt_net - $total['cash']
                        - $total['transfer'] - $total['cheque'];

      $transactions_cheque = $transactions->where('transaction_type_id',3);
      return view('print.account_sum',compact('total','request','transactions_cheque'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Test function to retrieve products based on selected IDs.
     *
     * @return \Illuminate\Http\Response
     */
    public function testFunction()
    {
        $selectedProducts = [1,2,3,4,5,6,7,8,19, 20, 22, 23];

        $products = \App\Product::whereIn('id', $selectedProducts)->get();
        $productWeight = [];
        foreach ($products as $product) {
            $productWeight['p'.$product->id] = $product->weight;
        }
        // Return the product weights as a JSON response
        return response()->json($productWeight);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function __construct()
    {
        $this->middleware('auth');
    }
}
