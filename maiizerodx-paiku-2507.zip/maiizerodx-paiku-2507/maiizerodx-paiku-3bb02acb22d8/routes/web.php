<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::resource('cars','CarsController');
Route::get('/cars', 'CarsController@searchData');

Route::resource('markets','MarketsController');
Route::get('/markets', 'MarketsController@searchData');

Route::resource('customers','CustomersController');
Route::get('/customers', 'CustomersController@searchData');

Route::resource('products','ProductsController');
Route::get('/products', 'ProductsController@searchData');
//Route::resource('orders','OrdersController');
//Route::resource('reports','ReportsController');
Auth::routes();

Route::get('/', 'HomeController@index');
Route::get('/home', function () {
    return redirect('/');
});
/**
 *
 */
Route::get('/customers/{id}/productprices', 'CustomerProductPriceController@create');
Route::post('/productprices', 'CustomerProductPriceController@store');
Route::delete('/productprices/{id}', 'CustomerProductPriceController@destroy');
Route::get('/productprices/{id}/edit', 'CustomerProductPriceController@edit');

/**
 * Orders Route
 */

Route::get('/orders', 'OrdersController@index');
Route::get('/orders', 'OrdersController@searchData');
Route::get('/orders/customer', 'OrdersController@chooseCustomer');
//Route::get('/orders/customer/{id}', 'OrdersController@createOrderByCustomer');

Route::post('/orders/customer/{id}', 'OrdersController@storeNewOrder');

Route::get('/orders/{id}', 'OrdersController@show');

Route::get('/orders/{id}/edit', 'OrdersController@edit');
Route::get('/orders/{id}/print', 'ReportsController@printBillByOrderID');

Route::post('/orders/{id}/product', 'OrdersController@storeProductLineitem');
Route::post('/orders/{id}/bucket', 'OrdersController@storeBucketLineitem');
Route::post('/orders/{id}/basket', 'OrdersController@storeBasketLineitem');

Route::put('/orders/{id}', 'OrdersController@update');

Route::delete('/orders/{id}', 'OrdersController@destroy');
Route::delete('/orders/{id}/product', 'OrdersController@destroyProductLineitem');
Route::delete('/orders/{id}/bucket', 'OrdersController@destroyBucketLineitem');
Route::delete('/orders/{id}/basket', 'OrdersController@destroyBasketLineitem');

/**
 * Report Route
 */
Route::get('/reports', 'ReportsController@index');

Route::get('/reports/all', function () {
    return view('layouts.alldailyreport');
});

Route::post('/reports/summary', 'ReportsController@summary');

Route::post('/reports/all', 'ReportsController@printSummaryByDate');
Route::post('/reports/autobill', 'ReportsController@printAutoBillOnDate');
Route::post('/reports/bills', 'ReportsController@printBillByDateRange');

Route::get('/reports/all/{date_q}', 'ReportsController@showallcar');
Route::post('/reports/car', 'ReportsController@showcar');

Route::get('/reports/account', function () {
    return view('reports.account');
});
Route::post('/reports/account/sum', 'ReportsController@printAccountSum');

Route::get('/m_genkey/{key}', function ($key) {
    return bcrypt($key);
});

Route::post('/test_req', 'HomeController@testPrintData');

Route::get('/test_view/{page}', function ($page) {
    return view($page);
});
//version 2
//Route::resource('billings','BillingsController');
// Route::get('/billings', function () {
//     return view('dataBilling.index');
// });
Route::get('/billings', 'BillingController@index');
//Route::get('/billings', 'BillingController@searchData');
Route::get('/billings/trash', 'BillingController@indexTrashed');
Route::get('/billings/customer', 'BillingController@chooseCustomer');
Route::get('/billings/customer/{id}', 'BillingController@showCustomerOrder');
Route::get('/billings/trash/{id}', 'BillingController@showTrashed');
Route::post('/billings', 'BillingController@store');
Route::get('/billings/{id}', 'BillingController@show');
Route::get('/billings/{id}/print', 'BillingController@printBill');
Route::get('/billings/{id}/pay', 'ReceiptController@createReceiptForSingleBilling');
Route::delete('/billings/{id}', 'BillingController@destroy');


Route::get('/receipts', 'ReceiptController@index');
Route::get('/receipts/trash', 'ReceiptController@indexTrashed');
Route::get('/receipts/customer', 'ReceiptController@chooseCustomer');
Route::get('/receipts/filter', 'ReceiptController@chooseCustomerfilter');
Route::get('/receipts/filter/customer/{id}', 'ReceiptController@showFilter');
Route::get('/receipts/customer/{id}', 'ReceiptController@showCustomerOrder');
Route::post('/receipts', 'ReceiptController@store');
Route::get('/receipts/{id}', 'ReceiptController@show');
Route::get('/receipts/{id}/instalment', 'ReceiptController@showInstalment');
Route::delete('/receipts/{id}', 'ReceiptController@destroy');



Route::post('/receipt/single', 'ReceiptController@storeReceiptForSingleBilling');
Route::post('/receipts/transaction', 'TransactionController@storeTransferForReceipt');

Route::get('/transactions', 'TransactionController@index');

Route::get('/transactions/transfer/{id}', 'TransactionController@showTrasfer');
Route::post('/transactions/transfer/{id}', 'TransactionController@updateTransfer');

Route::get('/transactions/cheque/{id}', 'TransactionController@showCheque');
Route::post('/transactions/cheque/{id}', 'TransactionController@updateCheque');//TransactionController@updateCheque

Route::post('/transaction/full/transfer', 'TransactionController@storeTransferForSingleReceiptFull');
Route::post('/transaction/full/cheque', 'TransactionController@storeChequeForSingleReceiptFull');
Route::post('/transaction/instalment/transfer', 'TransactionController@storeTransfer');
Route::post('/transaction/instalment/cheque', 'TransactionController@storeCheque');

Route::get('/transactions/list/transfer', 'TransactionController@indexTransfer');
Route::get('/transactions/list/cheque', 'TransactionController@indexCheque');
//Route::get('/reports/all/{date_q}', 'ReportsController@showall');
// Route::get('/101', function () {
//     return view('layouts.p_billingnote');
// });
// Route::get('/report/{id}', function ($id) {
//     return "Report : " . $id ;//. "<br><a href=".route('admin.home').">Click Here</a>";
// });

Route::get('/test', 'ReportsController@testFunction');
