<?php

use Illuminate\Database\Seeder;

class TypesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('customer_types')->insert([
		    ['name' => 'รถตลาด'],
            ['name' => 'รถบ้าน']
		    
		]);

		DB::table('product_types')->insert([
		    ['name' => 'ผลิตเอง'],
		    ['name' => 'ซัพฟลายเออร์']
		]);
    }
}
