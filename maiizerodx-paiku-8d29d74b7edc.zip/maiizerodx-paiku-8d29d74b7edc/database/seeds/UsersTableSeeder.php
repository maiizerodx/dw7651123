<?php

use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('users')->insert([
            ['username' => 'admin',
            'firstname' => 'admin',
            'lastname' => str_random(5),
            'email' => str_random(5).'@gmail.com',
            'password' => bcrypt('admin'),
            'role_id' => '1'],
            
            ['username' => 'system',
            'firstname' => 'SYSTEM',
            'lastname' => str_random(5),
            'email' => str_random(5).'@admin.com',
            'password' => bcrypt('dwanuoijwas4756aw4ddcadf'),
            'role_id' => '1'],
            
            ['username' => 'testuser',
            'firstname' => 'testuser',
            'lastname' => str_random(5),
            'email' => str_random(5).'@gmail.com',
            'password' => bcrypt('testuser'),
            'role_id' => '0']

            ]);
    }
}
