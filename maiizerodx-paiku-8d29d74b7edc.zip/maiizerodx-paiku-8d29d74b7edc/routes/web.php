<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::resource('cars','CarsController');
Route::get('/cars', 'CarsController@searchData');

Route::resource('markets','MarketsController');
Route::get('/markets', 'MarketsController@searchData');

Route::resource('customers','CustomersController');
Route::get('/customers', 'CustomersController@searchData');

Route::resource('products','ProductsController');
Route::get('/products', 'ProductsController@searchData');
//Route::resource('orders','OrdersController');
//Route::resource('reports','ReportsController');
Auth::routes();
Route::resource('register','RegisterController');

Route::get('/createuser', [
  'middleware' => ['auth'],
  'uses' => function () {
   return view('auth.register');
}]);

Route::get('/', 'HomeController@index');

/**
 * 
 */
Route::get('/customers/{id}/productprices', 'CustomerProductPriceController@create');
Route::post('/productprices', 'CustomerProductPriceController@store');
Route::delete('/productprices/{id}', 'CustomerProductPriceController@destroy');
Route::get('/productprices/{id}/edit', 'CustomerProductPriceController@edit');
/**
 * Orders Route
 */

Route::get('/orders', 'OrdersController@index');
Route::get('/orders', 'OrdersController@searchData');
Route::get('/orders/customer', 'OrdersController@chooseCustomer');
//Route::get('/orders/customer/{id}', 'OrdersController@createOrderByCustomer');

Route::post('/orders/customer/{id}', 'OrdersController@storeNewOrder');

Route::get('/orders/{id}', 'OrdersController@show');

Route::get('/orders/{id}/edit', 'OrdersController@edit');
Route::get('/orders/{id}/print', 'ReportsController@printBillByOrderID');

Route::post('/orders/{id}/product', 'OrdersController@storeProductLineitem');
Route::post('/orders/{id}/bucket', 'OrdersController@storeBucketLineitem');

Route::put('/orders/{id}', 'OrdersController@update');

Route::delete('/orders/{id}', 'OrdersController@destroy');
Route::delete('/orders/{id}/product', 'OrdersController@destroyProductLineitem');
Route::delete('/orders/{id}/bucket', 'OrdersController@destroyBucketLineitem');

Route::get('/reports', 'ReportsController@index');

Route::get('/reports/all', function () {
    return view('layouts.alldailyreport');
});

Route::post('/reports/all', 'ReportsController@printSummaryByDate');
Route::post('/reports/autobill', 'ReportsController@printAutoBillOnDate');
Route::post('/reports/bills', 'ReportsController@printBillByDateRange');

Route::get('/reports/all/{date_q}', 'ReportsController@showallcar');
Route::post('/reports/car', 'ReportsController@showcar');


Route::get('/reports/all', function () {
    return view('layouts.alldailyreport');
});

Route::get('/m_genkey/{key}', function ($key) {
    return bcrypt($key);
});

//Route::get('/reports/all/{date_q}', 'ReportsController@showall');
// Route::get('/101', function () {
//     return view('layouts.p_billingnote');
// });
// Route::get('/report/{id}', function ($id) {
//     return "Report : " . $id ;//. "<br><a href=".route('admin.home').">Click Here</a>";
// });

//Route::get('/test', 'OrdersController@test11');
