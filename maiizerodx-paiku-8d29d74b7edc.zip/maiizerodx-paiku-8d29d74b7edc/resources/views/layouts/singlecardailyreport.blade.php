<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>DailyReport</title>
<style type="text/css">
    body {
        width: 100%;
        height: 100%;
        margin: 0;
        padding: 0;
        background-color: #FAFAFA;
        font: 12pt "Tahoma";
    }
    * {
        box-sizing: border-box;
        -moz-box-sizing: border-box;
    }
    .page {
        width: 210mm;
        min-height: 297mm;
        padding: 5mm;
        margin: 5mm auto;
        border: 1px #D3D3D3 solid;
        border-radius: 5px;
        background: white;
        box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
    }
    .subpage {
        padding: .1cm;
        height: 287mm;
    }
    
    @page {
        size: A4;
        margin: 0;
    }
    @media print {
        html, body {
            width: 210mm;
            height: 297mm;        
        }
        .page {
            margin: 0;
            border: initial;
            border-radius: initial;
            width: initial;
            min-height: initial;
            box-shadow: initial;
            background: initial;
            page-break-after: always;
        }
    }
body,td,th {
	font-family: Tahoma;
	font-size: 10pt;
}
caption{
	font-family: Tahoma;
	font-size: 15pt;
	margin-bottom:10px;
}
.tg  {border-collapse:collapse;border-spacing:0;}
.tg td{font-family:Arial, sans-serif;font-size:14px;padding:2px 1px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;}
.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:1px 1px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;}
.tg .tg-yw4l{vertical-align:top}
</style>
</head>

<body>
<?php
?>
<div class="book">
@if(count($datas)>0)
        <div class="page">
            <div class="subpage">
                <table width="100%" border="1" cellpadding="2" cellspacing="0" class="tg">
                    <caption>รายการส่งของวันที่ {{date( 'd/m/Y', strtotime( $date_q ))}}</caption>
                    <tbody>
                      <tr>
                        <th width="12%" scope="col">ตลาด</th>
                        <th width="15%" scope="col">รายชื่อ</th>
                        <th width="5%" scope="col">เต้าหู้<br>
                          ขาว</th>
                        <th width="5%" scope="col">เต้าหู้<br>
                          เหลือง</th>
                        <th width="6%" scope="col">เต้าหู้<br>
                          กระดาน</th>
                        <th width="5%" scope="col">เต้าหู้<br>
                          พวง</th>
                        <th width="5%" scope="col">เต้าหู้<br>
                          นิ่ม</th>
                        <th width="5%" scope="col">ถั่วงอก<br>
                          1 kg.</th>
                        <th width="5%" scope="col">ถั่วงอก <br>
                          5 kg.</th>
                        <th width="6%" scope="col">ถั่วงอก <br>
                          10 kg.</th>
                        <th width="6%" scope="col">ถั่วงอก <br>
                          ถัง</th>
                        <th scope="col">รายละเอียด</th>
                      </tr>
                      @if(count($datas)>0)
                          @foreach($datas as $data)
                          <tr>
                            <th align="center">{{$data['market']}}</th>
                            <td align="left">{{$data['name']}}</td>
                            <?php for ($i=1; $i <= 8 ; $i++) { ?>
                            <td align='center'>{{$data['p'.$i]}}</td>
                            <?php } ?>
                            <td align="center">{{$data['num_b']}}</td>
                            <td>{{$data['list_b']}}</td>
                            </tr>
                          @endforeach
                      @endif
                      <tr>
                        <th bgcolor="#FFE796" scope="row">ถั่วเผื่อ</th>
                        <td bgcolor="#FFE796"><center>-</center></td>
                        <td bgcolor="#FFE796">&nbsp;</td>
                        <td bgcolor="#FFE796">&nbsp;</td>
                        <td bgcolor="#FFE796">&nbsp;</td>
                        <td bgcolor="#FFE796">&nbsp;</td>
                        <td bgcolor="#FFE796">&nbsp;</td>
                        <td bgcolor="#FFE796">&nbsp;</td>
                        <td bgcolor="#FFE796">&nbsp;</td>
                        <td bgcolor="#FFE796">&nbsp;</td>
                        <td bgcolor="#FFE796">&nbsp;</td>
                        <td bgcolor="#FFE796">&nbsp;</td>
                        </tr>
                      <tr>
                        <th colspan="2" scope="row">ยอดรวม</th>
                        <?php for ($i=1; $i <= 8 ; $i++) { ?>
                        <td align='center'>{{$total['p'.$i]}}</td>
                        <?php } ?>
                        <td align='center'>{{$total['num_b']}}</td>
                        <td>{{$total['sum_b']}}</td>
                        </tr>
                    </tbody>
                </table>
            </div>    
        </div>{{-- End Page --}}
@endif

</body>
</html>
