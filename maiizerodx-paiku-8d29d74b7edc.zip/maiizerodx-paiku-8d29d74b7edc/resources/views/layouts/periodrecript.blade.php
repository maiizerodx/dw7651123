<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<style type="text/css">
body {
  background: rgb(204,204,204);
}
page {
  background: white;
  display: block;
  margin: 0 auto;
  margin-bottom: 0.5cm;
  box-shadow: 0 0 0.5cm rgba(0,0,0,0.5);
}
page[size="A4"] {
  width: 21cm;
  height: 29.7cm;
}
page[size="A4"][layout="portrait"] {
  width: 29.7cm;
  height: 21cm;
}
page[size="A6"] {
  width: 10.5cm;
  height: 14.8cm;
}
page[size="A6"][layout="portrait"] {
  width: 14.8cm;
  height: 10.5cm;
}
page[size="A3"] {
  width: 29.7cm;
  height: 42cm;
}
page[size="A3"][layout="portrait"] {
  width: 42cm;
  height: 29.7cm;
}
page[size="A5"] {
  width: 14.8cm;
  height: 21cm;
}
page[size="A5"][layout="portrait"] {
  width: 21cm;
  height: 14.8cm;
}
.tableouter   {
	border-right: 1px solid #555555;
	border-bottom: 1px solid #555555;
}
.listItem    {
	border-collapse: collapse;
	border-spacing: 0;
	border: 2px solid #000000;
	margin: 0px auto;
}
.listItem th {
	font-size: 14px;
	font-weight: bold;
	padding-top: 3px;
	padding-right: 3px;
	padding-left: 3px;
	padding-bottom: 3px;
	border-style: solid;
	border-width: 1px;
	overflow: hidden;
	word-break: normal;
}
.listItem td {
	font-family: Arial, sans-serif;
	font-size: 14px;
	padding-top: 2px;
	padding-right: 5px;
	padding-left: 5px;
	padding-bottom: 1px;
	border-style: solid;
	border-width: 1px;
	overflow: hidden;
	word-break: normal;
}

.TableNormal {
	padding: 0px;
}
@media print {
  body, page {
    margin: 0;
    box-shadow: 0;
  }
}
body,td,th {
	font-size: 14px;
}
.tg {border-collapse:collapse;border-spacing:0;}
</style>
</head>

<body>
<?php
if(!isset($orderDatas))
{
  echo 'NO DATA';
  $countdate = 0;
}
else
{
  $countdate = count($orderDatas);
  $maxDatePerPage = 15;
  $startPage = 1;
}
?>
@if($countdate > 0)

<page size="A5" layout="portrait">
  <table width="100%" height="486" border="0" cellpadding="0" cellspacing="5" id="Table_">
    <tr>
      <td width="360" height="30" colspan="5" valign="bottom" ><table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tbody>
          <tr>
            <td height="40" valign="bottom"><center>
              <strong style="font-size: 18px">ใบวางบิล / บิลเงินสด</strong>
            </center></td>
          </tr>
          <tr>
            <td align="center">วันที่ {{$header['startDate']}} - {{$header['endDate']}} </td>
          </tr>
          <tr>
            <td align="center">ชื่อ {{$header['name']}} - {{$header['market']}}</td>
          </tr>
        </tbody>
      </table></td>
    </tr>
    <tr>
      <td height="5" rowspan="3"><img src="{{URL::asset('images/spacer.gif') }}" width="5" height="370" alt=""></td>
      <td  width="360" colspan="3"><table width="100%" border="1" cellpadding="2" cellspacing="0" class="tg">
        <tbody>
          <tr>
            <th width="70" scope="col">วันที่</th>
            <th width="40" scope="col"> ขาว</th>
            <th width="40" scope="col"> เหลือง</th>
            <th width="40" scope="col"> กระดาน</th>
            <th width="40" scope="col"> พวง</th>
            <th width="40" scope="col"> นิ่ม</th>
            <th scope="col">ถั่วงอก
              <br>
              (1 กก.)</th>
            <th scope="col">ถั่วงอก
              <br>
              (5 กก.)</th>
            <th scope="col">ถั่วงอก
              <br>
              (10 กก.)</th>
            <th scope="col">จน./ถัง</th>
            <th width="130" scope="col">ถั่วถัง</th>
            <th scope="col"> นน.รวม</th>
          </tr>
          @for($i = 0; $i < 15; $i++)
            @if(isset($orderDatas[$i]))
            <tr>
              <td align="center">{{ $orderDatas[$i]['date'] }}</td>
              <td align="center">@if($orderDatas[$i]['p1'] > 0){{ $orderDatas[$i]['p1']}}@else - @endif</td>
              <td align="center">@if($orderDatas[$i]['p2'] > 0){{$orderDatas[$i]['p2']}}@else - @endif</td>
              <td align="center">@if($orderDatas[$i]['p3'] > 0){{$orderDatas[$i]['p3']}}@else - @endif</td>
              <td align="center">@if($orderDatas[$i]['p4'] > 0){{$orderDatas[$i]['p4']}}@else - @endif</td>
              <td align="center">@if($orderDatas[$i]['p5'] > 0){{$orderDatas[$i]['p5']}}@else - @endif</td>
              <td align="center">@if($orderDatas[$i]['p6'] > 0){{$orderDatas[$i]['p6']}}@else - @endif</td>
              <td align="center">@if($orderDatas[$i]['p7'] > 0){{$orderDatas[$i]['p7']}}@else - @endif</td>
              <td align="center">@if($orderDatas[$i]['p8'] > 0){{$orderDatas[$i]['p8']}}@else - @endif</td>
              <td align="center">@if($orderDatas[$i]['b_num'] > 0){{$orderDatas[$i]['b_num']}}@else - @endif</td>
              <td align="center">@if($orderDatas[$i]['b_list'] > 0){{$orderDatas[$i]['b_list']}}@else - @endif</td>
              <td align="center">@if($orderDatas[$i]['b_total'] > 0){{$orderDatas[$i]['b_total']}}@else - @endif</td>
            </tr>
            @endif
          @endfor
          <tr>
            <td align="right"><strong>รวม</strong></td>
            <td align="center">@if($total['p1'] > 0){{ $total['p1']}}@else - @endif</td>
            <td align="center">@if($total['p2'] > 0){{ $total['p2']}}@else - @endif</td>
            <td align="center">@if($total['p3'] > 0){{ $total['p3']}}@else - @endif</td>
            <td align="center">@if($total['p4'] > 0){{ $total['p4']}}@else - @endif</td>
            <td align="center">@if($total['p5'] > 0){{ $total['p5']}}@else - @endif</td>
            <td align="center">@if($total['p6'] > 0){{ $total['p6']}}@else - @endif</td>
            <td align="center">@if($total['p7'] > 0){{ $total['p7']}}@else - @endif</td>
            <td align="center">@if($total['p8'] > 0){{ $total['p8']}}@else - @endif</td>
            <td align="center">@if($total['b_num'] > 0){{ $total['b_num']}}@else - @endif</td>
            <td align="center">-</td>
            <td align="center">@if($total['b_weight'] > 0){{ $total['b_weight']}}@else - @endif</td>
          </tr>
          <tr>
            <td align="right"><strong>จำนวนเงิน</strong></td>
            <td align="center">@if($total['p1_price'] > 0){{ number_format($total['p1_price'],2)}}@else - @endif</td>
            <td align="center">@if($total['p2_price'] > 0){{ number_format($total['p2_price'],2)}}@else - @endif</td>
            <td align="center">@if($total['p3_price'] > 0){{ number_format($total['p3_price'],2)}}@else - @endif</td>
            <td align="center">@if($total['p4_price'] > 0){{ number_format($total['p4_price'],2)}}@else - @endif</td>
            <td align="center">@if($total['p5_price'] > 0){{ number_format($total['p5_price'],2)}}@else - @endif</td>
            <td align="center">@if($total['p6_price'] > 0){{ number_format($total['p6_price'],2)}}@else - @endif</td>
            <td align="center">@if($total['p7_price'] > 0){{ number_format($total['p7_price'],2)}}@else - @endif</td>
            <td align="center">@if($total['p8_price'] > 0){{ number_format($total['p8_price'],2)}}@else - @endif</td>
            <td align="center">-</td>
            <td align="center">-</td>
            <td align="center">@if($total['b_price'] > 0){{ number_format($total['b_price'],2)}}@else - @endif</td>
          </tr>
        </tbody>
      </table></td>
      <td height="5" rowspan="3"><img src="{{URL::asset('images/spacer.gif') }}" width="5" height="370" alt=""></td>
    </tr>
    <tr>
      <td colspan="3" valign="bottom">
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tbody>
          <tr>
            <td width="42%">&nbsp;</td>
            <td width="35%" align="right"><strong style="font-size: 16px">ยอดเงินสุทธิ : &nbsp;</strong></td>
            <td width="23%"><table width="100%" border="1" cellpadding="0" cellspacing="0" class="tg">
              <tbody>
                <tr>
                  <td align="right"><strong>{{ number_format($totalAll,2)}}&nbsp;</strong></td>
                </tr>
              </tbody>
            </table></td>
          </tr>
        </tbody>
      </table></td>
    </tr>
    <tr>
      <td colspan="3" valign="bottom">ผู้รับเงิน............................</td>
    </tr>
    <tr>
      <td><img src="{{URL::asset('images/spacer.gif') }}" width="12" height="1" alt=""></td>
      <td><img src="{{URL::asset('images/spacer.gif') }}" width="81" height="1" alt=""></td>
      <td><img src="{{URL::asset('images/spacer.gif') }}" width="173" height="1" alt=""></td>
      <td width="360"><img src="{{URL::asset('images/spacer.gif') }}" width="82" height="1" alt=""></td>
      <td><img src="{{URL::asset('images/spacer.gif') }}" width="12" height="1" alt=""></td>
    </tr>
  </table>
</page>
@endif

</body>
</html>
