@extends('layouts.app')

@section('content')
{{-- <a href="#"><strong><i class="material-icons" style="font-size:20px">dashboard</i> กระดาน</strong></a> --}}
<h3>วันนี้ : {{\App\ThaiFormat::fulldate(\Carbon\Carbon::now())}}</h3>
<hr>



@endsection
