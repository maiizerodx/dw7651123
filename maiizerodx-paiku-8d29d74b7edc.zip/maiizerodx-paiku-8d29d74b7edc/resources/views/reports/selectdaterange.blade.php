@extends('layouts.app')

@push('styles')
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="css/bootstrap-select.min.css">
@endpush

@push('script')
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>
$(function(){
    $("#from").datepicker({ dateFormat: 'dd M yy' }).bind("change",function(){
        var minValue = $(this).val();
        minValue = $.datepicker.parseDate("dd M yy", minValue);
        minValue.setDate(minValue.getDate()+1);
        $("#to").datepicker( "option", "minDate", minValue );

        var maxValue = $(this).val();
        maxValue = $.datepicker.parseDate("dd M yy", maxValue);
        maxValue.setDate(maxValue.getDate()+14);
        $("#to").datepicker("option", "maxDate", maxValue);
    });
    $("#to").datepicker({ dateFormat: 'dd M yy' });


    $("#printDate").datepicker({ dateFormat: 'dd M yy' });
    $("#onDate").datepicker({ dateFormat: 'dd M yy' }).bind("change",function(){
        var minValue = $(this).val();
        minValue = $.datepicker.parseDate("dd M yy", minValue);
        minValue.setDate(minValue.getDate());
        $("#printDate").datepicker( "option", "minDate", minValue );
    });
    $("#dateValue").datepicker({ dateFormat: 'dd M yy' ,
        onSelect: function(){
        var selected = $(this).val();
        $("#dateValue2").val(selected);
        }
    });
});

// $(function() {
//     $("#datepicker").datepicker({
//         dateFormat: "yy-mm-dd",
//         onSelect: function(){
//         var selected = $(this).val();
//         $("#dateValue").val(selected);
//         }
//     });
// });
</script>
<!-- Latest compiled and minified JavaScript -->
<script src="js/bootstrap-select.min.js"></script>
@endpush

@section('content')
{{-- <a href="#"><strong><i class="material-icons" style="font-size:20px">dashboard</i> กระดาน</strong></a> --}}
<h3>วันนี้ : {{\App\ThaiFormat::fulldate(\Carbon\Carbon::now())}}</h3>
<hr>
<div class="row">
    <div class="col-sm-4">
        <div class="panel panel-default">
            <div class="panel-heading">ใบรายการส่งของ</div>
            <!-- <div class="panel-body">
                <form method="post" action="{{ url('/reports/all') }}">
                    {{ csrf_field() }}
                    <input type="hidden" id="dateValue" name="dateValue" value="{{ date( 'd M Y', strtotime( \Carbon\Carbon::now() )) }}">
                    <div class="form-group">
                        <center><strong>เลือกวันที่ต้องการ</strong></center>
                    </div>
                    <div class="form-group">
                        <center><div id="datepicker"></div></center>
                    </div>
                    <div class="form-group">
                      <input type="submit" name="submit" class="btn btn-success btn-block" value="พิมพ์">
                    </div>
                </form>
            </div> -->
            <div class="panel-body">
                <form method="post" action="{{ url('/reports/car') }}">
                    {{ csrf_field() }}
                    <div class="form-group">
                        <label>รถ</label>
                        <select id="selectbasic" name="car_id" class="form-control">
                            @if(isset($cars))
                                @foreach($cars as $car)
                                    <option value="{{$car->id}}">{{$car->id}} : {{$car->name}}</option>
                                @endforeach
                            @endif
                        </select>
                    </div>
                    <div class="form-group">
                        <label>วันที่ออกบิล</label>
                        <input class="form-control" type="text" id="dateValue" name="dateValue" size="12" value="{{ date( 'd M Y', strtotime( \Carbon\Carbon::now() )) }}"/>
                    </div>
                    <div class="form-group">
                      <input type="submit" name="submit" class="btn btn-success btn-block" value="พิมพ์">
                    </div>
                </form>
                <form method="post" action="{{ url('/reports/all') }}">
                    {{ csrf_field() }}
                    <input type="hidden" id="dateValue2" name="dateValue" value="{{ date( 'd M Y', strtotime( \Carbon\Carbon::now() )) }}">
                    <div class="form-group">
                      <input type="submit" name="submit" class="btn btn-block btn-warning" value="พิมพ์ใบรวมรถ">
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="col-sm-4">
        <div class="panel panel-default">
            <div class="panel-heading">บิลเงินสด/ใบส่งของ ที่กำหนดไว้</div>
            <div class="panel-body">
                <form method="post" action="{{ url('/reports/autobill') }}" class="form form-vertical">
                    {{ csrf_field() }}
                    <div class="form-group">
                        <label>รถ</label>
                        <select id="selectbasic" name="car_id" class="form-control">
                            @if(isset($cars))
                                @foreach($cars as $car)
                                    <option value="{{$car->id}}">{{$car->id}} : {{$car->name}}</option>
                                @endforeach
                            @endif
                        </select>
                    </div>
                    <div class="form-group">
                        <label>ประเภท</label>
                        <select id="selectbasic" name="printMode" class="form-control">
                            <option value="billingnote">ใบส่งของ - ทั้งหมด</option>
                            <option value="cashbill">บิลเงินสด - เฉพาะเงินสด</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>รายการสั่งของเมื่อ</label>
                        <input class="form-control" type="text" id="onDate" name="onDate" size="12" value="{{ date( 'd M Y', strtotime( \Carbon\Carbon::now() )) }}"/>
                    </div>
                    <div class="form-group">
                      <input type="submit" name="submit" class="btn btn-success btn-block" value="พิมพ์">
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="col-sm-4">
        <div class="panel panel-default">
            <div class="panel-heading">ใบวางบิล/บิลเงินสด รายบุคคล</div>
            <div class="panel-body">
                <form method="post" action="{{ url('/reports/bills') }}" class="form form-vertical">
                    {{ csrf_field() }}
                    <div class="form-group">
                        <label>ชื่อลูกค้า</label>
                        <select id="selectbasic" name="customer_id" class="selectpicker form-control" data-live-search="true">
                            @if(isset($customers))
                                @foreach($customers as $customer)
                                    <option value="{{$customer->id}}">{{$customer->id}} : {{$customer->name}} - {{$customer->market->name}}</option>
                                @endforeach
                            @endif
                        </select>
                    </div>
                    <div class="form-group">
                        <label>ตั้งแต่วันที่</label>
                        <input class="form-control" type="text" id="from" name="startDate" size="12" value="{{ date( 'd M Y', strtotime( \Carbon\Carbon::now()->subDay(5) )) }}"/>
                    </div>
                    <div class="form-group">
                        <label>จนถึง</label>
                        <input class="form-control" type="text" id="to" name="endDate" size="12" value="{{ date( 'd M Y', strtotime( \Carbon\Carbon::now() )) }}" />
                    </div>
                    <div class="form-group">
                      <input type="submit" name="submit" class="btn btn-success btn-block" value="พิมพ์">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>




{{-- <a href="/reports/all/{{ date( 'Y-m-d', strtotime( \Carbon\Carbon::now() )) }}"> รายงาน ทั้งหมด</a><br> --}}
<!-- <a href="{{ url('/reports/car') }}">  รายงานเ รายรถ</a> -->
@endsection
