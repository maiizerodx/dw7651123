@extends('layouts.app')

@section('content')
<a href="#"><strong><i class="glyphicon glyphicon-shopping-cart"></i> เพิ่มลูกค้า</strong></a>
<hr>
<div class="row">
    <div class="col-md-12">
		<form class="form-horizontal" method="post" action="{{ url('/customers') }}">
		{{ csrf_field() }}
			<fieldset>
			<!-- Text input-->
			<div class="form-group">
			  <label class="col-md-4 control-label" >ชื่อลูกค้า</label>
			  <div class="col-md-4">
			  <input name="name" type="text" placeholder="ชื่อลูกค้า" class="form-control input-md" required="">
			  </div>
			</div>
			<div class="form-group">
			  <label class="col-md-4 control-label" >เบอร์โทร</label>
			  <div class="col-md-4">
			  <input name="telephone" type="text" placeholder="เบอร์โทร" class="form-control input-md" >
			  </div>
			</div>
			<div class="form-group">
			  <label class="col-md-4 control-label" >ที่อยู่</label>
			  <div class="col-md-4">
			  <textarea  name="address" class="form-control input-md"></textarea>
			  </div>
			</div>
			<div class="form-group">
			  <label class="col-md-4 control-label" >ประเภทลูกค้า</label>
			  <div class="col-md-4">
			  <select id="selectbasic" name="customer_type_id" class="form-control">
			    <option value="0" selected="selected">ไม่ระบุ</option>
			    @if($customertypes)
	            	@foreach($customertypes as $customertype)
				    	<option value="{{$customertype->id}}">{{$customertype->name}}</option>
				    @endforeach
				  @endif
			    </select>
			  </div>
			</div>

			<div class="form-group">
			  <label class="col-md-4 control-label" >ตลาด</label>
			  <div class="col-md-4">
			  	<select id="selectbasic" name="market_id" class="form-control">
				  @if($markets)
	            	@foreach($markets as $market)
				    	<option value="{{$market->id}}">{{$market->name}}</option>
				    @endforeach
				  @endif
			  </select>
			  </div>
			</div>

			<div class="form-group">
			  <label class="col-md-4 control-label" >รถ</label>
			  <div class="col-md-4">
			  <select id="selectbasic" name="car_id" class="form-control">
			  	<option value="0" selected="selected">ไม่ระบุ</option>
				  @if($cars)
	            	@foreach($cars as $car)
				    	<option value="{{$car->id}}">{{$car->name}}</option>
				    @endforeach
				  @endif
			  </select>
			  </div>
			</div>

			<div class="form-group">
			  <label class="col-md-4 control-label" >ออกบิล</label>
			  <div class="col-md-4">
			  <div class="checkbox">
				<label><input type="checkbox" value="1" name="auto_bill_print">เงินสด</label>
			  </div>
			  </div>
			</div>
			<!-- Button (Double) -->
			<div class="form-group">
			<label class="col-md-4 control-label" ></label>
			  <div class="col-md-8">
			    <input type="submit" name="submit" class="btn btn-success" value="เพิ่ม">
			  </div>
			</div>

			</fieldset>
		</form>
    </div>
</div>

@endsection
