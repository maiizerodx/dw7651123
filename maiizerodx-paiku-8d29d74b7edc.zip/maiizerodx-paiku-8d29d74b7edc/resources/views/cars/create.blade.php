@extends('layouts.app')

@section('content')
<a href="#"><strong><i class="fa fa-car fa-lg"></i> เพิ่มรถส่งของ</strong></a>
<hr>
<div class="row">
    <div class="col-md-12">
		<form class="form-horizontal" method="post" action="{{ url('/cars') }}">
		{{ csrf_field() }}
			<fieldset>
			<!-- Text input-->
			<div class="form-group">
			  <label class="col-md-4 control-label" for="carname">ชื่อรถส่งของ</label>
			  <div class="col-md-4">
			  <input name="name" type="text" placeholder="ชื่อรถส่งของ" class="form-control input-md" required="">

			  </div>
			</div>

			<!-- Button (Double) -->
			<div class="form-group">
			  <label class="col-md-4 control-label" for="button1id"></label>
			  <div class="col-md-8">
			    <input type="submit" name="submit" class="btn btn-success" value="เพิ่ม">
			  </div>
			</div>

			</fieldset>
		</form>
    </div>
</div>

@endsection
