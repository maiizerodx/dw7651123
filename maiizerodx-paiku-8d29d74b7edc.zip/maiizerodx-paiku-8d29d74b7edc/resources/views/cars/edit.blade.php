@extends('layouts.app')

@section('content')
<a href="#"><strong><i class="fa fa-car fa-lg"></i> แก้ไขรถส่งของ</strong></a>
<hr>
<div class="row">
    <div class="col-md-12">
		<form class="form-horizontal" method="post" action="{{ url('/cars/'.$car->id) }}">
		{{ csrf_field() }}
		<input type="hidden" name="_method" value="PUT">
			<fieldset>
			<!-- Text input-->
			<div class="form-group">
			  <label class="col-md-4 control-label" for="carname">ชื่อรถส่งของ</label>
			  <div class="col-md-4">
			  <input name="name" type="text" placeholder="ชื่อรถส่งของ" class="form-control input-md" required="" value="{{$car->name}}">
			  </div>
			</div>

			<!-- Button (Double) -->
			<div class="form-group">
			  <label class="col-md-4 control-label" for="button1id"></label>
			  <div class="col-md-8">
			    <input type="submit" name="submit" class="btn btn-success" value="แก้ไข">
			  </div>
			</div>

			</fieldset>
		</form>
    </div>
</div>

@endsection
