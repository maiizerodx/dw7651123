@extends('layouts.app')

@section('content')
<a href="#"><strong><i class="glyphicon glyphicon-apple"></i> เพิ่มสินค้า</strong></a>
<hr>
<div class="row">
    <div class="col-md-12">
		<form class="form-horizontal" method="post" action="{{ url('/products') }}">
		{{ csrf_field() }}
			<fieldset>
			<!-- Text input-->
			<div class="form-group">
			  <label class="col-md-4 control-label">ชื่อสินค้า</label>
			  <div class="col-md-4">
			  <input name="name" type="text" placeholder="ชื่อสินค้า" class="form-control input-md" required="">

			  </div>
			</div>
			<div class="form-group">
			  <label class="col-md-4 control-label">หน่วย</label>
			  <div class="col-md-4">
			  <input name="unit" type="text" placeholder="หน่วย" class="form-control input-md" required="">
			  </div>
			</div>
			<div class="form-group">
			  <label class="col-md-4 control-label" >ประเภท</label>
			  <div class="col-md-4">
			  <select id="selectbasic" name="product_type_id" class="form-control">
			    <option value="0" selected="selected">-------ไม่ระบุ-------</option>
			    @if($producttypes)
	            	@foreach($producttypes as $producttype)
				    	<option value="{{$producttype->id}}">{{$producttype->name}}</option>
				    @endforeach
				  @endif
			    </select>
			  </div>
			</div>
			<div class="form-group">
			  <label class="col-md-4 control-label">น้ำหนักต่อหน่วย</label>
			  <div class="col-md-4">
			  <input name="weight" type="number" step="0.01" placeholder="น้ำหนักต่อหน่วย" class="form-control input-md" required="">
			  </div>
			</div>
			<!-- Button (Double) -->
			<div class="form-group">
			  <label class="col-md-4 control-label"></label>
			  <div class="col-md-8">
			    <input type="submit" name="submit" class="btn btn-success" value="เพิ่ม">
			  </div>
			</div>

			</fieldset>
		</form>
    </div>
</div>

@endsection
