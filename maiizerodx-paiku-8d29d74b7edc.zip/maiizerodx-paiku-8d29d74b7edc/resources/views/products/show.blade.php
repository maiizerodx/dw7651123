@extends('layouts.app')

@push('styles')
<link href="https://cdn.datatables.net/1.10.13/css/dataTables.bootstrap.min.css" rel="stylesheet">
@endpush

@push('script')
<script type="text/javascript" src="https://cdn.datatables.net/r/bs-3.3.5/jqc-1.11.3,dt-1.10.8/datatables.min.js"></script>
<script type="text/javascript" src="//cdn.datatables.net/plug-ins/1.10.13/i18n/Thai.json"></script>
<script type="text/javascript" charset="utf-8">
    $(document).ready(function() {
        $('#example').DataTable({
            "language": {
                "sProcessing":   "กำลังดำเนินการ...",
                "sLengthMenu":   "แสดง _MENU_ แถว",
                "sZeroRecords":  "ไม่พบข้อมูล",
                "sInfo":         "แสดง _START_ ถึง _END_ จาก _TOTAL_ แถว",
                "sInfoEmpty":    "แสดง 0 ถึง 0 จาก 0 แถว",
                "sInfoFiltered": "(กรองข้อมูล _MAX_ ทุกแถว)",
                "sInfoPostFix":  "",
                "sSearch":       "ค้นหา: ",
                "sUrl":          "",
                "oPaginate": {
                    "sFirst":    "หน้าแรก",
                    "sPrevious": "ก่อนหน้า",
                    "sNext":     "ถัดไป",
                    "sLast":     "หน้าสุดท้าย"
                }
            }
        });
    } );
</script>
@endpush

@section('content')
<a href="#"><strong><i class="glyphicon glyphicon-apple"></i> ข้อมูลสินค้า</strong></a>
<hr>
<a href="{{ url('/products/create') }}" class="btn btn-primary btn-success"><span class="glyphicon glyphicon-plus"></span> เพิ่มสินค้า</a>
<hr>
<div class="row">
    <div class="col-md-12">
        <table class="table">
          <tbody>
            <tr>
              <th scope="row">รหัสสินค้า</th>
              <td>{{ $product->id }}</td>
            </tr>
            <tr>
              <th scope="row">ชื่อสินค้า</th>
              <td>{{ $product->name }}</td>
            </tr>
            <tr>
              <th scope="row">หน่วย</th>
              <td>{{ $product->unit }}</td>
            </tr>
            <tr>
              <th scope="row">น้ำหนัก</th>
              <td>{{ $product->weight }}</td>
            </tr>
          </tbody>
        </table>
    </div>
</div>

@endsection
