@extends('layouts.app')

@push('styles')
<link href="https://cdn.datatables.net/1.10.13/css/dataTables.bootstrap.min.css" rel="stylesheet">
@endpush

@push('script')
<script type="text/javascript" src="https://cdn.datatables.net/r/bs-3.3.5/jqc-1.11.3,dt-1.10.8/datatables.min.js"></script>
<script type="text/javascript" src="//cdn.datatables.net/plug-ins/1.10.13/i18n/Thai.json"></script>
<script type="text/javascript" charset="utf-8">
    $(document).ready(function() {
        $('#example').DataTable({
            "paging":   false,
            "info":     false,
            "searching": false,
            "language": {
                "sProcessing":   "กำลังดำเนินการ...",
                "sLengthMenu":   "แสดง _MENU_ แถว",
                "sZeroRecords":  "ไม่พบข้อมูล",
                "sInfo":         "แสดง _START_ ถึง _END_ จาก _TOTAL_ แถว",
                "sInfoEmpty":    "แสดง 0 ถึง 0 จาก 0 แถว",
                "sInfoFiltered": "(กรองข้อมูล _MAX_ ทุกแถว)",
                "sInfoPostFix":  "",
                "sSearch":       "ค้นหา: ",
                "sUrl":          "",
                "oPaginate": {
                    "sFirst":    "หน้าแรก",
                    "sPrevious": "ก่อนหน้า",
                    "sNext":     "ถัดไป",
                    "sLast":     "หน้าสุดท้าย"
                }
            }
        });
    } );
</script>
@endpush

@section('content')
<a href="#"><strong><i class="glyphicon glyphicon-apple"></i> ข้อมูลสินค้า</strong></a>
<hr>
<a href="{{ url('/products/create') }}" class="btn btn-primary btn-success"><span class="glyphicon glyphicon-plus"></span> เพิ่มสินค้า</a>
<hr>
<div class="row">
    <div class="col-md-12">
        <form class="form-horizontal" method="get" action="{{ url('/products') }}">
            <!-- Text input-->
            <div class="form-group">
              <div class="col-md-9"></div>
              <div class="col-md-3">
                <div class="input-group">
                    <input name="key" type="text" class="form-control" placeholder="ชื่อ หรือ รหัส" @if(isset($_GET['key'])) value="{{$_GET['key']}}"@else value=""@endif>
                    <div class="input-group-btn">
                        <button class="btn btn-default" type="submit">
                            <i class="glyphicon glyphicon-search"></i>
                        </button>
                    </div>
                </div>
              </div>
            </div>
        </form>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th width="40"><center><i class="fa fa-cog"></i></center></th>
                <th width="80">รหัสสินค้า</th>
                <th>ชื่อสินค้า</th>
                <th>หน่วย</th>
                <th>น้ำหนัก (กิโลกรัม)</th>
            </tr>
        </thead>
        <tbody>
        @if($products)
            @foreach($products as $product)
                <tr>
                    <td>
                        <form action="{{ url('/products/'.$product->id) }}" method="POST"><input type="hidden" name="_method" value="DELETE">
                        <a href="{{ url('/products/'.$product->id.'/edit') }}" class="btn btn-xs btn-warning"><em class="fa fa-pencil"></em></a>
                        {{ csrf_field() }}
                        @if(Auth::user()->role_id >= 5)<button class='btn btn-danger btn-xs' type="submit" onclick="return confirm('คุณต้องการลบรายการนี้ออกใช่ไหม?')"><em class="fa fa-trash"></em></button>@endif
                        </form>
                    </td>
                    <td><a href="{{route('products.show',$product->id)}}"> {{ $product->id }}</a></td>
                    <td>{{ $product->name }}</td>
                    <td>{{ $product->unit }}</td>
                    <td>{{ $product->weight }}</td>
                </tr>
            @endforeach
        @endif
        </tbody>
    </table>
    {{ $products->appends(Request::only('key'))->links() }}
    </div>
</div>

@endsection
