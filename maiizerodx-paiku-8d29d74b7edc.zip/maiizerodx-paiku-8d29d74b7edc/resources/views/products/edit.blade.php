@extends('layouts.app')

@section('content')
<a href="#"><strong><i class="glyphicon glyphicon-apple"></i> แก้ไขสินค้า</strong></a>
<hr>
<div class="row">
    <div class="col-md-12">
		<form class="form-horizontal" method="post" action="{{ url('/products/'.$product->id) }}">
		{{ csrf_field() }}
		<input type="hidden" name="_method" value="PUT">
			<fieldset>
			<!-- Text input-->
			<div class="form-group">
			  <label class="col-md-4 control-label">ชื่อสินค้า</label>
			  <div class="col-md-4">
			  <input name="name" type="text" placeholder="ชื่อสินค้า" class="form-control input-md" required="" value="{{ $product->name }}">

			  </div>
			</div>
			<div class="form-group">
			  <label class="col-md-4 control-label">หน่วย</label>
			  <div class="col-md-4">
			  <input name="unit" type="text" placeholder="หน่วย" class="form-control input-md" required="" value="{{ $product->unit }}">
			  </div>
			</div>
			<div class="form-group">
			  <label class="col-md-4 control-label" >ประเภท</label>
			  <div class="col-md-4">
			  <select id="selectbasic" name="product_type_id" class="form-control">
			    <option value="0" @if($product['product_type_id'] == 0 )selected="selected"@endif>-------ไม่ระบุ-------</option>
			    @if($producttypes)
	            	@foreach($producttypes as $producttype)
				    	<option value="{{$producttype->id}}" @if($product['product_type_id'] == $producttype['id'] )selected="selected"@endif>{{$producttype->name}}</option>
				    @endforeach
				  @endif
			    </select>
			  </div>
			</div>
			<div class="form-group">
			  <label class="col-md-4 control-label">น้ำหนักต่อหน่วย</label>
			  <div class="col-md-4">
			  <input name="weight" type="number" step="0.01" placeholder="น้ำหนักต่อหน่วย" class="form-control input-md" required="" value="{{ $product->weight }}">
			  </div>
			</div>
			<!-- Button (Double) -->
			<div class="form-group">
			  <label class="col-md-4 control-label" for="button1id"></label>
			  <div class="col-md-8">
			    <input type="submit" name="submit" class="btn btn-success" value="แก้ไข">
			  </div>
			</div>

			</fieldset>
		</form>
    </div>
</div>

@endsection
