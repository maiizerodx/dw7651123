@extends('layouts.app')

@push('styles')
<link href="https://cdn.datatables.net/1.10.13/css/dataTables.bootstrap.min.css" rel="stylesheet">
@endpush

@push('script')
<script type="text/javascript" src="https://cdn.datatables.net/r/bs-3.3.5/jqc-1.11.3,dt-1.10.8/datatables.min.js"></script>
<script type="text/javascript" src="//cdn.datatables.net/plug-ins/1.10.13/i18n/Thai.json"></script>
<script type="text/javascript" charset="utf-8">
    $(document).ready(function() {
        $('#example').DataTable({
            "language": {
                "sProcessing":   "กำลังดำเนินการ...",
                "sLengthMenu":   "แสดง _MENU_ แถว",
                "sZeroRecords":  "ไม่พบข้อมูล",
                "sInfo":         "แสดง _START_ ถึง _END_ จาก _TOTAL_ แถว",
                "sInfoEmpty":    "แสดง 0 ถึง 0 จาก 0 แถว",
                "sInfoFiltered": "(กรองข้อมูล _MAX_ ทุกแถว)",
                "sInfoPostFix":  "",
                "sSearch":       "ค้นหา: ",
                "sUrl":          "",
                "oPaginate": {
                    "sFirst":    "หน้าแรก",
                    "sPrevious": "ก่อนหน้า",
                    "sNext":     "ถัดไป",
                    "sLast":     "หน้าสุดท้าย"
                }
            }
        });
    } );
</script>
@endpush

@section('content')
<a href="#"><strong><i class="glyphicon glyphicon-shopping-cart"></i>ราคาสินค้า</strong></a>
<hr>
<a href="{{ url('/products/create') }}" class="btn btn-primary btn-success"><span class="glyphicon glyphicon-plus"></span> เพิ่มสินค้า</a>
<hr>
<div class="row">
    <div class="col-md-12">
        <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <th width="40"><center><i class="fa fa-cog"></i></center></th>
                    <th width="80">รหัสสินค้า</th>
                    <th>ชื่อสินค้า</th>
                    <th>หน่วย</th>
                    <th>ราคาต่อหน่วย</th>
                </tr>
            </thead>
            <tbody>
            @if($productprices)
                @foreach($productprices as $productprice)
                    <tr>
                        <td>
                            <form action="{{ url('/productprice/'.$productprice->id) }}" method="POST">
                            <a href="{{ url('/productprice/'.$productprice->id.'/edit') }}" class="btn btn-xs btn-warning"><em class="fa fa-pencil"></em></a>
                            <input type="hidden" name="_method" value="DELETE">
                            {{ csrf_field() }}
                            <button class='btn btn-danger btn-xs' type="submit" onclick="return confirm('คุณต้องการลบรายการนี้ออกใช่ไหม?\nหากรถคันนี้มีลูกค้าอยู่\nลูกค้าที่อยู่กับรถคันนี้จะถูกเปลี่ยนเป็นไม่ระบุรถ')"><em class="fa fa-trash"></em></button>
                            </form>
                        </td>
                        <td>{{ $productprice->product->id }}</td>
                        <td>{{ $productprice->product->name }}</td>
                        <td>{{ $productprice->product->unit }}</td>
                        <td>{{ $productprice->normal_price }}</td>
                    </tr>
                @endforeach
            @endif           
            </tbody>
        </table>
    </div>
</div>

@endsection
