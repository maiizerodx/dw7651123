@extends('layouts.app')

@push('script')
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script>
$(document).ready(function(){
    $("#selecttype").change(function(){
        $(this).find("option:selected").each(function(){
            if($(this).attr("value")=="1"){
                $("#specialprice").hide();
                $("#specialprice input").prop('required',false);
                $("#specialprice input").val(0);
                $("#normalprice").show();
                $("#normalprice input").prop('required',true);
            }
            else if($(this).attr("value")=="2"){
                $("#normalprice").hide();
                $("#normalprice input").prop('required',false);
                $("#normalprice input").val(0);
                $("#specialprice").show();
                $("#specialprice input").prop('required',true);
            }
            else{
                $(".box").hide();
                $("#normalprice input").val(0);
                $("#specialprice input").val(0);
            }
        });
    }).change();
});
</script>
@endpush

@section('content')
<a href="#"><strong><i class="glyphicon glyphicon-shopping-cart"></i> เพิ่มราคาสินค้า</strong></a>
<hr>
<div class="row">
    <div class="col-md-12">
		<form class="form-horizontal" method="post" action="{{ url('/productprices') }}">
		<input type="hidden" name="customer_id" value="{{$customer_id}}">
		{{ csrf_field() }}
		<input type="hidden" name="_method" value="PUT">
			<fieldset>
			<!-- Text input-->
			<div class="form-group">
			  <label class="col-md-4 control-label" >สินค้า</label>  
			  <div class="col-md-4">
			  <select id="selectbasic" name="product_id" class="form-control">
			    @if($products)
	            	@foreach($products as $product)
				    	<option value="{{$product->id}}" >{{$product->name}}</option>
				    @endforeach
				  @endif
			    </select>
			  </div>
			</div>
			<div class="form-group">
			  <label class="col-md-4 control-label" >ประเภทราคา</label>  
			  <div class="col-md-4">
				  <select id="selecttype" name="price_mode" class="form-control">
					<option value="1">ปกติ</option>
					<option value="2">ลำดับขั้น</option>
				  </select>
			  </div>
			</div>
			<div class="form-group box" id="normalprice">
			  <label class="col-md-4 control-label">ราคาต่อหน่วย</label>  
			  <div class="col-md-4">
			  <input name="normal_price" type="number" step="0.01" placeholder="ราคาต่อหน่วย" class="form-control input-md">
			  </div>
			</div>
			<div class="form-group box" id="specialprice">
			<div class="row">
			  <label class="col-md-4 control-label">ช่วงราคาแรก</label>  
			  <div class="col-md-4">
			  <table cellspacing="2">
			  	<tr>
			  		<td  width="120">ตั้งแต่ 0 กิโลกรัม ถึง</td>
			  		<td  width="100"><input name="step1_amount" type="number" step="0.01" placeholder="น้ำหนัก" class="form-control input-md"></td>
			  		<td>กิโลกรัม</td>
			  	</tr>
			  	<tr>
			  		<td>ราคากิโลกรัมละ</td>
			  		<td><input name="step1_price" type="number" step="0.01" placeholder="ราคา" class="form-control input-md"></td>
			  		<td>บาท</td>
			  	</tr>
			  </table>
			  </div>
			  </div>
			  	<div class="row">
				  <label class="col-md-4 control-label">ช่วงราคาเกินนั้น</label>  
				  <div class="col-md-4">
				  <table cellspacing="2">
				  	<tr>
				  		<td width="120">ราคากิโลกรัมละ</td>
				  		<td width="100"><input name="step2_price" type="number" step="0.01" placeholder="ราคา" class="form-control input-md"></td>
				  		<td width="50"> บาท</td>
				  	</tr>
				  </table>
				</div>
			  </div>
			</div>
			<!-- Button (Double) -->
			<div class="form-group">
			  <label class="col-md-4 control-label"></label>
			  <div class="col-md-8">
			    <input type="submit" name="submit" class="btn btn-success" value="เพิ่ม">
			  </div>
			</div>

			</fieldset>
		</form>
    </div>
</div>

@endsection

