@extends('layouts.app')

@push('styles')
<style type="text/css">
.invoice-title h2, .invoice-title h3 {
    display: inline-block;
}

.table > tbody > tr > .no-line {
    border-top: none;
}

.table > thead > tr > .no-line {
    border-bottom: none;
}

.table > tbody > tr > .thick-line {
    border-top: 2px solid;
}
</style>
@endpush

@push('script')

@endpush

@section('content')
<div class="row">
   	<div class="container">
    <div class="row">
        <div class="col-xs-12">
    		<div class="invoice-title">
    			<h2>รายการสั่งซื้อ</h2><h3 class="pull-right">เลขที่ # 1234</h3>
    		</div>
    		<hr>
   		  <div class="row">
   			<div class="col-xs-6">
    				<address>
    				<strong>ข้อมูลลูกค้า</strong><br>
    				ชื่อ
    				<br>ที่อยู่
   				    </address>
   			  </div>
    		  <div class="col-xs-6 text-right">
   				  <address>
    					<strong>วันทำรายการ:</strong><br>
    					7 มีนาคม 2559<br>
    					<br>
   				</address>
   			  </div>
   		  </div>
    	</div>
    </div>
    
  <div class="row">
   	<div class="col-md-6">
    		<div class="panel panel-default">
    			<div class="panel-heading">
                	<div class="row">
                        <div class="col col-xs-6">
                            <h3 class="panel-title"><strong>รายการสินค้าทั่วไป</strong></h3>
                        </div>
                        <div class="col col-xs-6 text-right">
                            <a href="#" class="btn btn-xs btn-success"> <span class="glyphicon glyphicon-plus"></span></a>
                        </div>
                    </div>
    			</div>
    			<div class="panel-body">
    				<div class="table-responsive">
    				  <table class="table table-condensed">
    				    <thead>
    				      <tr>
    				        <td align="center" width="80"><i class="fa fa-cog"></i></td>
    				        <td><strong>รายการ</strong></td>
    				        <td class="text-center"><strong>ราคาต่อหน่วย</strong></td>
    				        <td class="text-center"><strong>จำนวน</strong></td>
    				        <td class="text-right"><strong>จำนวนเงิน</strong></td>
  				        </tr>
  				      </thead>
    				    <tbody>
    				      <!-- foreach (order->lineItems as line) or some such thing here -->
    				      <tr>
    				        <td align="center"><a class="btn btn-xs btn-default"><em class="fa fa-pencil"></em></a> <a class="btn btn-xs btn-danger"><em class="fa fa-trash"></em></a></td>
    				        <td>ถั่วงอก 1 kg</td>
    				        <td class="text-center">10.99</td>
    				        <td class="text-center">1</td>
    				        <td class="text-right">10.99</td>
  				        </tr>
    				      <tr>
    				        <td align="center"><a class="btn btn-xs btn-default"><em class="fa fa-pencil"></em></a> <a class="btn btn-xs btn-danger"><em class="fa fa-trash"></em></a></td>
    				        <td>ถั่วงอก 5 kg</td>
    				        <td class="text-center">20.00</td>
    				        <td class="text-center">3</td>
    				        <td class="text-right">60.00</td>
  				        </tr>
    				      <tr>
    				        <td align="center"><a class="btn btn-xs btn-default"><em class="fa fa-pencil"></em></a> <a class="btn btn-xs btn-danger"><em class="fa fa-trash"></em></a></td>
    				        <td>ถั่วงอก 10 kg</td>
    				        <td class="text-center">600.00</td>
    				        <td class="text-center">1</td>
    				        <td class="text-right">600.00</td>
  				        </tr>
    				      <tr>
    				        <td class="thick-line"></td>
    				        <td class="thick-line"></td>
    				        <td class="thick-line"></td>
    				        <td class="thick-line text-center"><strong>ยอดรวม</strong></td>
    				        <td class="thick-line text-right">685.99</td>
  				        </tr>
  				      </tbody>
  				    </table>
    				</div>
    			</div>
    		</div>
    	</div>
    	<div class="col-md-6">
    	  <div class="panel panel-default">
    	    <div class="panel-heading">
    	      <div class="row">
                        <div class="col col-xs-6">
                          <h3 class="panel-title"><strong>รายการ ถั่วถัง</strong></h3>
                        </div>
                        <div class="col col-xs-6 text-right">
                            <a href="#" class="btn btn-xs btn-success"> <span class="glyphicon glyphicon-plus"></span></a>
                        </div>
                </div>
  	      </div>
    	    <div class="panel-body">
    	      <div class="table-responsive">
    	        <table class="table table-condensed">
    	          <thead>
    	            <tr>
    	              <td align="center" width="80"><i class="fa fa-cog"></i></td>
    	              <td><strong>ลำดับ</strong></td>
    	              <td class="text-center"><strong>น้ำหนัก</strong></td>
    	              <td class="text-center"><strong>ราคา/กก.</strong></td>
    	              <td class="text-right"><strong>จำนวนเงิน</strong></td>
  	              </tr>
  	            </thead>
    	          <tbody>
    	            <!-- foreach (order->lineItems as line) or some such thing here -->
    	            <tr>
    	              <td align="center"><a class="btn btn-xs btn-default"><em class="fa fa-pencil"></em></a> <a class="btn btn-xs btn-danger"><em class="fa fa-trash"></em></a></td>
    	              <td>1</td>
    	              <td class="text-center">30</td>
    	              <td class="text-center">10.99</td>
    	              <td class="text-right">10.99</td>
  	              </tr>
    	            <tr>
    	              <td align="center"><a class="btn btn-xs btn-default"><em class="fa fa-pencil"></em></a> <a class="btn btn-xs btn-danger"><em class="fa fa-trash"></em></a></td>
    	              <td>2</td>
    	              <td class="text-center">20</td>
    	              <td class="text-center">20.00</td>
    	              <td class="text-right">60.00</td>
  	              </tr>
    	            <tr>
    	              <td align="center"><a class="btn btn-xs btn-default"><em class="fa fa-pencil"></em></a> <a class="btn btn-xs btn-danger"><em class="fa fa-trash"></em></a></td>
    	              <td>3</td>
    	              <td class="text-center">10</td>
    	              <td class="text-center">600.00</td>
    	              <td class="text-right">600.00</td>
  	              </tr>
    	            <tr>
    	              <td class="thick-line"></td>
    	              <td class="thick-line"></td>
    	              <td class="thick-line"></td>
    	              <td class="thick-line text-center"><strong>ยอดรวม</strong></td>
    	              <td class="thick-line text-right">685.99</td>
  	              </tr>
  	            </tbody>
  	          </table>
    	      </div>
  	      </div>
  	    </div>
  	  </div>
      <div class="col-xs-12 text-right">
        <h2>
                <strong>ยอดเงินสุทธิ:</strong><span class="no-line text-right"> 685.99 บาท</span>
        </h2>
      </div>
    </div>
</div>
            </div>
@endsection
