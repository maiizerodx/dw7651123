@extends('layouts.app')

@push('styles')
<link href="https://cdn.datatables.net/1.10.13/css/dataTables.bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<style type="text/css">
.invoice-title h2, .invoice-title h3 {
    display: inline-block;
}

.table > tbody > tr > .no-line {
    border-top: none;
}

.table > thead > tr > .no-line {
    border-bottom: none;
}

.table > tbody > tr > .thick-line {
    border-top: 2px solid;
}
</style>
@endpush

@push('script')
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>
  $( function() {
    $( "#datepicker" ).datepicker({ dateFormat: 'dd M yy'});

  //   $('.selectpicker').on('change', function(){
  //   var selected = $(this).val();
  //   //alert(selected);
  //   $('#unitprice').val(selected);
  // });

  } );
</script>
@endpush

@section('content')
<a href="{{ url('/orders/'.$order->id.'/print') }}" class="btn btn-primary btn-default"><span class="glyphicon glyphicon-print"></span> พิมพ์ บิลเงินสด/ใบส่งของ</a>
แก้ไขรายการ
<hr>
    <div class="row">
        <div class="col-md-12">
    		<div class="invoice-title">
    			<h2>รายการสั่งซื้อ</h2><h3 class="pull-right">เลขที่ # {{$order->id}}</h3>
    		</div>
    		<hr>
   		  <div class="row">
   			<div class="col-md-10">
    				<strong>ข้อมูลลูกค้า</strong>
            <p>
                ชื่อ : {{$order->customer->name}}
                <br>ตลาด : {{$order->customer->market->name}}
                <br>ที่อยู่ : {{$order->customer->address}}
                <br><br>
            </p>
   			  </div>
    		  <div class="col-md-2 text-right">
   				  <address>
    					<strong>วันทำรายการ:</strong><br>
              {{ date( 'd M y', strtotime( $order->order_at )) }}<br>
              <a data-toggle="modal" data-target="#edit-orderdate" class="btn btn-xs btn-warning"><em class="fa fa-pencil"></em> แก้ไขวันที่</a>
   				</address>
   			  </div>
   		  </div>
    	</div>
    </div>
    <!-- Modal -->
      <div id="edit-orderdate" class="modal fade" role="dialog">
        <div class="modal-dialog">

          <!-- Modal content-->
          <div class="modal-content">
          <form class="form-horizontal" method="post" action="{{ url('/orders/'.$order->id) }}">
          <input type="hidden" name="_method" value="PUT">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal">&times;</button>
              <h4 class="modal-title">แก้ไขวันทำรายการ</h4>
            </div>
            <div class="modal-body">
              {{ csrf_field() }}

                <fieldset>
                <!-- Text input-->
                <input type="hidden" name="order_id" value="{{$order->id}}">
                <div class="form-group">

                  <label class="col-md-4 control-label" >วันที่ทำรายการ</label>
                  <div class="col-md-4">
                  <input type="text" class="form-control" id="datepicker" name= "order_at" value="{{ date( 'd M y', strtotime( $order->order_at )) }}">
                  </div>
                </div>
            </div>
            <div class="modal-footer">
              <input type="submit" name="submit" class="btn btn-success" value="บันทึก">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
              </fieldset>
            </form>
          </div>
        </div>
      </div>
    <!-- End Modal -->
    <div class="row">
   	<div class="col-md-6">
    		<div class="panel panel-default">
    			<div class="panel-heading">
                	<div class="row">
                        <div class="col col-md-6">
                            <h3 class="panel-title"><strong>รายการสินค้าทั่วไป</strong></h3>
                        </div>
                        <div class="col col-md-6 text-right">
                            <a data-toggle="modal" data-target="#addproduct-lineitem" class="btn btn-xs btn-success"> <span class="glyphicon glyphicon-plus"></span></a>
                        </div>
                    </div>
    			</div>

    			<div class="panel-body">
    				<div class="table-responsive">
    				  <table class="table table-condensed">
    				    <thead>
    				      <tr>
    				        <td align="center" width="80"><i class="fa fa-cog"></i></td>
    				        <td><strong>รายการ</strong></td>
    				        <td class="text-center"><strong>ราคาต่อหน่วย</strong></td>
    				        <td class="text-center"><strong>จำนวน</strong></td>
    				        <td class="text-right"><strong>จำนวนเงิน</strong></td>
  				        </tr>
  				      </thead>
    				    <tbody>
                  @forelse ($order->product_lineitems as $product_lineitem)
                      <tr>
                    <td align="center">
                      <form action="{{ url('/orders/'.$product_lineitem->id.'/product') }}" method="POST">
                        <input type="hidden" name="_method" value="DELETE">
                        {{ csrf_field() }}
                        <button class='btn btn-danger btn-xs' type="submit" onclick="return confirm('คุณ๖้องการลบรายการนี้ออกใช่ไหม?')"><em class="fa fa-trash"></em></button>
                      </form>
                    </td>
                    <td>{{$product_lineitem->product->name}}</td>
                    <td class="text-center">{{$product_lineitem->price}}</td>
                    <td class="text-center">{{$product_lineitem->qty}}</td>
                    <td class="text-right">{{number_format($product_lineitem->subtotal,2)}}</td>
                  </tr>
                  @empty
                      <tr>
                        <td colspan=5 align="center">ไม่มีรายการ</td>
                      </tr>
                  @endforelse
                  <!-- Total -->
                  <tr>
                    <td class="thick-line"></td>
                    <td class="thick-line"></td>
                    <td class="thick-line"></td>
                    <td class="thick-line text-center"><strong>ยอดรวม</strong></td>
                    <td class="thick-line text-right">{{number_format( $order->product_lineitems->sum('subtotal'),2)}}</td>
                  </tr>
                </tbody>
  				    </table>
    				</div>
    			</div>
    		</div>
    	</div>
      <!-- Modal -->
          <div id="addproduct-lineitem" class="modal fade" role="dialog">
            <div class="modal-dialog">

              <!-- Modal content-->
              <div class="modal-content">
              <form class="form-horizontal" method="post" action="{{ url('/orders/'.$order->id.'/product') }}">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title">เพิ่มรายการสินค้าทั่วไป ...</h4>
                </div>
                <div class="modal-body">
                  {{ csrf_field() }}
                  @if(count($productprices)>0)
                    <fieldset>
                    <!-- Text input-->
                    <div class="form-group">
                      <input type="hidden" name="order_id" value="{{$order->id}}">
                      <label class="col-md-4 control-label" >สินค้า</label>
                      <div class="col-md-4">
                      <select id="selectbasic" name="product_price" class="form-control selectpicker">
                          @foreach($productprices as $productprice)
                            <option value="{{$productprice->id}}">{{$productprice->product->name}}</option>
                          @endforeach
                        </select>
                      </div>
                    </div>
                    {{-- <div class="form-group">
                      <label class="col-md-4 control-label">ราคาต่อหน่วย</label>
                      <div class="col-md-4">
                      <input id="unitprice" type="text" placeholder="ราคาต่อหน่วย" class="form-control input-md" readonly>
                      </div>
                    </div> --}}
                    <div class="form-group">
                      <label class="col-md-4 control-label">จำนวน</label>
                      <div class="col-md-4">
                      <input name="qty" type="number" step="0.01" placeholder="จำนวน" class="form-control input-md" required="">
                      </div>
                    </div>
                    @else
                      ลูกค้าคนนี้ยังไม่ได้ทำการกำหนดราคาของสินค้า
                    @endif
                </div>
                <div class="modal-footer">
                  @if(count($productprices)>0)<input type="submit" name="submit" class="btn btn-success" value="เพิ่ม">@endif
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
                  </fieldset>
                </form>
              </div>
            </div>
          </div>
      <!-- End Modal -->
    	<div class="col-md-6">
    	  <div class="panel panel-default">
    	    <div class="panel-heading">
    	      <div class="row">
                        <div class="col col-md-6">
                          <h3 class="panel-title"><strong>รายการ ถั่วถัง</strong></h3>
                        </div>
                        <div class="col col-md-6 text-right">
                            <a data-toggle="modal" data-target="#addbucket-lineitem" class="btn btn-xs btn-success"> <span class="glyphicon glyphicon-plus"></span></a>
                        </div>
                </div>
  	      </div>
    	    <div class="panel-body">
    	      <div class="table-responsive">
    	        <table class="lineitems table table-condensed">
    	          <thead>
    	            <tr>
    	              <td align="center" width="80"><i class="fa fa-cog"></i></td>
    	              <td><strong>ลำดับ</strong></td>
    	              <td class="text-center"><strong>น้ำหนัก</strong></td>
    	              <td class="text-center"><strong>ราคา/กก.</strong></td>
    	              <td class="text-right"><strong>จำนวนเงิน</strong></td>
  	              </tr>
  	            </thead>
    	          <tbody>
                <?php $i = 1;?>
                  @forelse ($order->bucket_lineitems as $bucket_lineitem)
                      <tr>
                    <td align="center">
                      <form action="{{ url('/orders/'.$bucket_lineitem->id.'/bucket') }}" method="POST">
                        <input type="hidden" name="_method" value="DELETE">
                        {{ csrf_field() }}
                        <button class='btn btn-danger btn-xs' type="submit" onclick="return confirm('คุณ๖้องการลบรายการนี้ออกใช่ไหม?')"><em class="fa fa-trash"></em></button>
                      </form>
                    </td>
                    <td class="text-center"><?php echo $i;?></td>
                    <td class="text-center">{{$bucket_lineitem->weight}}</td>
                    <td class="text-center">{{$bucket_lineitem->price}}</td>
                    <td class="text-right">{{number_format($bucket_lineitem->subtotal,2)}}</td>
                  </tr>
                  <?php $i++;?>
                  @empty
                      <tr>
                        <td colspan=5 align="center">ไม่มีรายการ</td>
                      </tr>
                  @endforelse
                  <!-- Total -->
                  <tr>
                    <td class="thick-line"></td>
                    <td class="thick-line"></td>
                    <td class="thick-line"></td>
                    <td class="thick-line text-center"><strong>ยอดรวม</strong></td>
                    <td class="thick-line text-right">{{number_format( $order->bucket_lineitems->sum('subtotal'),2)}}</td>
                  </tr>
                </tbody>
  	          </table>
    	      </div>
  	      </div>
  	    </div>
  	  </div>
      <!-- Modal -->
          <div id="addbucket-lineitem" class="modal fade" role="dialog">
            <div class="modal-dialog">

              <!-- Modal content-->
              <div class="modal-content">
              <form class="form-horizontal" method="post" action="{{ url('/orders/'.$order->id.'/bucket') }}">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title">เพิ่มรายการถั่วถัง</h4>
                </div>
                <div class="modal-body">
                  {{ csrf_field() }}
                  @if($bucketprice)
                  <input type="hidden" name="order_id" value="{{$order->id}}">
                  <input type="hidden" name="product_price" value="{{$bucketprice->id}}">
                    <fieldset>
                    <!-- Text input-->
                    <div class="form-group">
                      <label class="col-md-4 control-label">น้ำหนัก</label>
                      <div class="col-md-4">
                      <input name="weight" type="number" step="0.01" placeholder="จำนวน" class="form-control input-md" required="">
                      </div>
                    </div>
                  @else
                    ลูกค้าคนนี้ยังไม่ได้ทำการกำหนดราคาของถั่วถัง
                  @endif
                </div>
                <div class="modal-footer">
                  @if($bucketprice)<input type="submit" name="submit" class="btn btn-success" value="เพิ่ม">@endif
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
                  </fieldset>
                </form>
              </div>
            </div>
          </div>
      <!-- End Modal -->
      <div class="col-md-12 text-right">
        <h2>
            <strong>ยอดเงินสุทธิ:</strong><span class="no-line text-right"> {{number_format(($order->bucket_lineitems->sum('subtotal') + $order->product_lineitems->sum('subtotal')),2)}} บาท</span>
        </h2>
      </div>
    </div>
@endsection
