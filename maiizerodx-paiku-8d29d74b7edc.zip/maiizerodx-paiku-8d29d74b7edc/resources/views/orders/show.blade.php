@extends('layouts.app')

@push('styles')
<link href="https://cdn.datatables.net/1.10.13/css/dataTables.bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<style type="text/css">
.invoice-title h2, .invoice-title h3 {
    display: inline-block;
}

.table > tbody > tr > .no-line {
    border-top: none;
}

.table > thead > tr > .no-line {
    border-bottom: none;
}

.table > tbody > tr > .thick-line {
    border-top: 2px solid;
}
</style>
@endpush

@push('script')
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/r/bs-3.3.5/jqc-1.11.3,dt-1.10.8/datatables.min.js"></script>
<script type="text/javascript" src="//cdn.datatables.net/plug-ins/1.10.13/i18n/Thai.json"></script>
<script>
$( function() {
  $( "#datepicker" ).datepicker({ dateFormat: 'dd/mm/yy'});
} );

</script>
@endpush

@section('content')
<a href="{{ url('/orders/'.$order->id.'/edit') }}" class="btn btn-primary btn-warning"><span class="glyphicon glyphicon-edit"></span> แก้ไข</a>
<a href="{{ url('/orders/'.$order->id.'/print') }}" class="btn btn-primary btn-default"><span class="glyphicon glyphicon-print"></span> พิมพ์ ใบส่งของ/บิลเงินสด</a>
{{-- <a href="{{ url('/orders/'.$order->id.'/print') }}" class="btn btn-primary btn-default"><span class="glyphicon glyphicon-print"></span> พิมพ์ บิลเงินสด</a> --}}
{{-- <a href="#" class="btn btn-primary btn-default"><span class="glyphicon glyphicon-print"></span> พิมพ์</a> --}}
<hr>
    <div class="row">
        <div class="col-md-12">
        <div class="invoice-title">
          <h2>รายการสั่งซื้อ</h2><h3 class="pull-right">เลขที่ # {{$order->id}}</h3>
        </div>
        <hr>
      </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <strong>ข้อมูลลูกค้า</strong>
            <p>
                ชื่อ : {{$order->customer->name}}
                <br>ตลาด : {{$order->customer->market->name}}
                <br>ที่อยู่ : {{$order->customer->address}}
                <br><br>
            </p>
          </div>
          <div class="col-md-6 text-right">
            <address>
              <strong>วันทำรายการ:</strong><br>
              {{date( 'd/m/Y', strtotime( $order->order_at ) )}}<br>
              <br>
          </address>
          </div>
        </div>
    <div class="row">
    <div class="col-md-6">
        <div class="panel panel-default">
          <div class="panel-heading">
                  <div class="row">
                        <div class="col col-md-6">
                            <h3 class="panel-title"><strong>รายการสินค้าทั่วไป</strong></h3>
                        </div>
                        <div class="col col-md-6 text-right">
                            {{-- <a href="#" class="btn btn-xs btn-success"> <span class="glyphicon glyphicon-plus"></span></a> --}}
                        </div>
                    </div>
          </div>
          <div class="panel-body">
            <div class="table-responsive">
              <table class="table table-condensed">
                <thead>
                  <tr>
                    {{-- <td align="center" width="80"><i class="fa fa-cog"></i></td> --}}
                    <td><strong>รายการ</strong></td>
                    <td class="text-center"><strong>ราคาต่อหน่วย</strong></td>
                    <td class="text-center"><strong>จำนวน</strong></td>
                    <td class="text-right"><strong>จำนวนเงิน</strong></td>
                  </tr>
                </thead>
                <tbody>
                  @forelse ($order->product_lineitems as $product_lineitem)
                      <tr>
                    {{-- <td align="center"><a class="btn btn-xs btn-default"><em class="fa fa-pencil"></em></a> <a class="btn btn-xs btn-danger"><em class="fa fa-trash"></em></a></td> --}}
                    <td>{{$product_lineitem->product->name}}</td>
                    <td class="text-center">{{$product_lineitem->price}}</td>
                    <td class="text-center">{{$product_lineitem->qty}}</td>
                    <td class="text-right">{{$product_lineitem->subtotal}}</td>
                  </tr>
                  @empty
                      <tr>
                        <td colspan=5 align="center">ไม่มีรายการ</td>
                      </tr>
                  @endforelse
                  <!-- Total -->
                  <tr>
                    {{-- <td class="thick-line"></td> --}}
                    <td class="thick-line"></td>
                    <td class="thick-line"></td>
                    <td class="thick-line text-center"><strong>ยอดรวม</strong></td>
                    <td class="thick-line text-right">{{number_format( $order->product_lineitems->sum('subtotal'),2)}}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="panel panel-default">
          <div class="panel-heading">
            <div class="row">
                        <div class="col col-md-6">
                          <h3 class="panel-title"><strong>รายการ ถั่วถัง</strong></h3>
                        </div>
                        <div class="col col-md-6 text-right">
                            {{-- <a href="#" class="btn btn-xs btn-success"> <span class="glyphicon glyphicon-plus"></span></a> --}}
                        </div>
                </div>
          </div>
          <div class="panel-body">
            <div class="table-responsive">
              <table class="lineitems table table-condensed">
                <thead>
                  <tr>
                    {{-- <td align="center" width="80"><i class="fa fa-cog"></i></td> --}}
                    <td class="text-center"><strong>ลำดับ</strong></td>
                    <td class="text-center"><strong>น้ำหนัก</strong></td>
                    <td class="text-center"><strong>ราคา/กก.</strong></td>
                    <td class="text-right"><strong>จำนวนเงิน</strong></td>
                  </tr>
                </thead>
                <tbody>
                <?php $i = 1;?>
                  @forelse ($order->bucket_lineitems as $bucket_lineitem)
                      <tr>
                    {{-- <td align="center"><a class="btn btn-xs btn-default"><em class="fa fa-pencil"></em></a> <a class="btn btn-xs btn-danger"><em class="fa fa-trash"></em></a></td> --}}
                    <td class="text-center"><?php echo $i;?></td>
                    <td class="text-center">{{$bucket_lineitem->weight}}</td>
                    <td class="text-center">{{$bucket_lineitem->price}}</td>
                    <td class="text-right">{{$bucket_lineitem->subtotal}}</td>
                  </tr>
                  <?php $i++;?>
                  @empty
                      <tr>
                        <td colspan=5 align="center">ไม่มีรายการ</td>
                      </tr>
                  @endforelse
                  <!-- Total -->
                  <tr>
                    {{-- <td class="thick-line"></td> --}}
                    <td class="thick-line"></td>
                    <td class="thick-line"></td>
                    <td class="thick-line text-center"><strong>ยอดรวม</strong></td>
                    <td class="thick-line text-right">{{number_format( $order->bucket_lineitems->sum('subtotal'),2)}}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-12 text-right">
        <h2>
                <strong>ยอดเงินสุทธิ:</strong><span class="no-line text-right"> {{number_format(($order->bucket_lineitems->sum('subtotal') + $order->product_lineitems->sum('subtotal')),2)}} บาท</span>
        </h2>
      </div>
    </div>
@endsection
