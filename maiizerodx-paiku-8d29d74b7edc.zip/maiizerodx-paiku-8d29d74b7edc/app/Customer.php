<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    //
    protected $fillable = [
    	'car_id',
    	'market_id',
    	'name',
    	'telephone',
    	'address',
    	'customer_type_id',
        'customer_priority',
        'auto_bill_print'
    	];
    	
    public function car()
    {
        return $this->belongsTo('App\Car');
    }

    public function market()
    {
        return $this->belongsTo('App\Market');
    }

    public function customerType()
    {
        return $this->belongsTo('App\CustomerType');
    }

    public function productprices()
    {
        return $this->hasMany('App\CustomerProductPrice');
    }

    public function orders()
    {
        return $this->hasMany('App\Order');
    }
}
