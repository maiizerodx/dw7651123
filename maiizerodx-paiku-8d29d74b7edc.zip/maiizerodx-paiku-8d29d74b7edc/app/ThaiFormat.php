<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DateTime;

class ThaiFormat
{
    //

    public static function fulldate($time){
	    //echo date("w",strtotime($time));
	    $thai_day_arr = array("อาทิตย์","จันทร์","อังคาร","พุธ","พฤหัสบดี","ศุกร์","เสาร์");
		$thai_month_arr=array(
		    "0"=>"",
		    "1"=>"มกราคม",
		    "2"=>"กุมภาพันธ์",
		    "3"=>"มีนาคม",
		    "4"=>"เมษายน",
		    "5"=>"พฤษภาคม",
		    "6"=>"มิถุนายน", 
		    "7"=>"กรกฎาคม",
		    "8"=>"สิงหาคม",
		    "9"=>"กันยายน",
		    "10"=>"ตุลาคม",
		    "11"=>"พฤศจิกายน",
		    "12"=>"ธันวาคม"                 
		);

	    $thai_date_return= "วัน".$thai_day_arr[date("w",strtotime($time))];
	    $thai_date_return.= "ที่ ".date("j",strtotime($time));
	    $thai_date_return.= " ".$thai_month_arr[date("n",strtotime($time))];
	    $thai_date_return.= " พ.ศ. ".(date("Yํ",strtotime($time))+543);
	    //$thai_date_return.= "  เวลา".date("H:i",strtotime($time))." น.";
	    return $thai_date_return;
	}

	public static function numtothaistring($num)
	{
		$return_str = "";
		$txtnum1 = array('','หนึ่ง','สอง','สาม','สี่','ห้า','หก','เจ็ด','แปด','เก้า');
		$txtnum2 = array('','สิบ','ร้อย','พัน','หมื่น','แสน','ล้าน');
		$num_arr = str_split($num);
		$count = count($num_arr);
		foreach($num_arr as $key=>$val)
		{
			if($count > 1 && $val == 1 && $key ==($count-1))
			$return_str .= "เอ็ด";
			else
			$return_str .= $txtnum1[$val].$txtnum2[$count-$key-1];
		}
		return $return_str ;
	}

	public static function numtothai($num)
	{
		$return = "";
		$num = str_replace(",","",$num);
		$number = explode(".",$num);
		if(sizeof($number)>2){
			return 'รูปแบบข้อมุลไม่ถูกต้อง';
			exit;
		}
		$return .= numtothaistring($number[0])."บาท";
		
		$stang = intval($number[1]);
		if($stang > 0)
			$return.= numtothaistring($stang)."สตางค์";
		else
			$return .= "ถ้วน";
		return $return ;
	}
}
