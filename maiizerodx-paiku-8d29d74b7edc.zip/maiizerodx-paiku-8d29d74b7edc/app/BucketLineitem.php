<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BucketLineitem extends Model
{
    //
    protected $fillable = [
    	'order_id',
    	'weight',
    	'price',
    	'subtotal'
    	];

    public function order()
    {
        return $this->belongsTo('App\Order');
    }
}
