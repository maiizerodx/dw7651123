<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    //
    protected $fillable = [
    	'user_id',
    	'customer_id'
    	];

    public function user()
    {
        return $this->belongsTo('App\User');
    }

    public function customer()
    {
        return $this->belongsTo('App\Customer');
    }

    public function product_lineitems()
    {
        return $this->hasMany('App\ProductLineitem');
    }

    public function bucket_lineitems()
    {
        return $this->hasMany('App\BucketLineitem');
    }

}
