<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReportsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $customers = \App\Customer::all();
        $cars = \App\Car::all();

        // foreach($customers as $customer){
        //   echo $customer->id.' : '.$customer->name.' - '.$customer->market->name." <br>";
        // }

        return view('reports.selectdaterange',compact('customers','cars'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function showall()
    {
        //
    }

    public function showcar(Request $request)
    {
        $date_q = date( 'Y-m-d', strtotime( $request->dateValue ));
        $id = $request->car_id;
        //$customers = \App\Customer::with('orders')->where('car_id',$id)->get();
        $customers = \App\Customer::where('car_id',$id)->get();

        //echo print_r($customers)."<hr>";

        $datas = array();
        $total = array();
        $total['p1'] = 0;
        $total['p2'] = 0;
        $total['p3'] = 0;
        $total['p4'] = 0;
        $total['p5'] = 0;
        $total['p6'] = 0;
        $total['p7'] = 0;
        $total['p8'] = 0;
        $total['num_b'] = 0;
        $total['sum_b'] = 0;

        foreach ($customers as $customer) {
            $data = array();
            $data['name'] = $customer->name;
            $data['market'] = $customer->market->name;
            $orders = \App\Order::with('product_lineitems','bucket_lineitems')->where('customer_id',$customer->id)->whereDate('order_at',$date_q)->get();

            //echo count($orders)."<hr>";
            for ($i=1; $i <= 8 ; $i++) {
                $data['p'.$i] = 0;
            }
            $data['num_b']=0;
            $data['list_b']="";

            if(count($orders)>0)
            {
                foreach ($orders as $order) {

                    for ($i=1; $i <= 8 ; $i++) {
                        $temps = $order->product_lineitems()->where('product_id',$i)->get();
                        // $data['p'.$i] = 0;
                        if(count($temps)>0)
                        {
                           foreach ($temps as $temp) {
                               $data['p'.$i] += $temp->qty;
                               $total['p'.$i] += $temp->qty;
                           }
                        }
                    }

                    $temps1 = $order->bucket_lineitems()->get();
                    // $data['num_b']=0;
                    // $data['list_b']="";
                    if(count($temps1)>0)
                    {
                        $temp_w = 0;
                       foreach ($temps1 as $temp1) {
                            $temp_w += $temp1->weight;
                            $data['list_b'] .= number_format ($temp1->weight);
                            $data['list_b'] .= ' ';
                            $data['num_b']++;
                       }
                       $total['num_b'] +=$data['num_b'];
                       $total['sum_b'] +=$temp_w;
                    }
                }
            }

            array_push($datas,$data);
        }
        //echo print_r($datas);
        //echo print_r($total);
        return view('layouts.singlecardailyreport',compact('date_q','datas','total'));
    }

    public function showallcar($date_q)
    {
        //$customers = \App\Customer::with('orders')->where('car_id',$id)->get();
        // $customers = \App\Customer::with(['orders' => function ($query) {
        //             $query->whereDate('order_at','2017-01-07');
        //         }])->where('car_id',$id)->get();
        $count = \App\Car::all()->count();
        $customers = \App\Customer::with('orders.product_lineitems','orders.bucket_lineitems')->get();
        $allcars = array();
        $total = array();
        for ($id=1; $id <= $count ; $id++) {
            $datas = array();
            $total[$id]['p1'] = 0;
            $total[$id]['p2'] = 0;
            $total[$id]['p3'] = 0;
            $total[$id]['p4'] = 0;
            $total[$id]['p5'] = 0;
            $total[$id]['p6'] = 0;
            $total[$id]['p7'] = 0;
            $total[$id]['p8'] = 0;
            $total[$id]['num_b'] = 0;
            $total[$id]['sum_b'] = 0;
            foreach ($customers as $customer) {
                if($customer->car_id == $id)
                {
                    $data = array();
                    $data['market'] = $customer->market->name;
                    $data['name'] = $customer->name;
                    $total[$id]['car'] = $customer->car->name;

                    $temps = $customer->orders()->whereDate('order_at',$date_q)->get();
                    $data['p1'] = 0;
                    $data['p2'] = 0;
                    $data['p3'] = 0;
                    $data['p4'] = 0;
                    $data['p5'] = 0;
                    $data['p6'] = 0;
                    $data['p7'] = 0;
                    $data['p8'] = 0;
                    $data['num_b']=0;
                    $data['list_b']="";
                    if(count($temps)>0)
                    {
                        for ($i=1; $i <= 8 ; $i++) {
                            $temps2 = $temps[0]->product_lineitems()->where('product_id',$i)->get();
                            if(count($temps2)>0)
                            {
                               foreach ($temps2 as $temp) {
                                   $data['p'.$i] = $temp->qty;
                                   $total[$id]['p'.$i] += $data['p'.$i];
                               }
                            }
                        }

                        $temps1 =  $temps[0]->bucket_lineitems()->get();
                        if(count($temps1) > 0)
                        {
                            $temp_w = 0;
                           foreach ($temps1 as $temp1) {
                                $temp_w += $temp1->weight;
                                $data['list_b'] .= number_format ($temp1->weight);
                                $data['list_b'] .= ' ';
                                $data['num_b']++;
                           }
                           $total[$id]['num_b'] +=$data['num_b'];
                           $total[$id]['sum_b'] +=$temp_w;
                        }
                    }
                    array_push($datas,$data);
                }
            }
            array_push($allcars,$datas);
        }
        echo print_r($allcars);
        //echo print_r($total);
        //return view('layouts.cardailyreport',compact('date_q','allcars','total'));
    }

    public function printSummaryByDate(Request $request)
    {
        $date_q = date( 'Y-m-d', strtotime( $request->dateValue ));
        $cars = \App\Car::all();

        $allcars = array();
        $total = array();

        foreach ($cars as $car) {
            $id = $car->id;
            $customers = \App\Customer::where('car_id',$id)->get();

            $datas = array();
            $total[$id]['p1'] = 0;
            $total[$id]['p2'] = 0;
            $total[$id]['p3'] = 0;
            $total[$id]['p4'] = 0;
            $total[$id]['p5'] = 0;
            $total[$id]['p6'] = 0;
            $total[$id]['p7'] = 0;
            $total[$id]['p8'] = 0;
            $total[$id]['num_b'] = 0;
            $total[$id]['sum_b'] = 0;

            $total[$id]['car'] = $car->name;


            if(count($customers)>0){
                foreach ($customers as $customer) {
                    $data = array();
                    $data['name'] = $customer->name;
                    $data['market'] = $customer->market->name;

                    $orders = \App\Order::with('product_lineitems','bucket_lineitems')->where('customer_id',$customer->id)->whereDate('order_at',$date_q)->get();

                    //echo count($orders)."<hr>";
                    for ($i=1; $i <= 8 ; $i++) {
                        $data['p'.$i] = 0;
                    }
                    $data['num_b']=0;
                    $data['list_b']="";

                    if(count($orders)>0)
                    {
                        foreach ($orders as $order) {

                            for ($i=1; $i <= 8 ; $i++) {
                                $temps = $order->product_lineitems()->where('product_id',$i)->get();
                                // $data['p'.$i] = 0;
                                if(count($temps)>0)
                                {
                                   foreach ($temps as $temp) {
                                       $data['p'.$i] += $temp->qty;
                                       $total[$id]['p'.$i] += $temp->qty;
                                   }
                                }
                            }

                            $temps1 = $order->bucket_lineitems()->get();
                            // $data['num_b']=0;
                            // $data['list_b']="";
                            if(count($temps1)>0)
                            {
                                $temp_w = 0;
                               foreach ($temps1 as $temp1) {
                                    $temp_w += $temp1->weight;
                                    $data['list_b'] .= number_format ($temp1->weight);
                                    $data['list_b'] .= ' ';
                                    $data['num_b']++;
                               }
                               $total[$id]['num_b'] +=$data['num_b'];
                               $total[$id]['sum_b'] +=$temp_w;
                            }
                        }
                    }
                    $datas['car_id'] = $car->id;
                    array_push($datas,$data);
                }
                array_push($allcars,$datas);
            }

        }

        return view('layouts.cardailyreport',compact('date_q','allcars','total'));
    }

    // public function printSummaryByDate(Request $request)
    // {
    //     //
    //     //$customers = \App\Customer::with('orders')->where('car_id',$id)->get();
    //     // $customers = \App\Customer::with(['orders' => function ($query) {
    //     //             $query->whereDate('order_at','2017-01-07');
    //     //         }])->where('car_id',$id)->get();
    //     $count = \App\Car::all()->count();
    //     $products = \App\Product::all();
    //     $date_q = $request->dateValue;
    //     $customers = \App\Customer::with('orders.product_lineitems','orders.bucket_lineitems')->get();
    //     $allcars = array();
    //     $total = array();
    //     for ($id=1; $id <= $count ; $id++) {
    //         $datas = array();
    //         $total[$id]['p1'] = 0;
    //         $total[$id]['p2'] = 0;
    //         $total[$id]['p3'] = 0;
    //         $total[$id]['p4'] = 0;
    //         $total[$id]['p5'] = 0;
    //         $total[$id]['p6'] = 0;
    //         $total[$id]['p7'] = 0;
    //         $total[$id]['p8'] = 0;
    //         $total[$id]['num_b'] = 0;
    //         $total[$id]['sum_b'] = 0;
    //         foreach ($customers as $customer) {
    //             if($customer->car_id == $id)
    //             {
    //                 $data = array();
    //                 $data['market'] = $customer->market->name;
    //                 $data['name'] = $customer->name;
    //                 $total[$id]['car'] = $customer->car->name;

    //                 $temps = $customer->orders()->whereDate('order_at',$date_q)->get();
    //                 $data['p1'] = 0;
    //                 $data['p2'] = 0;
    //                 $data['p3'] = 0;
    //                 $data['p4'] = 0;
    //                 $data['p5'] = 0;
    //                 $data['p6'] = 0;
    //                 $data['p7'] = 0;
    //                 $data['p8'] = 0;
    //                 $data['num_b']=0;
    //                 $data['list_b']="";
    //                 if(count($temps)>0)
    //                 {
    //                     for ($i=1; $i <= 8 ; $i++) {
    //                         $temps2 = $temps[0]->product_lineitems()->where('product_id',$i)->get();
    //                         if(count($temps2)>0)
    //                         {
    //                            foreach ($temps2 as $temp) {
    //                                $data['p'.$i] = $temp->qty;
    //                                $total[$id]['p'.$i] += $data['p'.$i];
    //                            }
    //                         }
    //                     }

    //                     $temps1 =  $temps[0]->bucket_lineitems()->get();
    //                     if(count($temps1) > 0)
    //                     {
    //                         $temp_w = 0;
    //                        foreach ($temps1 as $temp1) {
    //                             $temp_w += $temp1->weight;
    //                             $data['list_b'] .= number_format ($temp1->weight);
    //                             $data['list_b'] .= ' ';
    //                             $data['num_b']++;
    //                        }
    //                        $total[$id]['num_b'] +=$data['num_b'];
    //                        $total[$id]['sum_b'] +=$temp_w;
    //                     }
    //                 }
    //                 array_push($datas,$data);
    //             }
    //         }
    //         array_push($allcars,$datas);
    //     }
    //     //echo print_r($allcars);
    //     //echo print_r($total);
    //     return view('layouts.cardailyreport',compact('date_q','allcars','total','products'));
    // }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function printBillByDateRange(Request $request)
    {
        //
        //return ("ตั้งแต่วันที่ " . $request->startDate ." จนถึง ". $request->endDate);
        $from = date( 'Y-m-d H:i:s', strtotime( $request->startDate ));
        $to = date( 'Y-m-d H:i:s', strtotime( $request->endDate .'+1 days'));

        $orders = \App\Order::where('order_at','>=', $from)
                    ->where('order_at','<', $to) //whereBetween('order_at', [$from, $to])
                    ->where('customer_id',$request->customer_id)
                    ->orderBy('order_at','asc')
                    ->get();
        $products = \App\Product::all();
        $customer = \App\Customer::findOrFail($request->customer_id);

        // echo "ชื่อ :" . $customer->name;
        // echo "<br>ตลาด :" . $customer->market->name;
        // echo "<br>ช่วงวันทำรายการ :" . $request->startDate . " - " . $request->endDate ;
        // echo "<hr>";

        $header = array();
        $header['name'] = $customer->name;
        $header['market'] = $customer->market->name;
        $header['startDate'] = date( 'd / m / Y', strtotime( $request->startDate ));
        $header['endDate'] = date( 'd / m / Y', strtotime( $request->endDate ));

        $total = array();
        $total['p1_price'] = 0;
        $total['p2_price'] = 0;
        $total['p3_price'] = 0;
        $total['p4_price'] = 0;
        $total['p5_price'] = 0;
        $total['p6_price'] = 0;
        $total['p7_price'] = 0;
        $total['p8_price'] = 0;
        $total['b_price'] = 0;
        $total['p1'] = 0;
        $total['p2'] = 0;
        $total['p3'] = 0;
        $total['p4'] = 0;
        $total['p5'] = 0;
        $total['p6'] = 0;
        $total['p7'] = 0;
        $total['p8'] = 0;
        $total['b_num'] = 0;
        $total['b_weight'] = 0;

        $orderDatas = array();
        // echo $orders->count();
        if($orders->count()) {
            //var_dump($orders);
            $iList = 1;
            $totalAll = 0;
            foreach ($orders as $order) {
                # code...
                // if($order->customer->id != $request->customer_id)
                //     continue;

                $orderData = array();
                $orderData['date'] = date( 'd ', strtotime( $order->order_at ));
                $orderData['p1'] = 0;
                $orderData['p2'] = 0;
                $orderData['p3'] = 0;
                $orderData['p4'] = 0;
                $orderData['p5'] = 0;
                $orderData['p6'] = 0;
                $orderData['p7'] = 0;
                $orderData['p8'] = 0;
                $orderData['b_num']=0;
                $orderData['b_list']="";
                $orderData['b_total']=0;

                for ($i=1; $i <= 8 ; $i++) {
                    $tempProduct = $order->product_lineitems()->where('product_id',$i)->get();
                    if(count($tempProduct)>0)
                    {
                       foreach ($tempProduct as $temp) {
                        //echo 'p'.$i.'_price';
                           $orderData['p'.$i] = $temp->qty;
                           $total['p'.$i] += $temp->qty;
                           $total['p'.$i.'_price'] += $temp->subtotal;
                       }
                    }
                }

                $tempBucket =  $order->bucket_lineitems()->get();
                if(count($tempBucket) > 0)
                {
                    //$temp_w = 0;
                    //$orderData['b_total']=0;
                    foreach ($tempBucket as $temp2) {
                        $orderData['b_total'] += $temp2->weight;
                        $orderData['b_list'] .= number_format ($temp2->weight);
                        $orderData['b_list'] .= ' ';
                        $orderData['b_num']++;
                        $total['b_price'] += $temp2->subtotal;
                   }
                   $total['b_num'] +=$orderData['b_num'];
                   $total['b_weight'] +=$orderData['b_total'];
                }
                $orderTotal = $order->bucket_lineitems->sum('subtotal') + $order->product_lineitems->sum('subtotal');
                // echo "$iList | ". date( 'd / m / Y', strtotime( $order->order_at )) . " | " . number_format($orderTotal,2) . "<br>" ;
                $iList++;
                $totalAll += $orderTotal;
                array_push($orderDatas,$orderData);
            }

            // var_dump($orderDatas);
            // var_dump($total);
            // echo "<hr>" . number_format($totalAll,2);

        }else{
            echo 'No data';
        }
        //var_dump($orders);
        return view('layouts.periodrecript',compact('header','orderDatas','total','totalAll'));
    }

    public function printAutoBillOnDate(Request $request)
    {
        $date_q = date( 'Y-m-d', strtotime( $request->onDate ));
        $date_end = date( 'Y-m-d', strtotime( $request->onDate .'+1 days'));

        $car_select = $request->car_id;

        $orders = \App\Order::with('product_lineitems','bucket_lineitems','customer')
                    ->where('order_at','>=', $date_q)
                    ->where('order_at','<', $date_end)
                    ->orderBy('customer_id', 'ASC')
                    ->get();
        //return response()->json($orders);
        // $orders = DB::table('orders')
        //         ->whereDate('order_at', $date_q)
        //         ->get();
        //return $date_q . $orders;
        $products = \App\Product::all();
        $bills = array();
        //$temps = $customer->orders()->whereDate('order_at',$date_q)->get();
        if(count($orders)>0)
        {
            foreach ($orders as $order) {

                if($car_select != $order->customer->car_id)
                    continue;

                if(($request->printMode == 'cashbill') && ($order->customer->auto_bill_print != 1))
                    continue;

                if(($request->printMode != 'cashbill') && ($order->customer->auto_bill_print == 1))
                    continue;

                $data = array();
                $data['order_id'] = $order->id;
                $data['car_name'] = $order->customer->car->name;
                $data['customer_no'] = $order->customer->id;//customer_priority;
                $data['customer_name'] = $order->customer->name;
                $data['mareket_name'] = $order->customer->market->name;
                $data['printDate'] =$request->onDate;

                $data['p1'] = "";
                $data['p2'] = "";
                $data['p3'] = "";
                $data['p4'] = "";
                $data['p5'] = "";
                $data['p6'] = "";
                $data['p7'] = "";
                $data['p8'] = "";
                $data['p1_amount'] = "";
                $data['p2_amount'] = "";
                $data['p3_amount'] = "";
                $data['p4_amount'] = "";
                $data['p5_amount'] = "";
                $data['p6_amount'] = "";
                $data['p7_amount'] = "";
                $data['p8_amount'] = "";
                $data['num_b']=0;
                $data['list_b']="";
                $data['b_amount'] = "";
                $data['total_amount'] = "";

                for ($i=1; $i <= 8 ; $i++) {
                    $temps2 = $order->product_lineitems()->where('product_id',$i)->get();
                    if(count($temps2)>0)
                    {
                       foreach ($temps2 as $temp) {
                           $data['p'.$i] += $temp->qty;
                           $data['p'.$i.'_amount'] += $temp->subtotal;
                           //$total[$id]['p'.$i] += $data['p'.$i];
                       }
                       $data['total_amount'] +=$data['p'.$i.'_amount'];
                    }
                }

                $temps1 =  $order->bucket_lineitems()->get();
                if(count($temps1) > 0)
                {
                    $temp_w = 0;
                   foreach ($temps1 as $temp1) {
                        $temp_w += $temp1->weight;
                        $data['list_b'] .= number_format ($temp1->weight);
                        $data['list_b'] .= ' ';
                        $data['num_b']++;
                        $data['b_amount'] += $temp1->subtotal;
                   }
                   $data['total_amount'] +=$data['b_amount'];
                   //$total[$id]['num_b'] +=$data['num_b'];
                   //$total[$id]['sum_b'] +=$temp_w;
                }
                array_push($bills,$data);
            }

        }
        if($request->printMode == 'cashbill')
            return view('layouts.p_cashbill',compact('bills','products'));
        else
            return view('layouts.p_billingnote',compact('bills','products'));
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function printBillByOrderID($id)
    {
        //
        $order = \App\Order::findOrFail($id);
        $products = \App\Product::all();
        //$temps = $customer->orders()->whereDate('order_at',$date_q)->get();
        $data = array();
        $data['order_id'] = $order->id;
        $data['car_name'] = $order->customer->car->name;
        $data['customer_no'] = $order->customer->id;//customer_priority;
        $data['customer_name'] = $order->customer->name;
        $data['mareket_name'] = $order->customer->market->name;
        $data['printDate'] =$order->order_at;

        $data['p1'] = "";
        $data['p2'] = "";
        $data['p3'] = "";
        $data['p4'] = "";
        $data['p5'] = "";
        $data['p6'] = "";
        $data['p7'] = "";
        $data['p8'] = "";
        $data['p1_amount'] = "";
        $data['p2_amount'] = "";
        $data['p3_amount'] = "";
        $data['p4_amount'] = "";
        $data['p5_amount'] = "";
        $data['p6_amount'] = "";
        $data['p7_amount'] = "";
        $data['p8_amount'] = "";
        $data['num_b']=0;
        $data['list_b']="";
        $data['b_amount'] = "";
        $data['total_amount'] = "";
        if(count($order)>0)
        {
            for ($i=1; $i <= 8 ; $i++) {
                $temps2 = $order->product_lineitems()->where('product_id',$i)->get();
                if(count($temps2)>0)
                {
                   foreach ($temps2 as $temp) {
                       $data['p'.$i] += $temp->qty;
                       $data['p'.$i.'_amount'] += $temp->subtotal;
                       //$total[$id]['p'.$i] += $data['p'.$i];
                   }
                   $data['total_amount'] +=$data['p'.$i.'_amount'];
                }
            }

            $temps1 =  $order->bucket_lineitems()->get();
            if(count($temps1) > 0)
            {
                $temp_w = 0;
               foreach ($temps1 as $temp1) {
                    $temp_w += $temp1->weight;
                    $data['list_b'] .= number_format ($temp1->weight);
                    $data['list_b'] .= ' ';
                    $data['num_b']++;
                    $data['b_amount'] += $temp1->subtotal;
               }
               $data['total_amount'] +=$data['b_amount'];
               //$total[$id]['num_b'] +=$data['num_b'];
               //$total[$id]['sum_b'] +=$temp_w;
            }
        }
        return view('layouts.recript',compact('order','data','products'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function __construct()
    {
        $this->middleware('auth');
    }
}
