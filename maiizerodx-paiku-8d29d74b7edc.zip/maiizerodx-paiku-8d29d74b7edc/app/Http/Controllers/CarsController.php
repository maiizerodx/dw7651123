<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\DB;

class CarsController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $cars = \App\Car::orderBy('id', 'asc')->paginate(20);

        return view('cars.index',compact('cars'));
    }
    
    public function searchData(Request $request)
    {
        $data = $request->get('key');
              
        if($data=="")
            $cars = \App\Car::orderBy('id', 'asc')->paginate(20);
        else
        {
            $cars_raw = DB::table('cars')
                ->where('cars.name', 'like', "%{$data}%")
                ->orWhere('cars.id', 'like', "%{$data}%")
                ->select('cars.id as id')
                ->get();
            $array = json_decode(json_encode($cars_raw), true);

            $cars = \App\Car::whereIn('id', $array)
                    ->orderBy('id', 'asc')->paginate(20);
        }
        
        return view('cars.index',compact('cars'));
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('cars.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //

        // $car =  new \App\Car;
        // $car->name = $request->name;
        // $car->save();

        \App\Car::create($request->all());

        return redirect('/cars');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $car = \App\Car::findOrFail($id);

        return view('cars.show',compact('car'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $car = \App\Car::findOrFail($id);

        return view('cars.edit',compact('car'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $car = \App\Car::findOrFail($id);

        $car->update($request->all());

        return redirect('/cars');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $car = \App\Car::findOrFail($id);

        $customers = \App\Car::findOrFail($id)->customers;

        foreach($customers as $customer)
        {
            $customer->car_id = '0';
            $customer->save();
        }

        $car->delete();

        return redirect('/cars');
    }
}
