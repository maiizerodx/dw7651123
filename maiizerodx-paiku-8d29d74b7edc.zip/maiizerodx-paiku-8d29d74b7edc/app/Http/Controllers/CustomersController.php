<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\DB;


class CustomersController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $customers = \App\Customer::orderBy('id', 'asc')->paginate(20);

        return view('customers.index',compact('customers'));
        //return $customers;
    }

    public function searchData(Request $request)
    {
        $data = $request->get('key');
        // $orders = \App\Order::where('first_name', 'like', "%{$data}%"))
        //                 ->orWhere('last_name', 'like', "%{$data}%"))
        //                 ->paginate(20);
        //
        if($data=="")
            $customers = \App\Customer::orderBy('id', 'asc')->paginate(20);
        else
        {
            $customers_raw = DB::table('customers')
                ->where('customers.name', 'like', "%{$data}%")
                ->orWhere('customers.id', 'like', "%{$data}%")
                ->select('customers.id as id')
                ->get();
            $array = json_decode(json_encode($customers_raw), true);

            $customers = \App\Customer::whereIn('id', $array)
                    ->orderBy('id', 'asc')->paginate(20);
        }

        //$orders = \App\Order::search("4600")->get();
        return view('customers.index',compact('customers'));
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $customertypes = \App\CustomerType::all();
        $cars = \App\Car::all();
        $markets = \App\Market::all();

        return view('customers.create',compact('customertypes','cars','markets'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        //return $request->all();
        $customer = \App\Customer::create($request->all());

        return redirect('/customers');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $customer = \App\Customer::findOrFail($id);

        return view('customers.show',compact('customer'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $customer = \App\Customer::findOrFail($id);
        $customertypes = \App\CustomerType::all();
        $cars = \App\Car::all();
        $markets = \App\Market::all();

        return view('customers.edit',compact('customer','customertypes','cars','markets'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $customer = \App\Customer::findOrFail($id);

        $customer->update($request->all());

      	if($request->input('auto_bill_print') == '')
      		$customer->auto_bill_print = 0;
      	$customer->save();

        return redirect('/customers');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $customer = \App\Customer::findOrFail($id);
        $customer->orders()->delete();
        $customer->delete();

        return redirect('/customers');
    }
}
