<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\DB;

class OrdersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $orders = \App\Order::orderBy('id', 'desc')->paginate(20);
        echo "tes";
        //print_r($orders);
        //return view('orders.index',compact('orders'));

    }

    /**
     * search from order database
     *
     * @return \Illuminate\Http\Response
     */
    public function searchData(Request $request)
    {
        $data = $request->get('key');
        // $orders = \App\Order::where('first_name', 'like', "%{$data}%"))
        //                 ->orWhere('last_name', 'like', "%{$data}%"))
        //                 ->paginate(20);
        //

        if($data=="")
        {
          $orders = \App\Order::orderBy('id', 'desc')->paginate(20);

        }
        else
        {
            $orders_raw = DB::table('orders')
                ->join('customers', 'customers.id', '=', 'orders.customer_id')
                ->where('customers.name', 'like', "%{$data}%")
                ->orWhere('orders.id', 'like', "%{$data}%")
                ->select('orders.id as id')
                ->get();
            $array = json_decode(json_encode($orders_raw), true);

            $orders = \App\Order::whereIn('id', $array)
                    ->orderBy('id', 'desc')->paginate(20);
        }
        //$orders = \App\Order::search("4600")->get();
        return view('orders.index',compact('orders'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function chooseCustomer()
    {
        //
        $customers = \App\Customer::all();

        return view('orders.customerslist',compact('customers'));
    }
    /**
     * @param  [type]
     * @return [type]
     */
    public function createOrderByCustomer($id)
    {
        //
        $customer = \App\Customer::findOrFail($id);

        return view('orders.create',compact('customer'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function storeNewOrder(Request $request)
    {
        //
        $order = \App\Order::create($request->all());

        $order->order_at = date( 'Y-m-d', strtotime( $order->order_at .' + 1 days'));
        $order->save();

        return redirect('orders/'.$order->id.'/edit');
        //return "save Order Head";
    }

    public function storeProductLineitem(Request $request)
    {
        //
        //$order = \App\Order::create($request->all());

        //return redirect('orders/'.$order->id.'/edit');


        $data = $request->all();
        $products = \App\Product::all();
        $productprice = \App\CustomerProductPrice::findOrFail($data['product_price']);

        $product_lineitem = new \App\ProductLineitem();
        $product_lineitem->order_id = $data['order_id'];
        $product_lineitem->product_id = $productprice->product_id;
        $productdata = \App\Product::findOrFail($productprice->product_id);
        $product_lineitem->qty = $data['qty'];

        $subunit = 1;
        if($productdata->weight > 1) $subunit = $productdata->weight;

        if($productprice->price_mode == 1)
        {
            $product_lineitem->price = $productprice->normal_price;
            $product_lineitem->subtotal = $product_lineitem->price * $product_lineitem->qty * $subunit;
            $product_lineitem->save();
            return redirect('orders/'.$data['order_id'].'/edit');
        }
        else
        {
            $product_lineitem->price = 0;
            $step1_amount = $productprice->step1_amount;
            $step1_price  = $productprice->step1_price;
            //$step2_amount = $productprice->step2_amount;
            $step2_price  = $productprice->step2_price;
            $qty          = $product_lineitem->qty * $subunit;
            if($qty > $step1_amount)
            {
               $formula = ($step1_amount*$step1_price)+(($qty-$step1_amount)*$step2_price);
            }
            else
            {
                $formula = $qty*$step1_price;
            }
            $product_lineitem->subtotal = $formula;
            $product_lineitem->save();
            return redirect('orders/'.$data['order_id'].'/edit');
        }

    }

    public function storeBucketLineitem(Request $request)
    {
        //
        //$order = \App\Order::create($request->all());

        //return redirect('orders/'.$order->id.'/edit');


        $data = $request->all();

        $productprice = \App\CustomerProductPrice::findOrFail($data['product_price']);

        $product_lineitem = new \App\BucketLineitem();
        $product_lineitem->order_id = $data['order_id'];
        $product_lineitem->weight = $data['weight'];
        if($productprice->price_mode == 1)
        {
            $product_lineitem->price = $productprice->normal_price;
            $product_lineitem->subtotal = $product_lineitem->price * $product_lineitem->weight;
            $product_lineitem->save();
            return redirect('orders/'.$data['order_id'].'/edit');
        }
        else
        {
            $product_lineitem->price = 0;
            $step1_amount = $productprice->step1_amount;
            $step1_price  = $productprice->step1_price;
            //$step2_amount = $productprice->step2_amount;
            $step2_price  = $productprice->step2_price;
            $weight          = $product_lineitem->weight;
            if($weight > $step1_amount)
            {
               $formula = ($step1_amount*$step1_price)+(($weight-$step1_amount)*$step2_price);
            }
            else
            {
                $formula = $weight*$step1_price;
            }
            $product_lineitem->subtotal = $formula;
            $product_lineitem->save();
            return redirect('orders/'.$data['order_id'].'/edit');
        }

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $order = \App\Order::findOrFail($id);

        return view('orders.show',compact('order'));
        // foreach($order->product_lineitems as $product_lineitem)
        // {
        //     echo $product_lineitem->product->name;
        // }
        // return $order;
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $order = \App\Order::findOrFail($id);
        $productprices = \App\CustomerProductPrice::where('customer_id', $order->customer_id)->where('product_id','!=', 9)->get();
        $bucketprice = \App\CustomerProductPrice::where('customer_id', $order->customer_id)->where('product_id', 9)->first();

        return view('orders.create',compact('order','productprices','bucketprice'));
        //return compact('order','productprices','bucketprice');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $originalDate = $request['order_at'];
        $newDate = date("Y-m-d", strtotime($originalDate));
        //return $newDate ;
        $order = \App\Order::findOrFail($id);
        $order->order_at = $newDate;
        $order->save();
        //$order->update($request->all());
        return redirect('orders/'.$order->id.'/edit');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //$product_lineitem = new \App\ProductLineitem();
        $order = \App\Order::findOrFail($id);
        $order->product_lineitems()->delete();
        $order->bucket_lineitems()->delete();
        $order->delete();

        return redirect('/orders');
    }

    public function destroyProductLineitem($id)
    {
        //$product_lineitem = new \App\ProductLineitem();
        $product_lineitem = \App\ProductLineitem::findOrFail($id);
        $order_id = $product_lineitem->order_id;
        $product_lineitem->delete();

        return redirect('orders/'.$order_id.'/edit');
    }

    public function destroyBucketLineitem($id)
    {
        //$product_lineitem = new \App\ProductLineitem();
        $bucket_lineitem = \App\BucketLineitem::findOrFail($id);
        $order_id = $bucket_lineitem->order_id;
        $bucket_lineitem->delete();

        return redirect('orders/'.$order_id.'/edit');
    }

    public function __construct()
    {
        $this->middleware('auth');
    }
}
