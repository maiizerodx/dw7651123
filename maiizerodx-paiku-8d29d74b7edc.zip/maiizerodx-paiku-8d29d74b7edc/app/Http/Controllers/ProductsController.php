<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\DB;

class ProductsController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $products = \App\Product::orderBy('id', 'asc')->paginate(20);

        return view('products.index',compact('products'));
    }

    public function searchData(Request $request)
    {
        $data = $request->get('key');
              
        if($data=="")
            $products = \App\Product::orderBy('id', 'asc')->paginate(20);
        else
        {
            $cars_raw = DB::table('products')
                ->where('products.name', 'like', "%{$data}%")
                ->orWhere('products.id', 'like', "%{$data}%")
                ->select('products.id as id')
                ->get();
            $array = json_decode(json_encode($cars_raw), true);

            $products = \App\Product::whereIn('id', $array)
                    ->orderBy('id', 'asc')->paginate(20);
        }
        
        return view('products.index',compact('products'));
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $producttypes = \App\ProductType::all();
        return view('products.create',compact('producttypes'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $product = \App\Product::create($request->all());
        return redirect('/products');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $product = \App\Product::findOrFail($id);

        return view('products.show',compact('product'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $product = \App\Product::findOrFail($id);
        $producttypes = \App\ProductType::all();

        return view('products.edit',compact('product','producttypes'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $product = \App\Product::findOrFail($id);

        $product->update($request->all());

        return redirect('/products');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $product = \App\Product::findOrFail($id);

        $product->delete();

        return redirect('/products');
    }

}
