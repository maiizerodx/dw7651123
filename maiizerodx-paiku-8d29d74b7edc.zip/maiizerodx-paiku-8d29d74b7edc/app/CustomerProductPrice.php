<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomerProductPrice extends Model
{
    //
    protected $fillable = [
    	'customer_id',
    	'product_id',
    	'price_mode',
    	'normal_price',
    	'step1_price',
    	'step1_amount',
    	'step2_price',
    	'step2_amount'
    	];

    public function product()
    {
        return $this->belongsTo('App\Product');
    }

    public function customer()
    {
        return $this->belongsTo('App\Customer');
    }
}
