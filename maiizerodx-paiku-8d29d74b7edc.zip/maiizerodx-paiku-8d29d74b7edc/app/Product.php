<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    //
    protected $fillable = ['name','unit','weight','product_type_id'];

    public function productType()
    {
        return $this->belongsTo('App\ProductType');
    }
}
